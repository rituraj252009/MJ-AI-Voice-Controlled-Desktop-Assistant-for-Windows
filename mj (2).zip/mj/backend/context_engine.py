import os
import sys
import time
import ctypes
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("MJ_ContextEngine")

class LiveContextEngine:
    """
    Live Execution Context Engine for MJ.
    Maintains continuous real-time awareness of:
    - Active Foreground Window HWND & Title
    - Active Application Process (e.g. WhatsApp.Root.exe, chrome.exe, notepad.exe)
    - Normalized Application Name & Active Browser Tab
    - Ongoing Task Context (e.g. last searched contact, current video, active file)
    - Contextual reference resolution ('this app', 'this tab', 'here', 'continue', etc.)
    """

    KNOWN_PROCESS_MAP = {
        "whatsapp.root.exe": "whatsapp",
        "whatsapp.exe": "whatsapp",
        "chrome.exe": "chrome",
        "msedge.exe": "edge",
        "firefox.exe": "firefox",
        "brave.exe": "brave",
        "notepad.exe": "notepad",
        "code.exe": "vscode",
        "explorer.exe": "explorer",
        "calc.exe": "calculator",
        "calculatorapp.exe": "calculator",
        "spotify.exe": "spotify",
        "telegram.exe": "telegram",
        "discord.exe": "discord",
        "cmd.exe": "cmd",
        "powershell.exe": "powershell",
        "windowsterminal.exe": "terminal",
        "wt.exe": "terminal",
        "systemsettings.exe": "settings"
    }

    def __init__(self):
        self.active_context: Dict[str, Any] = {
            "active_device": "laptop",
            "active_window_hwnd": None,
            "active_window_title": "",
            "active_process_name": "",
            "active_application": None,
            "active_browser_tab": "",
            "active_browser_url": "",
            "active_task": "",
            "last_action": "",
            "last_target": "",
            "last_app": "",
            "updated_at": time.time()
        }
        self.user32 = ctypes.windll.user32
        self.kernel32 = ctypes.windll.kernel32

    def _ensure_desktop_access(self):
        """Attaches current thread to user's active input desktop if detached."""
        try:
            hdesk = self.user32.OpenInputDesktop(0, False, 0x0100)
            if hdesk:
                self.user32.SetThreadDesktop(hdesk)
                self.user32.CloseDesktop(hdesk)
        except Exception:
            pass

    def _get_process_name(self, hwnd: int) -> str:
        """Retrieves executable process name from window handle using Win32 API."""
        try:
            pid = ctypes.c_ulong()
            self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value == 0:
                return ""

            # PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            hproc = self.kernel32.OpenProcess(0x1000, False, pid.value)
            if not hproc:
                return ""

            try:
                buf = ctypes.create_unicode_buffer(1024)
                size = ctypes.c_ulong(1024)
                if self.kernel32.QueryFullProcessImageNameW(hproc, 0, buf, ctypes.byref(size)):
                    full_path = buf.value
                    return os.path.basename(full_path).lower()
            finally:
                self.kernel32.CloseHandle(hproc)
        except Exception:
            pass
        return ""

    def refresh_active_window(self) -> Dict[str, Any]:
        """
        Polls the active foreground window and updates the live context (<0.2ms).
        """
        self._ensure_desktop_access()
        hwnd = self.user32.GetForegroundWindow()
        title = ""
        process_name = ""
        app_name = None
        browser_tab = ""

        if hwnd:
            length = self.user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buf = ctypes.create_unicode_buffer(length + 1)
                self.user32.GetWindowTextW(hwnd, buf, length + 1)
                title = buf.value.strip()

            process_name = self._get_process_name(hwnd)
            app_name = self.KNOWN_PROCESS_MAP.get(process_name)

            # Infer from title if process name is generic or host
            lower_title = title.lower()
            if not app_name:
                for proc, name in self.KNOWN_PROCESS_MAP.items():
                    if name in lower_title:
                        app_name = name
                        break

            # Browser Tab Awareness
            if app_name in ["chrome", "edge", "brave", "firefox"]:
                browser_tab = title
                # Check if YouTube or WhatsApp Web is the active tab
                if "youtube" in lower_title:
                    app_name = "youtube"
                elif "whatsapp" in lower_title:
                    app_name = "whatsapp_web"
                elif "google search" in lower_title or "google" in lower_title:
                    app_name = "google_search"

        self.active_context["active_window_hwnd"] = hwnd
        self.active_context["active_window_title"] = title
        self.active_context["active_process_name"] = process_name
        self.active_context["active_application"] = app_name or (self.active_context.get("active_application") if title else None)
        self.active_context["active_browser_tab"] = browser_tab
        self.active_context["updated_at"] = time.time()

        return self.active_context

    def get_active_context(self) -> Dict[str, Any]:
        """Returns the up-to-date execution context."""
        self.refresh_active_window()
        return self.active_context

    def update_task_state(self, action: str = "", target: str = "", task: str = "", app: str = ""):
        """Updates active task memory after executing an action."""
        if action:
            self.active_context["last_action"] = action
        if target:
            self.active_context["last_target"] = target
        if task:
            self.active_context["active_task"] = task
        if app:
            self.active_context["last_app"] = app
            self.active_context["active_application"] = app
        self.active_context["updated_at"] = time.time()

    def is_contextual_reference(self, text: str) -> bool:
        """
        Determines if user command refers to the currently open app/tab/window.
        e.g. 'this app', 'is app mein', 'this tab', 'here', 'continue', 'now do this', 'in this'
        """
        t = text.lower().strip()
        triggers = [
            "this app", "this opened app", "the opened app", "opened app",
            "this window", "this tab", "active tab", "active window",
            "here", "in this", "inside this", "inside it", "in it",
            "is app mein", "is app me", "isme", "ismein", "is window me",
            "is window mein", "is tab mein", "is tab me", "yahan", "yaha",
            "continue", "now do this", "ab ye karo", "agle step", "next",
            "send it", "bhejo ise", "play it", "chalao ise", "pause it",
            "close it", "ise band karo", "type this", "write this"
        ]
        return any(trig in t for trig in triggers)

    def resolve_target(self, explicit_target: Optional[str] = None) -> Dict[str, Any]:
        """
        Resolves the target application/window/tab for an action.
        If explicit_target is provided, checks if it's a contextual reference;
        if so, resolves to the live active context.
        """
        ctx = self.get_active_context()

        if not explicit_target or self.is_contextual_reference(explicit_target):
            target_app = ctx.get("active_application") or ctx.get("last_app")
            return {
                "is_contextual": True,
                "application": target_app,
                "window_title": ctx.get("active_window_title"),
                "browser_tab": ctx.get("active_browser_tab"),
                "hwnd": ctx.get("active_window_hwnd"),
                "last_target": ctx.get("last_target"),
                "last_action": ctx.get("last_action")
            }

        return {
            "is_contextual": False,
            "application": explicit_target.lower().strip(),
            "window_title": ctx.get("active_window_title"),
            "browser_tab": ctx.get("active_browser_tab"),
            "hwnd": ctx.get("active_window_hwnd"),
            "last_target": ctx.get("last_target"),
            "last_action": ctx.get("last_action")
        }


# Global singleton instance
context_engine = LiveContextEngine()
