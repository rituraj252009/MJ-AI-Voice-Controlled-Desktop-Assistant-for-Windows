import sys
import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.tools import computer
from backend.tools import files


def test_computer_tools():
    print("Testing get_battery...")
    res = computer.get_battery()
    print("Result:", res)
    assert res["success"] is True
    assert res["tool"] == "get_battery"

    print("\nTesting get_system_stats...")
    res = computer.get_system_stats()
    print("Result:", res)
    assert res["success"] is True

    print("\nTesting read_screen...")
    res = computer.read_screen()
    print("Result:", res)
    assert res["success"] is True
    assert "active_window" in res["data"]
    assert "resolution" in res["data"]

    print("\nTesting safe command...")
    res = computer.run_safe_command("Get-Date")
    print("Result:", res)
    assert res["success"] is True

    print("\nTesting dangerous command blocked...")
    res = computer.run_safe_command("format C:")
    print("Result:", res)
    assert res["success"] is False
    assert "blocked" in res["error"].lower()


def test_file_tools():
    test_file = "mj_test_temp_doc.txt"
    print("\nTesting create_file...")
    res = files.create_file(test_file, initial_content="MJ Autonomous Agent Test")
    print("Result:", res)
    assert res["success"] is True

    print("\nTesting read_file_content...")
    res = files.read_file_content(test_file)
    print("Result:", res)
    assert res["success"] is True
    assert "MJ Autonomous Agent Test" in res["data"]["content"]

    print("\nTesting delete_file...")
    res = files.delete_file(test_file)
    print("Result:", res)
    assert res["success"] is True


if __name__ == "__main__":
    print("=== RUNNING PHASE 2 TESTS ===")
    test_computer_tools()
    test_file_tools()
    print("\n=== ALL PHASE 2 TESTS PASSED! ===")
