import unittest
from backend.intent_parser import intent_parser
from brain import brain

class TestPRDSpecification(unittest.TestCase):
    """
    Tests ensuring full coverage of all PRD specification voice commands:
    - Barge-in & interruption ('Stop. Open WhatsApp instead', 'Stop', 'Ruko')
    - Local-first file/folder search ('Open my resume', 'Find my Downloads folder', 'Open main.py')
    - Media controls ('Open the first one', 'Search Java ka roadmap')
    - Contextual in-app search ('Is app mein Rahul ko search karo', 'Search Amit in this tab', 'Search here', 'Do the same here')
    - System controls ('What is my battery level?', 'Set volume to 50 percent')
    """

    def test_barge_in_and_stop(self):
        # Stop. Open WhatsApp instead.
        res = intent_parser.parse("Stop. Open WhatsApp instead.")
        self.assertTrue(res.get("is_compound"))
        self.assertEqual(res["steps"][0]["intent"], "stop_task")
        self.assertEqual(res["steps"][1]["intent"], "open_app")
        self.assertEqual(res["steps"][1]["application"], "whatsapp")

        # Standalone stops
        for stop_word in ["Stop", "Ruko", "Ruk jao", "Cancel", "Wait"]:
            p = intent_parser.parse(stop_word)
            self.assertEqual(p["intent"], "stop_task")
            b_res = brain.process_command(stop_word)
            self.assertEqual(b_res["system_action"], "stop_current")

    def test_local_first_files_and_folders(self):
        # Open my resume
        p_res = intent_parser.parse("Open my resume")
        self.assertEqual(p_res["intent"], "open_file")
        self.assertIn("resume", p_res["file"].lower())
        b_res = brain.process_command("Open my resume")
        self.assertEqual(b_res["system_action"], "open_file")

        # Open main.py
        p_py = intent_parser.parse("Open main.py")
        self.assertEqual(p_py["intent"], "open_file")
        self.assertEqual(p_py["file"], "main.py")
        b_py = brain.process_command("Open main.py")
        self.assertEqual(b_py["system_action"], "open_file")

        # Find my Downloads folder
        p_fol = intent_parser.parse("Find my Downloads folder")
        self.assertEqual(p_fol["intent"], "open_folder")
        self.assertEqual(p_fol["folder"], "downloads")
        b_fol = brain.process_command("Find my Downloads folder")
        self.assertEqual(b_fol["system_action"], "open_folder")

    def test_media_and_youtube_first_result(self):
        # Open the first one
        p_first = intent_parser.parse("Open the first one")
        self.assertEqual(p_first["intent"], "media_control")
        self.assertEqual(p_first["action"], "open_first_video")

        # Search Java ka roadmap
        p_search = intent_parser.parse("Search Java ka roadmap")
        self.assertEqual(p_search["intent"], "search_in_app")
        self.assertIn("java ka roadmap", p_search["query"].lower())

    def test_in_app_and_context_search(self):
        # Is app mein Rahul ko search karo
        p_ctx1 = intent_parser.parse("Is app mein Rahul ko search karo")
        self.assertEqual(p_ctx1["intent"], "search_in_app")
        self.assertEqual(p_ctx1["query"].lower(), "rahul")
        self.assertTrue(p_ctx1["is_contextual"])

        # Search Amit in this tab
        p_ctx2 = intent_parser.parse("Search Amit in this tab")
        self.assertEqual(p_ctx2["intent"], "search_in_app")
        self.assertEqual(p_ctx2["query"].lower(), "amit")
        self.assertTrue(p_ctx2["is_contextual"])

        # Do the same here
        p_cont = intent_parser.parse("Do the same here")
        self.assertEqual(p_cont["intent"], "context_continue")
        self.assertTrue(p_cont["is_contextual"])
        b_cont = brain.process_command("Do the same here")
        self.assertEqual(b_cont["system_action"], "context_task")

    def test_system_telemetry_and_volume(self):
        # Battery
        p_bat = intent_parser.parse("What is my battery level?")
        self.assertEqual(p_bat["intent"], "get_battery")
        b_bat = brain.process_command("What is my battery level?")
        self.assertEqual(b_bat["system_action"], "get_battery")

        # Volume
        p_vol = intent_parser.parse("Set volume to 50 percent")
        self.assertEqual(p_vol["intent"], "set_volume")
        self.assertEqual(p_vol["level"], 50)
        b_vol = brain.process_command("Set volume to 50 percent")
        self.assertEqual(b_vol["system_action"], "set_volume")
        self.assertEqual(b_vol["action_param"], 50)

if __name__ == "__main__":
    unittest.main()
