import os
import sys
import unittest

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.intent_parser import intent_parser
from backend.context_engine import context_engine
from backend.local_policy import local_policy
from backend.orchestrator.planner import TaskPlanner
from backend.adapters.browser_adapter import browser_adapter
from backend.adapters.whatsapp_adapter import whatsapp_adapter
from app_automator import automator
from brain import brain


class TestMJUpgradeSuite(unittest.TestCase):
    """
    Verification test suite for MJ Assistant Upgrade:
    - Language / Intent processing (Hindi / Hinglish / English)
    - Verbatim entity & message preservation
    - Local-first execution policy
    - Multi-step compound command planning
    - Active context resolution
    """

    # ==================== 1. Direct Intent Parser Tests ====================
    def test_hindi_sov_open_app(self):
        res = intent_parser.parse("WhatsApp kholo")
        self.assertEqual(res.get("intent"), "open_app")
        self.assertEqual(res.get("application"), "whatsapp")

    def test_english_svo_open_app(self):
        res = intent_parser.parse("Open YouTube")
        self.assertEqual(res.get("intent"), "open_app")
        self.assertEqual(res.get("application"), "youtube")

    def test_whatsapp_message_verbatim_preservation(self):
        prompt = "Amit ko message karo saying I will reach in 10 minutes"
        res = intent_parser.parse(prompt)
        self.assertEqual(res.get("intent"), "send_message")
        self.assertEqual(res.get("contact"), "Amit")
        self.assertEqual(res.get("message"), "I will reach in 10 minutes")

    def test_whatsapp_message_hindi_devanagari_preservation(self):
        prompt = "राहुल को संदेश भेजो saying नमस्ते भाई कैसे हो"
        res = intent_parser.parse(prompt)
        self.assertEqual(res.get("intent"), "send_message")
        self.assertEqual(res.get("contact"), "राहुल")
        self.assertEqual(res.get("message"), "नमस्ते भाई कैसे हो")

    def test_contextual_search(self):
        res = intent_parser.parse("Is app mein Amit ko search karo")
        self.assertEqual(res.get("intent"), "search_in_app")
        self.assertEqual(res.get("query").lower(), "amit")
        self.assertTrue(res.get("is_contextual"))

    def test_media_controls(self):
        res_play = intent_parser.parse("Play it")
        self.assertEqual(res_play.get("intent"), "media_control")
        self.assertEqual(res_play.get("action"), "play")

        res_pause = intent_parser.parse("Pause")
        self.assertEqual(res_pause.get("intent"), "media_control")
        self.assertEqual(res_pause.get("action"), "pause")

    # ==================== 2. Compound Multi-Step Commands ====================
    def test_compound_whatsapp_workflow(self):
        prompt = "WhatsApp kholo aur Amit ko message karo saying I am on my way"
        parsed = intent_parser.parse(prompt)
        self.assertTrue(parsed.get("is_compound"))
        self.assertEqual(len(parsed.get("steps")), 2)
        self.assertEqual(parsed["steps"][0].get("intent"), "open_app")
        self.assertEqual(parsed["steps"][1].get("intent"), "send_message")
        self.assertEqual(parsed["steps"][1].get("contact"), "Amit")

    def test_planner_compound_plan_generation(self):
        planner = TaskPlanner()
        plan = planner.plan("WhatsApp kholo aur Amit ko search karo")
        self.assertEqual(len(plan.steps), 2)
        self.assertEqual(plan.steps[0].tool, "open_app")
        self.assertEqual(plan.steps[0].params.get("app"), "whatsapp")
        self.assertEqual(plan.steps[1].tool, "whatsapp_search")
        self.assertEqual(plan.steps[1].params.get("contact"), "amit")

    def test_planner_youtube_plan_generation(self):
        planner = TaskPlanner()
        plan = planner.plan("YouTube kholo aur Java DSA search karo")
        self.assertEqual(len(plan.steps), 2)
        self.assertEqual(plan.steps[0].tool, "open_app")
        self.assertEqual(plan.steps[0].params.get("app"), "youtube")
        self.assertEqual(plan.steps[1].tool, "play_youtube")
        self.assertEqual(plan.steps[1].params.get("query"), "java dsa")

    # ==================== 3. Local-First Policy Tests ====================
    def test_local_first_blocks_web_fallback(self):
        res = local_policy.handle_missing_local_target("non_existent_program_xyz")
        self.assertFalse(res.get("success"))
        self.assertTrue(res.get("blocked_web_fallback"))
        self.assertIn("voice_response", res)
        # Verify no URL opened
        self.assertNotIn("http", res.get("summary"))

    def test_automator_missing_app_local_policy(self):
        res = automator.open_any("completely_fake_program_9999")
        # Should return local failure message, not open web browser
        self.assertIn("नहीं मिला", res)

    # ==================== 4. Live Context Engine Tests ====================
    def test_context_engine_refresh(self):
        ctx = context_engine.get_active_context()
        self.assertIn("active_device", ctx)
        self.assertEqual(ctx["active_device"], "laptop")
        self.assertIn("active_window_title", ctx)
        self.assertIn("active_process_name", ctx)

    def test_contextual_reference_detection(self):
        self.assertTrue(context_engine.is_contextual_reference("in this opened tab, search java"))
        self.assertTrue(context_engine.is_contextual_reference("is app mein"))
        self.assertTrue(context_engine.is_contextual_reference("send it"))
        self.assertTrue(context_engine.is_contextual_reference("continue"))
        self.assertFalse(context_engine.is_contextual_reference("open calculator"))

    # ==================== 5. Brain Heuristic Sub-Millisecond Routing ====================
    def test_brain_fast_routing(self):
        dec_open = brain.process_command("WhatsApp kholo")
        self.assertEqual(dec_open.get("system_action"), "open_any")
        self.assertEqual(dec_open.get("action_param"), "whatsapp")

        dec_msg = brain.process_command("Amit ko message bhejo saying see you at 6")
        self.assertEqual(dec_msg.get("system_action"), "send_whatsapp_message")
        self.assertEqual(dec_msg["action_param"].get("contact"), "Amit")
        self.assertEqual(dec_msg["action_param"].get("message"), "see you at 6")


if __name__ == "__main__":
    unittest.main()
