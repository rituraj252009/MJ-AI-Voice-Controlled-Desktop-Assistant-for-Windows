import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.tools.browser import browser


def test_browser_agent():
    print("Testing Playwright WebBrowserAgent...")
    # 1. Navigate to a test page or data URL
    res = browser.navigate("https://example.com")
    print("Navigate result:", res)
    assert res["success"] is True
    assert "Example Domain" in res["data"]["title"]

    # 2. Inspect DOM
    inspect_res = browser.inspect_page()
    print("Inspect result:", inspect_res["data"]["title"])
    assert inspect_res["success"] is True

    # 3. Read Page Text
    read_res = browser.read_page()
    print("Read content snippet:", read_res["data"]["content"][:100])
    assert "Example Domain" in read_res["data"]["content"]

    # 4. Form Fill Simulation on a data URL
    form_html = """
    data:text/html,
    <html><body>
      <h2>Registration Form</h2>
      <form id="reg">
        <label>Full Name: <input type="text" name="fname" id="name"></label><br>
        <label>Email: <input type="email" name="email" id="email"></label><br>
        <label>Phone: <input type="tel" name="phone" id="phone"></label><br>
        <button type="submit" id="sub">Submit</button>
      </form>
    </body></html>
    """
    browser.navigate(form_html)
    fill_res = browser.fill_form({"Full Name": "Rituraj", "Email": "rituraj@example.com", "Phone": "+919876543210"})
    print("Fill form result:", fill_res)
    assert fill_res["success"] is True
    assert fill_res["data"]["fields_matched"] >= 2

    # 5. Validate Form
    val_res = browser.validate_form()
    print("Validate form result:", val_res)
    assert val_res["success"] is True

    browser.close()
    print("Browser agent test passed!")


if __name__ == "__main__":
    test_browser_agent()
