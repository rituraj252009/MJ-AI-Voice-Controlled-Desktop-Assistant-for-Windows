import sys
import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.orchestrator.planner import TaskPlanner
from backend.orchestrator.executor import TaskExecutor
from backend.orchestrator.agent import MasterAgent


def test_planner():
    print("Testing TaskPlanner heuristics...")
    planner = TaskPlanner()
    
    # Test multi-step YouTube search
    plan1 = planner.plan("Chrome kholo aur YouTube par Java DSA playlist search karo")
    print(f"Goal: {plan1.goal}")
    print(f"Steps count: {len(plan1.steps)}")
    for s in plan1.steps:
        print(f"  Step {s.step_id}: {s.description} -> Tool: {s.tool}({s.params})")
    assert len(plan1.steps) >= 2
    assert plan1.steps[0].tool == "open_app"

    # Test multi-step Notepad
    plan2 = planner.plan("Open Notepad and write my project meeting notes")
    print(f"\nGoal: {plan2.goal}")
    for s in plan2.steps:
        print(f"  Step {s.step_id}: {s.description} -> Tool: {s.tool}({s.params})")
    assert len(plan2.steps) >= 2


def test_executor_with_safe_steps():
    print("\nTesting TaskExecutor with safe diagnostic steps...")
    planner = TaskPlanner()
    events = []
    
    def log_event(event_name, payload):
        events.append((event_name, payload))

    executor = TaskExecutor(autonomy_mode="SMART_AUTONOMY", on_event_callback=log_event)

    # Create a test plan with get_battery and get_system_stats
    from backend.orchestrator.planner import TaskPlan, TaskStep
    plan = TaskPlan("System Diagnostics", [
        TaskStep(1, "Check Battery", "get_battery", {}, "check_success", "low"),
        TaskStep(2, "Check Stats", "get_system_stats", {}, "check_success", "low")
    ])

    res = executor.execute_plan(plan)
    print("Execution Result:", res["success"])
    print("Summary:", res["summary"])
    assert res["success"] is True
    assert len(events) >= 4  # task_started, task_step, tool_called, tool_result, ...


def test_master_agent():
    print("\nTesting MasterAgent end-to-end...")
    agent = MasterAgent()
    res = agent.run_goal("What is my system battery and CPU status?")
    print("Agent result:", res.get("voice_response"))
    assert res["success"] is True


if __name__ == "__main__":
    print("=== RUNNING PHASE 3 TESTS ===")
    test_planner()
    test_executor_with_safe_steps()
    test_master_agent()
    print("\n=== ALL PHASE 3 TESTS PASSED! ===")
