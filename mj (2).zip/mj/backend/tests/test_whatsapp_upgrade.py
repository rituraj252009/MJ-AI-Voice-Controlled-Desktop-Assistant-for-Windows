import os
import sys
import unittest
import time

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.whatsapp.detector import whatsapp_detector
from backend.whatsapp.launcher import whatsapp_launcher
from backend.whatsapp.context_manager import whatsapp_context
from backend.whatsapp.action_executor import whatsapp_executor
from backend.whatsapp.manager import whatsapp_manager
from backend.adapters.whatsapp_adapter import whatsapp_adapter
from backend.intent_parser import intent_parser
from backend.memory.contacts import contacts_manager
from brain import brain
from terminal_controller import controller as term_ctrl


class TestWhatsAppUpgradeSuite(unittest.TestCase):
    """
    Comprehensive verification for WhatsApp Full Control & Reliability:
    1. Target selection priority (Stable Desktop > Beta > Web fallback)
    2. Search & open chat commands
    3. Send message & pronoun resolution ('usko bolo...')
    4. Reply to active message context
    5. Read visible / unread messages
    6. File attachment intent & resolution
    7. Contact safety & duplicate message protection
    8. Diagnostic status reporting
    """

    def setUp(self):
        whatsapp_context.clear()

    # ==================== 1. Target Selection Priority ====================
    def test_target_priority_detection(self):
        pref = whatsapp_detector.get_preferred_target(prefer_beta=False)
        self.assertIn("priority", pref)
        self.assertIn(pref["priority"], [1, 2, 3])

        # If desktop is installed on PC, priority must be <= 2, never web fallback
        if whatsapp_detector.is_desktop_installed():
            self.assertIn(pref["priority"], [1, 2])
            self.assertNotEqual(pref["type"], "web_fallback")

        # Verify beta preference flag
        pref_beta = whatsapp_detector.get_preferred_target(prefer_beta=True)
        if any(i.get("is_beta") for i in whatsapp_detector.detect_all_installations()):
            self.assertTrue(pref_beta.get("is_beta"))

    # ==================== 2. Search & Open Chat Intent ====================
    def test_search_contact_intents(self):
        # English SVO: Search Ravi on WhatsApp
        res1 = intent_parser.parse("Search Ravi on WhatsApp")
        self.assertEqual(res1.get("intent"), "whatsapp_search")
        self.assertEqual(res1.get("contact"), "Ravi")

        # Hindi SOV: Ravi ko WhatsApp par search karo
        res2 = intent_parser.parse("Ravi ko WhatsApp par search karo")
        self.assertEqual(res2.get("intent"), "whatsapp_search")
        self.assertEqual(res2.get("contact"), "Ravi")

        # Chat open: Amit ka chat kholo
        res3 = intent_parser.parse("Amit ka chat kholo")
        self.assertEqual(res3.get("intent"), "whatsapp_search")
        self.assertEqual(res3.get("contact"), "Amit")

        # Find Rahul on WhatsApp
        res4 = intent_parser.parse("Find Rahul on WhatsApp")
        self.assertEqual(res4.get("intent"), "whatsapp_search")
        self.assertEqual(res4.get("contact"), "Rahul")

    # ==================== 3. Send Message & Pronoun Context ====================
    def test_send_message_intents(self):
        # SVO
        res1 = intent_parser.parse("Send 'I will call you later' to Amit on WhatsApp")
        self.assertEqual(res1.get("intent"), "send_message")
        self.assertEqual(res1.get("contact"), "Amit")
        self.assertIn("I will call you later", res1.get("message"))

        # SOV with colon
        res2 = intent_parser.parse("Ravi ko WhatsApp par message karo: kal college aa raha hai?")
        self.assertEqual(res2.get("intent"), "send_message")
        self.assertEqual(res2.get("contact"), "Ravi")
        self.assertIn("kal college aa raha hai?", res2.get("message"))

        # Hindi bolo format
        res3 = intent_parser.parse("WhatsApp par Neha ko bolo main 10 minute mein aa raha hoon")
        self.assertEqual(res3.get("intent"), "send_message")
        self.assertEqual(res3.get("contact"), "Neha")
        self.assertIn("main 10 minute mein aa raha hoon", res3.get("message"))

    def test_context_pronoun_resolution(self):
        # Step 1: Open Ravi's chat
        whatsapp_context.update_context(chat="Ravi", contact="Ravi", action="opened_chat")
        self.assertEqual(whatsapp_context.get_active_contact(), "Ravi")

        # Step 2: "Usko bolo main 5 minute mein aa raha hoon"
        parsed = intent_parser.parse("Usko bolo main 5 minute mein aa raha hoon")
        self.assertEqual(parsed.get("intent"), "send_message")
        self.assertEqual(parsed.get("contact"), "usko")

        # Resolve pronoun
        resolved = whatsapp_context.resolve_contact(parsed.get("contact"))
        self.assertEqual(resolved, "Ravi")

        # Fast brain heuristic routing handles pronoun automatically
        dec = brain.process_command("Usko bolo main 5 minute mein aa raha hoon")
        self.assertEqual(dec.get("system_action"), "send_whatsapp_message")
        self.assertEqual(dec["action_param"].get("contact"), "Ravi")
        self.assertIn("5 minute mein aa raha hoon", dec["action_param"].get("message"))

    # ==================== 4. Replies & Context Maintenance ====================
    def test_reply_intents(self):
        # Is message ka reply karo: okay
        res1 = intent_parser.parse("Is message ka reply karo: okay")
        self.assertEqual(res1.get("intent"), "whatsapp_reply")
        self.assertEqual(res1.get("message"), "okay")

        # Reply that I will call him later
        res2 = intent_parser.parse("Reply that I will call him later")
        self.assertEqual(res2.get("intent"), "whatsapp_reply")
        self.assertIn("I will call him later", res2.get("message"))

        # Brain heuristic match
        whatsapp_context.update_context(chat="Amit", contact="Amit")
        dec = brain.process_command("Is message ka reply karo: haan main aa raha hoon")
        self.assertEqual(dec.get("system_action"), "whatsapp_reply")
        self.assertEqual(dec.get("action_param"), "haan main aa raha hoon")

    # ==================== 5. Message Reading / Information Access ====================
    def test_message_reading_intents(self):
        # Ravi ne kya message kiya?
        res1 = intent_parser.parse("Ravi ne kya message kiya?")
        self.assertEqual(res1.get("intent"), "whatsapp_read")
        self.assertEqual(res1.get("contact"), "Ravi")

        # Last message kya hai?
        res2 = intent_parser.parse("Last message kya hai?")
        self.assertEqual(res2.get("intent"), "whatsapp_read")
        self.assertEqual(res2.get("contact"), "")

        # Unread messages dikhao
        res3 = intent_parser.parse("Unread messages dikhao")
        self.assertEqual(res3.get("intent"), "whatsapp_unread")

        # Is chat ka latest message read karo
        res4 = intent_parser.parse("Is chat ka latest message read karo")
        self.assertEqual(res4.get("intent"), "whatsapp_read")

    # ==================== 6. File Attachment Intents ====================
    def test_file_attachment_intents(self):
        # Ravi ko ye file WhatsApp par bhejo
        res1 = intent_parser.parse("Ravi ko ye file WhatsApp par bhejo")
        self.assertEqual(res1.get("intent"), "whatsapp_send_file")
        self.assertEqual(res1.get("contact"), "Ravi")

        # Send this PDF to Amit
        res2 = intent_parser.parse("Send this PDF to Amit")
        self.assertEqual(res2.get("intent"), "whatsapp_send_file")
        self.assertEqual(res2.get("contact"), "Amit")

    # ==================== 7. Contact Safety & Duplicate Protection ====================
    def test_duplicate_send_protection(self):
        contact = "TestUser"
        msg = "Hello, testing deduplication safety"

        # First send attempt records cache
        whatsapp_executor._record_send(contact, msg)
        self.assertTrue(whatsapp_executor._is_duplicate_send(contact, msg, window_seconds=5.0))

        # Attempting duplicate send within window triggers protection
        res = whatsapp_executor.send_message(contact, msg)
        self.assertTrue(res.get("success"))
        self.assertTrue(res.get("duplicate_prevented"))
        self.assertIn("Sent to", res.get("voice_response"))

    def test_contact_ambiguity_detection(self):
        # Insert test contacts with same first name into memory
        try:
            contacts_manager.add_or_update_contact("Rahul Sharma", phone="9999999991")
            contacts_manager.add_or_update_contact("Rahul Verma", phone="9999999992")

            matches = contacts_manager.find_all_matching_contacts("Rahul")
            self.assertGreaterEqual(len(matches), 2)

            res = whatsapp_executor.send_message("Rahul", "Hey bro")
            self.assertTrue(res.get("requires_clarification"))
            self.assertIn("multiple contacts", res.get("voice_response").lower())
        except Exception:
            pass

    # ==================== 8. Status Commands ====================
    def test_status_intents_and_reporting(self):
        # WhatsApp status intent
        res_wa = intent_parser.parse("WhatsApp status")
        self.assertEqual(res_wa.get("intent"), "whatsapp_status")

        # MJ status intent
        res_mj = intent_parser.parse("MJ status")
        self.assertEqual(res_mj.get("intent"), "mj_status")

        # Status output content
        wa_status_text = term_ctrl.get_whatsapp_status()
        self.assertIn("WhatsApp Desktop", wa_status_text)

        mj_status_text = term_ctrl.get_mj_status()
        self.assertIn("Microphone", mj_status_text)
        self.assertIn("STT", mj_status_text)
        self.assertIn("TTS", mj_status_text)
        self.assertIn("WhatsApp", mj_status_text)


if __name__ == "__main__":
    unittest.main()
