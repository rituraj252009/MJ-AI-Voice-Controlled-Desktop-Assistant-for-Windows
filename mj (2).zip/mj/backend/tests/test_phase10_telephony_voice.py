import os
import sys
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from voice.audio import AudioProcessor
from voice.vad import VoiceActivityDetector
from voice.interruption import BargeInDetector
from voice.session_manager import session_manager
from backend.tools.calls import telephony


def test_audio_processor():
    print("Testing AudioProcessor mulaw/pcm conversion...")
    # Generate 16kHz sine wave PCM
    sample_rate = 16000
    t = np.linspace(0, 0.5, int(sample_rate * 0.5), endpoint=False)
    sine_wave = (np.sin(2 * np.pi * 440 * t) * 16384).astype(np.int16)
    pcm_bytes = sine_wave.tobytes()

    # Convert PCM to mulaw
    mulaw = AudioProcessor.pcm16_to_mulaw(pcm_bytes, source_rate=16000, target_rate=8000)
    assert len(mulaw) > 0

    # Convert mulaw back to PCM
    pcm_reconstructed = AudioProcessor.mulaw_to_pcm16(mulaw, target_rate=16000, source_rate=8000)
    assert len(pcm_reconstructed) > 0

    # Test WAV header creation
    wav = AudioProcessor.create_wav_header(pcm_bytes, sample_rate=16000)
    assert wav.startswith(b"RIFF")
    print("AudioProcessor passed!")


def test_vad():
    print("\nTesting VoiceActivityDetector...")
    vad = VoiceActivityDetector(sample_rate=16000, energy_threshold=0.01)

    # 1. Silence
    silence = np.zeros(1024, dtype=np.int16).tobytes()
    res_silence = vad.process_frame(silence)
    assert res_silence["is_speech"] is False

    # 2. Speech / Audio energy
    speech_frame = (np.sin(np.linspace(0, 10, 1024)) * 15000).astype(np.int16).tobytes()
    res_speech = vad.process_frame(speech_frame)
    assert res_speech["is_speech"] is True
    print("VAD passed!")


def test_barge_in():
    print("\nTesting BargeInDetector...")
    barge = BargeInDetector(energy_threshold=0.02, consecutive_spikes_required=2)
    interrupted = False

    def on_interrupt():
        nonlocal interrupted
        interrupted = True

    # High energy audio
    loud_frame = (np.ones(1024, dtype=np.int16) * 20000).tobytes()
    barge.check_for_interruption(loud_frame, on_interrupt_callback=on_interrupt)
    barge.check_for_interruption(loud_frame, on_interrupt_callback=on_interrupt)
    assert interrupted is True
    print("Barge-in passed!")


def test_telephony_and_session():
    print("\nTesting TelephonyConnector & SessionManager...")
    # Outbound call
    out_res = telephony.start_outgoing_call("Rahul", goal="Confirm project meeting time")
    print("Outbound call result:", out_res)
    assert out_res["success"] is True
    call_id = out_res["data"]["call_id"]

    # Session tracking
    session = session_manager.get_session(call_id)
    assert session is not None
    session.add_turn("assistant", "Hello Rahul, I am calling on behalf of Sir Rituraj.")
    session.add_turn("caller", "Yes, tell me about the meeting.")
    session.add_turn("assistant", "Meeting is scheduled for tomorrow at 11 AM.")

    # End call
    end_res = telephony.end_call(call_id)
    print("End call summary:", end_res["data"]["summary"])
    assert end_res["success"] is True
    assert "Meeting is scheduled" in end_res["data"]["summary"]

    # Inbound webhook test
    in_res = telephony.handle_incoming_call("+919999988888", "in_call_999")
    print("Inbound call handler:", in_res)
    assert in_res["action"] == "answer"
    assert in_res["caller"] == "Rahul"
    print("Telephony and Sessions passed!")


if __name__ == "__main__":
    print("=== RUNNING PHASE 10, 11, 12 TESTS ===")
    test_audio_processor()
    test_vad()
    test_barge_in()
    test_telephony_and_session()
    print("\n=== ALL PHASE 10, 11, 12 TESTS PASSED! ===")
