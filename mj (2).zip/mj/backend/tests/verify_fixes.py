import sys
import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from brain import brain
from backend.intent_parser import intent_parser

test_cases = [
    ('YouTube, kholo,', 'open_any', 'youtube'),
    ('YouTube, kolum', 'open_any', 'youtube'),
    ('WhatsApp, kholo', 'open_any', 'whatsapp'),
    ('message to Raj,', 'whatsapp_search', 'Raj'),
    ('राच, को, कॉल, करो, WhatsApp, पर, राच, को, कॉल, करो, WhatsApp, पर,', 'whatsapp_call', 'Raj'),
    ('Rahul ko call karo WhatsApp par', 'whatsapp_call', 'Rahul'),
    ('Open YouTube', 'open_any', 'youtube'),
    ('Notepad kholo', 'open_any', 'notepad')
]

print("=== RUNNING VERIFICATION SUITE ===")
all_passed = True
for query, expected_action, expected_param in test_cases:
    dec = brain.process_command(query)
    action = dec.get('system_action')
    param = dec.get('action_param')
    
    if isinstance(param, dict) and 'contact' in param:
        param_check = param['contact']
    else:
        param_check = param
        
    ok_action = (action == expected_action)
    ok_param = (str(expected_param).lower() in str(param_check).lower())
    
    if ok_action and ok_param:
        print(f"PASS: '{query}' -> {action} ({param_check}) [Voice: {dec.get('voice_response')}]")
    else:
        print(f"FAIL: '{query}' -> got {action} ({param_check}), expected {expected_action} ({expected_param})")
        all_passed = False

if all_passed:
    print("\nALL VERIFICATION CASES PASSED SUCCESSFULLY!")
else:
    print("\nSOME CASES FAILED")
    sys.exit(1)
