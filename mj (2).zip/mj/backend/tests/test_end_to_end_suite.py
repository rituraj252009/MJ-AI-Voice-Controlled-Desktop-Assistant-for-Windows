import os
import sys
import time

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.tools import computer
from backend.tools import files
from backend.tools.browser import browser
from backend.tools.whatsapp import whatsapp_agent
from backend.tools.calls import telephony
from backend.security.credentials import vault
from backend.security.policy import SecurityPolicy
from backend.orchestrator.agent import master_agent
from backend.memory.conversations import conversation_manager
from backend.memory.contacts import contacts_manager
from voice.session_manager import session_manager


def run_computer_tests():
    print("\n--- 1. COMPUTER AGENT TESTS ---")
    
    # 1. Read Screen
    res = computer.read_screen()
    print("[PASS] Read Screen:", res["data"]["resolution"])
    assert res["success"] is True

    # 2. System Stats
    res = computer.get_system_stats()
    print("[PASS] System Stats:", res["result"][:50])
    assert res["success"] is True

    # 3. Battery
    res = computer.get_battery()
    print("[PASS] Battery:", res["result"])
    assert res["success"] is True

    # 4. Screenshot
    res = computer.screenshot()
    print("[PASS] Screenshot saved:", os.path.exists(res["data"]["path"]))
    assert res["success"] is True
    if os.path.exists(res["data"]["path"]):
        os.remove(res["data"]["path"])

    # 5. File creation & read
    t_file = "e2e_test_doc.txt"
    files.create_file(t_file, "Autonomous AI Verification")
    r_res = files.read_file_content(t_file)
    print("[PASS] File created & read content:", r_res["data"]["content"])
    assert "Autonomous AI Verification" in r_res["data"]["content"]
    files.delete_file(t_file)


def run_website_tests():
    print("\n--- 2. WEBSITE AGENT TESTS ---")
    
    # 1. Navigate
    res = browser.navigate("https://example.com")
    print("[PASS] Navigate:", res["data"]["title"])
    assert res["success"] is True

    # 2. Inspect DOM
    res = browser.inspect_page()
    print("[PASS] Inspect page:", res["data"]["title"])
    assert res["success"] is True

    # 3. Secure Login simulation with vault
    vault.store_credential("test_portal", "rituraj_admin", "TestSecretPass99!")
    test_login_html = """data:text/html,
    <html><body>
      <form id="login">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <button type="submit">Sign In</button>
      </form>
    </body></html>"""
    browser.navigate(test_login_html)
    login_res = browser.login("test_portal")
    print("[PASS] Secure Login (Zero Password Leakage):", login_res["result"])
    assert login_res["success"] is True

    # 4. Form filling & validation
    test_form_html = """data:text/html,
    <html><body>
      <form id="reg">
        <input type="text" name="fname" placeholder="Full Name">
        <input type="email" name="email" placeholder="Email">
        <input type="tel" name="phone" placeholder="Phone">
        <button type="submit">Submit</button>
      </form>
    </body></html>"""
    browser.navigate(test_form_html)
    fill_res = browser.fill_form({"Full Name": "Rituraj", "Email": "rituraj@example.com", "Phone": "+919876543210"})
    print("[PASS] Form fill:", fill_res["result"])
    assert fill_res["success"] is True

    val_res = browser.validate_form()
    print("[PASS] Form validation:", val_res["data"]["is_valid"])
    assert val_res["data"]["is_valid"] is True

    # 5. Security confirmation requirement check
    req, prompt = SecurityPolicy.requires_confirmation("browser_submit", SecurityPolicy.AUTONOMY_SMART_AUTONOMY)
    print(f"[PASS] Submission Confirmation Gated: {req} (Prompt: '{prompt}')")
    assert req is True

    browser.close()


def run_whatsapp_tests():
    print("\n--- 3. WHATSAPP AGENT TESTS ---")
    
    # 1. Find contact
    res = whatsapp_agent.find_contact("Rahul")
    print("[PASS] Find Contact:", res["data"]["name"], res["data"]["phone"])
    assert res["success"] is True

    # 2. Receive incoming message & auto-reply
    incoming = "Rahul: Meeting confirmed for 11 AM tomorrow"
    reply = whatsapp_agent.handle_incoming_message("Rahul", "Meeting confirmed for 11 AM tomorrow", send_to_desktop=False)
    print("[PASS] Autonomous WhatsApp Handler:", reply)
    assert "action" in reply

    # 3. Read conversation
    conv = whatsapp_agent.get_conversation("Rahul", limit=5)
    print(f"[PASS] Read Conversation: {len(conv['data']['messages'])} messages loaded")
    assert conv["success"] is True

    # 4. Summarize conversation
    summ = whatsapp_agent.summarize_conversation("Rahul")
    print("[PASS] Conversation Summary:\n" + summ["data"]["summary"][:150] + "...")
    assert summ["success"] is True


def run_call_tests():
    print("\n--- 4. TELEPHONY & REALTIME CALL TESTS ---")
    
    # 1. Outgoing call initiation
    out_call = telephony.start_outgoing_call("Rahul", goal="Confirm project meeting")
    print("[PASS] Outgoing Call Triggered:", out_call["result"])
    assert out_call["success"] is True
    call_id = out_call["data"]["call_id"]

    # 2. Live conversation turn simulation
    session = session_manager.get_session(call_id)
    assert session is not None
    session.add_turn("caller", "Hello Rituraj?")
    session.add_turn("assistant", "Hello Rahul, this is MJ speaking on behalf of Sir Rituraj.")
    session.add_turn("caller", "Is the meeting confirmed for 11 AM?")
    session.add_turn("assistant", "Yes, the meeting is confirmed for 11 AM tomorrow.")

    # 3. End call & Summary generation
    end_call = telephony.end_call(call_id)
    print("[PASS] Call Ended & Summarized:\n", end_call["data"]["summary"])
    assert end_call["success"] is True
    assert "11 AM" in end_call["data"]["summary"]

    # 4. Inbound call identification & auto-answer check
    in_call = telephony.handle_incoming_call("+919999988888", "in_98765")
    print("[PASS] Inbound Call Handled:", in_call)
    assert in_call["action"] == "answer"
    assert in_call["caller"] == "Rahul"


def run_combined_cross_channel_workflow():
    print("\n--- 5. COMBINED MULTI-STEP CROSS-CHANNEL WORKFLOW ---")
    user_request = "Rahul ko WhatsApp karo aur agar free ho toh call karke meeting time decide karlo"
    print(f"Goal: '{user_request}'")

    plan = master_agent.planner.plan(user_request)
    print(f"[PASS] Master Agent Planned {len(plan.steps)} steps:")
    for s in plan.steps:
        print(f"  Step {s.step_id}: {s.description} (Tool: {s.tool})")
    assert len(plan.steps) >= 1

    # Check cross channel memory persistence
    context = conversation_manager.get_cross_channel_context("Rahul")
    print(f"[PASS] Cross Channel Unified Intelligence: Context Found = {context['found']}")
    print(f"  Contact: {context['contact']['name']}")
    print(f"  Latest Call: {context['latest_call_summary']['summary'][:60]}...")
    assert context["found"] is True
    assert context["latest_call_summary"] is not None


if __name__ == "__main__":
    print("=================================================================")
    print("      MJ AUTONOMOUS MULTI-CHANNEL AGENT - FULL VERIFICATION      ")
    print("=================================================================")
    run_computer_tests()
    run_website_tests()
    run_whatsapp_tests()
    run_call_tests()
    run_combined_cross_channel_workflow()
    print("\n=================================================================")
    print("  ALL SYSTEM TEST CASES PASSED SUCCESSFULLY WITH ZERO ERRORS!    ")
    print("=================================================================")
