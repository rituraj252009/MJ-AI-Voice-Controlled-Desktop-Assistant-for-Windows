import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.security.credentials import vault
from backend.security.policy import SecurityPolicy
from backend.memory.database import db
from backend.memory.contacts import contacts_manager
from backend.memory.conversations import conversation_manager
from backend.tools.whatsapp import whatsapp_agent


def test_vault():
    print("Testing Credential Vault...")
    vault.store_credential("college_portal", "rituraj_student", "SuperSecretPassword123!")
    services = vault.list_services()
    print("Stored services:", services)
    assert "college_portal" in services

    cred = vault.get_credential("college_portal")
    assert cred["username"] == "rituraj_student"
    assert cred["password"] == "SuperSecretPassword123!"
    assert vault.mask_text(cred["password"]) == "********"
    print("Vault test passed!")


def test_security_policy():
    print("\nTesting Security Policy...")
    assert SecurityPolicy.get_tool_risk("open_app") == "low"
    assert SecurityPolicy.get_tool_risk("delete_file") == "high"
    assert SecurityPolicy.get_tool_risk("browser_submit") == "high"

    req, prompt = SecurityPolicy.requires_confirmation("browser_submit", SecurityPolicy.AUTONOMY_SMART_AUTONOMY)
    print(f"browser_submit confirmation required: {req} (Prompt: '{prompt}')")
    assert req is True
    assert "submit" in prompt.lower() or "form" in prompt.lower()
    print("Security Policy test passed!")


def test_memory_and_contacts():
    print("\nTesting Contact and Conversation Memory...")
    # Add/Update contact
    c = contacts_manager.add_or_update_contact("TestUser", "+919123456789", "Beta tester", "FULL_AUTONOMY", auto_reply=True)
    assert c["name"] == "TestUser"
    assert c["phone"] == "+919123456789"

    # Record message
    msg_id = conversation_manager.record_message("TestUser", sender="contact", channel="whatsapp", content="Hey MJ, meeting at 5 PM?")
    assert msg_id > 0

    # Record call summary
    conversation_manager.record_call_summary("call_test_01", "TestUser", "Confirmed meeting at 5 PM on Google Meet", "Send calendar invite")

    # Get cross channel context
    ctx = conversation_manager.get_cross_channel_context("TestUser")
    print("Cross channel context:", ctx["found"])
    assert ctx["found"] is True
    assert len(ctx["recent_messages"]) > 0
    assert ctx["latest_call_summary"]["summary"] == "Confirmed meeting at 5 PM on Google Meet"
    print("Memory and Cross-Channel test passed!")


def test_whatsapp_agent():
    print("\nTesting WhatsApp Agent...")
    found = whatsapp_agent.find_contact("Rahul")
    print("Found Rahul:", found["success"])
    assert found["success"] is True

    # Test auto-reply evaluation
    reply_res = whatsapp_agent.handle_incoming_message("Rahul", "Hey bro, are you free?")
    print("Auto-reply response:", reply_res)
    assert "action" in reply_res
    print("WhatsApp Agent test passed!")


if __name__ == "__main__":
    print("=== RUNNING PHASE 7, 8, 9 TESTS ===")
    test_vault()
    test_security_policy()
    test_memory_and_contacts()
    test_whatsapp_agent()
    print("\n=== ALL PHASE 7, 8, 9 TESTS PASSED! ===")
