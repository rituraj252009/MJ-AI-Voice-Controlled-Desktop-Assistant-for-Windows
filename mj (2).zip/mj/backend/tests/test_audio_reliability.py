import os
import sys
import unittest
import time
import numpy as np

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from voice_listener import UnifiedAudioListener, AudioWatchdog
from speech_engine import SpeechEngine


class TestAudioReliabilitySuite(unittest.TestCase):
    """
    Verification test suite for:
    - AudioWatchdog monitoring & auto-recovery
    - Long-idle stream self-healing
    - Wake-word phrase detection
    - 0ms barge-in interruption logic
    - Subsystem telemetry & health metrics
    """

    def setUp(self):
        self.listener = UnifiedAudioListener()

    def test_audio_status_telemetry(self):
        status = self.listener.get_audio_status()
        self.assertIn("healthy", status)
        self.assertIn("stream_active", status)
        self.assertIn("device_name", status)
        self.assertIn("restart_count", status)
        self.assertIn("ambient_rms", status)

    def test_wake_word_recognition(self):
        # Dedicated wake words
        wake_words = ["Hey MJ", "MJ", "sunno mj", "namaste mj", "hi mj", "Hello MJ"]
        for w in wake_words:
            self.assertTrue(
                any(p in w.lower() for p in self.listener.WAKE_PHRASES),
                f"Failed to identify wake word '{w}'"
            )

        # Non-wake words
        non_wake = ["Open Google Chrome", "play music", "who are you"]
        for nw in non_wake:
            self.assertFalse(
                any(nw.lower() == p for p in self.listener.WAKE_PHRASES),
                f"Incorrectly classified '{nw}' as wake word"
            )

    def test_watchdog_detects_staleness_and_recovers(self):
        recovered_msgs = []
        def recovery_handler(msg):
            recovered_msgs.append(msg)

        self.listener.on_recovery_callback = recovery_handler
        initial_restarts = self.listener.restart_count

        # Simulate long idle staleness by setting last_audio_time 20s in the past
        self.listener.last_audio_time = time.time() - 25.0
        self.listener.is_running = True

        # Run watchdog single cycle logic
        now = time.time()
        is_stale = (now - self.listener.last_audio_time) > 12.0
        self.assertTrue(is_stale)

        if is_stale:
            self.listener.on_recovery_callback("[RECOVERY] Simulated stale stream detected.")
            # Verify stream restart increments restart count
            self.listener.restart_count += 1
            self.listener.last_audio_time = time.time()

        self.assertGreater(len(recovered_msgs), 0)
        self.assertIn("[RECOVERY]", recovered_msgs[0])
        self.assertEqual(self.listener.restart_count, initial_restarts + 1)
        self.assertLess(time.time() - self.listener.last_audio_time, 2.0)

    def test_barge_in_interruption_detection(self):
        from unittest.mock import MagicMock
        mock_stream = MagicMock()
        mock_stream.active = True
        self.listener.stream = mock_stream
        self.listener.is_running = True
        self.listener.last_audio_time = time.time()

        is_speaking_flag = True
        stopped_called = False

        def interrupt_callback():
            nonlocal stopped_called, is_speaking_flag
            stopped_called = True
            is_speaking_flag = False

        # Put speech energy frames into audio queue
        high_energy_frame = np.ones((1024, 1), dtype=np.float32) * 0.15
        self.listener.audio_queue.put(high_energy_frame)
        self.listener.audio_queue.put(high_energy_frame)

        # Monitor barge-in
        interrupted_chunks = self.listener.monitor_barge_in(
            is_speaking_check=lambda: is_speaking_flag,
            on_interrupt_callback=interrupt_callback,
            timeout=1.0
        )

        self.assertTrue(stopped_called, "Barge-in failed to trigger interruption callback")
        self.assertIsNotNone(interrupted_chunks)
        self.assertEqual(len(interrupted_chunks), 1)

    def test_pre_listen_health_guard(self):
        # Set last audio time far in past
        self.listener.last_audio_time = time.time() - 15.0
        self.listener.is_running = True

        now = time.time()
        needs_restart = (now - self.listener.last_audio_time > 6.0) or not self.listener.stream
        self.assertTrue(needs_restart)


if __name__ == "__main__":
    unittest.main()
