import os
import sys
import json
import logging
from aiohttp import web

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.tools import computer
from backend.tools import files

logging.basicConfig(level=logging.INFO, format="[%(asctime)s] [%(levelname)s] %(message)s")
logger = logging.getLogger("MJ_API")

# Enable CORS middleware
@web.middleware
async def cors_middleware(request, handler):
    if request.method == "OPTIONS":
        response = web.Response(status=200)
    else:
        try:
            response = await handler(request)
        except Exception as e:
            logger.error(f"Error handling {request.path}: {e}")
            response = web.json_response({"success": False, "error": str(e)}, status=500)
    
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-API-Key"
    return response


# ==================== Health & Status ====================
async def handle_health(request):
    return web.json_response({
        "status": "online",
        "service": "MJ Internal Tool Server",
        "version": "2.0.0"
    })


# ==================== Tool Endpoints ====================
async def handle_open_app(request):
    data = await request.json() if request.can_read_body else {}
    app_name = data.get("app") or data.get("app_name") or data.get("name") or ""
    res = computer.open_app(app_name)
    return web.json_response(res)


async def handle_close_app(request):
    data = await request.json() if request.can_read_body else {}
    app_name = data.get("app") or data.get("app_name") or None
    res = computer.close_app(app_name)
    return web.json_response(res)


async def handle_open_url(request):
    data = await request.json() if request.can_read_body else {}
    url = data.get("url") or ""
    res = computer.open_url(url)
    return web.json_response(res)


async def handle_search_web(request):
    data = await request.json() if request.can_read_body else {}
    query = data.get("query") or data.get("q") or ""
    res = computer.search_web(query)
    return web.json_response(res)


async def handle_click(request):
    data = await request.json() if request.can_read_body else {}
    x = data.get("x")
    y = data.get("y")
    button = data.get("button", "left")
    res = computer.click(x, y, button)
    return web.json_response(res)


async def handle_type(request):
    data = await request.json() if request.can_read_body else {}
    text = data.get("text") or ""
    press_enter = bool(data.get("enter") or data.get("press_enter", False))
    res = computer.type_text(text, press_enter=press_enter)
    return web.json_response(res)


async def handle_screenshot(request):
    data = await request.json() if request.can_read_body else {}
    save_path = data.get("path")
    res = computer.screenshot(save_path)
    return web.json_response(res)


async def handle_read_screen(request):
    res = computer.read_screen()
    return web.json_response(res)


async def handle_system_stats(request):
    res = computer.get_system_stats()
    return web.json_response(res)


async def handle_battery(request):
    res = computer.get_battery()
    return web.json_response(res)


async def handle_volume(request):
    data = await request.json() if request.can_read_body else {}
    level = data.get("level")
    if level is not None:
        res = computer.set_volume(int(level))
    else:
        res = computer.mute_volume()
    return web.json_response(res)


async def handle_run_command(request):
    data = await request.json() if request.can_read_body else {}
    cmd = data.get("command") or data.get("cmd") or ""
    res = computer.run_safe_command(cmd)
    return web.json_response(res)


async def handle_generic_tool(request):
    """Universal dispatcher for n8n tool router."""
    data = await request.json() if request.can_read_body else {}
    tool_name = data.get("tool") or ""
    params = data.get("params") or {}

    tool_map = {
        "open_app": lambda p: computer.open_app(p.get("app") or p.get("app_name", "")),
        "close_app": lambda p: computer.close_app(p.get("app")),
        "open_url": lambda p: computer.open_url(p.get("url", "")),
        "search_web": lambda p: computer.search_web(p.get("query", "")),
        "play_youtube": lambda p: computer.play_youtube(p.get("query", "")),
        "click": lambda p: computer.click(p.get("x"), p.get("y"), p.get("button", "left")),
        "double_click": lambda p: computer.double_click(p.get("x"), p.get("y")),
        "type_text": lambda p: computer.type_text(p.get("text", ""), p.get("enter", False)),
        "press_key": lambda p: computer.press_key(p.get("key", "")),
        "hotkey": lambda p: computer.hotkey(p.get("keys", "")),
        "scroll": lambda p: computer.scroll(p.get("direction", "down"), p.get("amount", 500)),
        "screenshot": lambda p: computer.screenshot(p.get("path")),
        "read_screen": lambda p: computer.read_screen(),
        "find_on_screen": lambda p: computer.find_on_screen(p.get("template", ""), p.get("confidence", 0.8)),
        "run_safe_command": lambda p: computer.run_safe_command(p.get("command", "")),
        "set_volume": lambda p: computer.set_volume(int(p.get("level", 50))),
        "mute_volume": lambda p: computer.mute_volume(),
        "get_battery": lambda p: computer.get_battery(),
        "get_system_stats": lambda p: computer.get_system_stats(),
        "open_file": lambda p: files.open_file(p.get("file", "")),
        "open_folder": lambda p: files.open_folder(p.get("folder", "")),
        "create_folder": lambda p: files.create_folder(p.get("folder", "")),
        "delete_folder": lambda p: files.delete_folder(p.get("folder", "")),
        "rename_folder": lambda p: files.rename_folder(p.get("old", ""), p.get("new", "")),
        "create_file": lambda p: files.create_file(p.get("file", ""), p.get("content", "")),
        "delete_file": lambda p: files.delete_file(p.get("file", "")),
        "rename_file": lambda p: files.rename_file(p.get("old", ""), p.get("new", "")),
        "read_file_content": lambda p: files.read_file_content(p.get("file", ""))
    }

    if tool_name not in tool_map:
        return web.json_response({"success": False, "error": f"Unknown tool: '{tool_name}'"}, status=400)

    try:
        result = tool_map[tool_name](params)
        return web.json_response(result)
    except Exception as e:
        return web.json_response({"success": False, "tool": tool_name, "error": str(e)}, status=500)


def create_app():
    app = web.Application(middlewares=[cors_middleware])
    app.router.add_get("/health", handle_health)
    app.router.add_post("/tools/open-app", handle_open_app)
    app.router.add_post("/tools/close-app", handle_close_app)
    app.router.add_post("/tools/open-url", handle_open_url)
    app.router.add_post("/tools/search-web", handle_search_web)
    app.router.add_post("/tools/click", handle_click)
    app.router.add_post("/tools/type", handle_type)
    app.router.add_post("/tools/screenshot", handle_screenshot)
    app.router.add_post("/tools/read-screen", handle_read_screen)
    app.router.add_post("/tools/system-stats", handle_system_stats)
    app.router.add_post("/tools/battery", handle_battery)
    app.router.add_post("/tools/volume", handle_volume)
    app.router.add_post("/tools/run-command", handle_run_command)
    app.router.add_post("/tools/execute", handle_generic_tool)
    return app


if __name__ == "__main__":
    port = int(os.getenv("MJ_BACKEND_PORT", 8000))
    host = os.getenv("MJ_BACKEND_HOST", "127.0.0.1")
    logger.info(f"Starting MJ Internal Tool API on http://{host}:{port}")
    app = create_app()
    web.run_app(app, host=host, port=port)
