import os
import sys
import time
import logging
from typing import Dict, Any, Optional

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.tools.computer import tool_response
from backend.memory.contacts import contacts_manager
from backend.memory.conversations import conversation_manager
from voice.session_manager import session_manager
import config

logger = logging.getLogger("MJ_Telephony")


class TelephonyConnector:
    """
    Telephony Integration Connector supporting India-compatible providers
    (Exotel / Twilio / custom SIP gateway).
    Initiates outbound calls and manages inbound webhooks connecting to the
    realtime voice WebSocket server.
    """
    def __init__(self):
        self.account_id = os.getenv("TELEPHONY_ACCOUNT_ID", "")
        self.api_key = os.getenv("TELEPHONY_API_KEY", "")
        self.voice_server_ws = os.getenv("VOICE_WS_URL", "ws://127.0.0.1:8765/voice/stream")

    def start_outgoing_call(self, contact_name: str, phone_number: Optional[str] = None, goal: str = "") -> Dict[str, Any]:
        """
        Initiates an outbound phone call.
        Connects target's phone to the Realtime Voice Server.
        """
        # Resolve contact
        contact = contacts_manager.find_contact(contact_name)
        target_phone = phone_number or (contact["phone"] if contact else None)

        if not target_phone:
            return tool_response("make_call", False, error=f"Could not find phone number for '{contact_name}'")

        call_id = f"out_call_{int(time.time() * 1000)}"

        # If configured with real provider (Exotel/Twilio API), dispatch call
        # Here we simulate or trigger via telephony webhook
        logger.info(f"Initiating outbound call to {contact_name} ({target_phone}) for goal: '{goal}'")

        # Record in memory database
        session = session_manager.create_session(call_id, phone=target_phone, name=contact_name, direction="outbound")
        conversation_manager.record_call(
            call_id=call_id,
            contact_name=contact_name,
            phone=target_phone,
            direction="outbound",
            status="ringing"
        )

        return tool_response("make_call", True, result=f"Dialing {contact_name} at {target_phone}...", data={
            "call_id": call_id,
            "contact": contact_name,
            "phone": target_phone,
            "websocket": self.voice_server_ws
        })

    def handle_incoming_call(self, caller_phone: str, call_sid: str) -> Dict[str, Any]:
        """
        Handles incoming telephony webhook:
        1. Identifies caller from memory
        2. Checks contact autonomy (auto-answer policy)
        3. Generates telephony response bridging call to WebSocket
        """
        contact = contacts_manager.find_contact(caller_phone)
        caller_name = contact["name"] if contact else caller_phone
        auto_answer = contact.get("auto_answer", 1) if contact else 0

        logger.info(f"Incoming call from {caller_name} ({caller_phone}). Auto-answer: {auto_answer}")

        # Record incoming call
        session = session_manager.create_session(call_sid, phone=caller_phone, name=caller_name, direction="inbound")
        conversation_manager.record_call(
            call_id=call_sid,
            contact_name=caller_name,
            phone=caller_phone,
            direction="inbound",
            status="in-progress"
        )

        # Return TwiML or Exotel response XML/JSON directing media to WebSocket
        return {
            "action": "answer" if auto_answer else "reject",
            "caller": caller_name,
            "stream_url": self.voice_server_ws,
            "session_id": call_sid
        }

    def end_call(self, call_id: str) -> Dict[str, Any]:
        summary_info = session_manager.close_session(call_id)
        return tool_response("end_call", True, result="Call ended", data=summary_info or {})


# Global singleton instance
telephony = TelephonyConnector()
