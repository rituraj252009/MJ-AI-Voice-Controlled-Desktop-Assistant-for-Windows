import os
import sys
import time
import subprocess
import webbrowser
from typing import Dict, Any, Optional

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import pyautogui
from terminal_controller import controller as terminal_controller
from app_automator import automator


def tool_response(tool_name: str, success: bool, result: str = "", data: Optional[Dict[str, Any]] = None, error: Optional[str] = None) -> Dict[str, Any]:
    """Generates structured response format required for all MJ tools."""
    resp = {
        "success": success,
        "tool": tool_name,
        "result": result or (error if not success else "Executed successfully"),
        "data": data or {}
    }
    if error:
        resp["error"] = error
    return resp


def open_app(app_name: str) -> Dict[str, Any]:
    """Launches desktop application by name or alias with automatic verification."""
    try:
        if not app_name or not app_name.strip():
            return tool_response("open_app", False, error="App name is required")
        res = terminal_controller.open_application(app_name.strip())
        return tool_response("open_app", True, result=res, data={"app": app_name})
    except Exception as e:
        return tool_response("open_app", False, error=str(e))


def close_app(app_name: Optional[str] = None) -> Dict[str, Any]:
    """Closes target application or current foreground application."""
    try:
        if app_name:
            # Use PowerShell stop-process
            safe_name = app_name.replace("'", "").replace('"', '').strip()
            ps_script = f"Get-Process | Where-Object {{ $_.ProcessName -like '*{safe_name}*' -or $_.MainWindowTitle -like '*{safe_name}*' }} | Stop-Process -Force"
            terminal_controller.run_powershell(ps_script)
            return tool_response("close_app", True, result=f"Closed application '{app_name}'", data={"app": app_name})
        else:
            res = automator.in_app_window_control("close_tab")
            return tool_response("close_app", True, result=res)
    except Exception as e:
        return tool_response("close_app", False, error=str(e))


def search_web(query: str) -> Dict[str, Any]:
    """Searches Google in default browser."""
    try:
        if not query:
            return tool_response("search_web", False, error="Search query is required")
        res = terminal_controller.search_google(query)
        return tool_response("search_web", True, result=res, data={"query": query})
    except Exception as e:
        return tool_response("search_web", False, error=str(e))


def open_url(url: str) -> Dict[str, Any]:
    """Opens a website URL in default browser."""
    try:
        if not url:
            return tool_response("open_url", False, error="URL is required")
        target = url.strip()
        if not target.startswith("http://") and not target.startswith("https://"):
            target = "https://" + target
        webbrowser.open(target)
        return tool_response("open_url", True, result=f"Opened URL: {target}", data={"url": target})
    except Exception as e:
        return tool_response("open_url", False, error=str(e))


def play_youtube(query: str) -> Dict[str, Any]:
    """Searches and plays media on YouTube."""
    try:
        res = terminal_controller.play_youtube(query)
        return tool_response("play_youtube", True, result=res, data={"query": query})
    except Exception as e:
        return tool_response("play_youtube", False, error=str(e))


def click(x: Optional[int] = None, y: Optional[int] = None, button: str = "left") -> Dict[str, Any]:
    """Clicks mouse at specified coordinates or current mouse location."""
    try:
        if x is not None and y is not None:
            pyautogui.click(x=x, y=y, button=button)
            return tool_response("click", True, result=f"Clicked {button} at ({x}, {y})", data={"x": x, "y": y, "button": button})
        else:
            pyautogui.click(button=button)
            cur_x, cur_y = pyautogui.position()
            return tool_response("click", True, result=f"Clicked {button} at current position ({cur_x}, {cur_y})", data={"x": cur_x, "y": cur_y, "button": button})
    except Exception as e:
        return tool_response("click", False, error=str(e))


def double_click(x: Optional[int] = None, y: Optional[int] = None) -> Dict[str, Any]:
    """Double clicks mouse at specified coordinates or current mouse location."""
    try:
        if x is not None and y is not None:
            pyautogui.doubleClick(x=x, y=y)
            return tool_response("double_click", True, result=f"Double clicked at ({x}, {y})", data={"x": x, "y": y})
        else:
            pyautogui.doubleClick()
            cur_x, cur_y = pyautogui.position()
            return tool_response("double_click", True, result=f"Double clicked at ({cur_x}, {cur_y})", data={"x": cur_x, "y": cur_y})
    except Exception as e:
        return tool_response("double_click", False, error=str(e))


def type_text(text: str, press_enter: bool = False) -> Dict[str, Any]:
    """Types text into currently focused application via clipboard pasting."""
    try:
        res = automator.type_in_active_window(text, press_enter=press_enter)
        return tool_response("type_text", True, result=res, data={"text_length": len(text), "enter": press_enter})
    except Exception as e:
        return tool_response("type_text", False, error=str(e))


def press_key(key_name: str) -> Dict[str, Any]:
    """Presses a single key (e.g. 'enter', 'tab', 'esc', 'backspace')."""
    try:
        res = automator.press_key(key_name)
        return tool_response("press_key", True, result=res, data={"key": key_name})
    except Exception as e:
        return tool_response("press_key", False, error=str(e))


def hotkey(keys: str) -> Dict[str, Any]:
    """Triggers hotkey combination (e.g. 'ctrl+c', 'alt+tab', 'win+d')."""
    try:
        res = automator.execute_hotkey(keys)
        return tool_response("hotkey", True, result=res, data={"keys": keys})
    except Exception as e:
        return tool_response("hotkey", False, error=str(e))


def scroll(direction: str = "down", amount: int = 500) -> Dict[str, Any]:
    """Scrolls active window up or down."""
    try:
        res = automator.scroll(direction=direction, amount=amount)
        return tool_response("scroll", True, result=res, data={"direction": direction, "amount": amount})
    except Exception as e:
        return tool_response("scroll", False, error=str(e))


def screenshot(save_path: Optional[str] = None) -> Dict[str, Any]:
    """Captures screenshot and returns file path."""
    try:
        if not save_path:
            desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            save_path = os.path.join(desktop_dir, f"MJ_Screenshot_{timestamp}.png")
        
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        try:
            img = pyautogui.screenshot()
            img.save(save_path)
            return tool_response("screenshot", True, result=f"Screenshot saved to {save_path}", data={"path": save_path, "size": img.size})
        except Exception:
            # Fallback to Windows PowerShell .NET GDI capture
            res = terminal_controller.take_screenshot()
            return tool_response("screenshot", True, result=res, data={"path": save_path})
    except Exception as e:
        return tool_response("screenshot", False, error=str(e))


def read_screen() -> Dict[str, Any]:
    """Reads current screen state including active window title, context, and resolution."""
    try:
        title = automator.get_active_window_title()
        ctx = automator.get_context()
        screen_w, screen_h = pyautogui.size()
        cur_x, cur_y = pyautogui.position()
        return tool_response("read_screen", True, result=f"Foreground window: '{title}'", data={
            "active_window": title,
            "context": ctx,
            "resolution": {"width": screen_w, "height": screen_h},
            "mouse_position": {"x": cur_x, "y": cur_y}
        })
    except Exception as e:
        return tool_response("read_screen", False, error=str(e))


def find_on_screen(image_template_path: str, confidence: float = 0.8) -> Dict[str, Any]:
    """Locates visual template on screen and returns bounding box coordinates."""
    try:
        if not os.path.exists(image_template_path):
            return tool_response("find_on_screen", False, error=f"Template image not found: {image_template_path}")
        location = pyautogui.locateOnScreen(image_template_path, confidence=confidence)
        if location:
            center = pyautogui.center(location)
            return tool_response("find_on_screen", True, result="Element located on screen", data={
                "box": {"left": location.left, "top": location.top, "width": location.width, "height": location.height},
                "center": {"x": center.x, "y": center.y}
            })
        return tool_response("find_on_screen", False, error="Element not found on screen")
    except Exception as e:
        return tool_response("find_on_screen", False, error=str(e))


def run_safe_command(command: str) -> Dict[str, Any]:
    """Executes safe PowerShell command and returns stdout, stderr, and returncode."""
    try:
        # Check command against blocked dangerous operations
        lower_cmd = command.lower()
        blocked = ["format ", "del /f /s /q c:", "rmdir /s /q c:", "reg delete", "diskpart"]
        if any(b in lower_cmd for b in blocked):
            return tool_response("run_safe_command", False, error="Command blocked by security policy: destructive operation")

        res = terminal_controller.run_powershell(command)
        return tool_response("run_safe_command", res["success"], result=res["stdout"] or res["stderr"], data=res)
    except Exception as e:
        return tool_response("run_safe_command", False, error=str(e))


def set_volume(level: int) -> Dict[str, Any]:
    """Sets master volume percentage (0 to 100)."""
    try:
        res = terminal_controller.set_volume(level)
        return tool_response("set_volume", True, result=res, data={"level": level})
    except Exception as e:
        return tool_response("set_volume", False, error=str(e))


def mute_volume() -> Dict[str, Any]:
    """Mutes or unmutes system audio."""
    try:
        res = terminal_controller.mute_volume()
        return tool_response("mute_volume", True, result=res)
    except Exception as e:
        return tool_response("mute_volume", False, error=str(e))


def get_battery() -> Dict[str, Any]:
    """Queries laptop battery status and charge percentage."""
    try:
        res = terminal_controller.get_battery_status()
        return tool_response("get_battery", True, result=res)
    except Exception as e:
        return tool_response("get_battery", False, error=str(e))


def get_system_stats() -> Dict[str, Any]:
    """Queries CPU and Memory utilization."""
    try:
        res = terminal_controller.get_system_stats()
        return tool_response("get_system_stats", True, result=res)
    except Exception as e:
        return tool_response("get_system_stats", False, error=str(e))
