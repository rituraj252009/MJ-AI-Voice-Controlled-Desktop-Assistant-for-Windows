import os
import sys
import time
import logging
from typing import Dict, Any, Optional, List

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.tools.computer import tool_response
from backend.security.credentials import vault

logger = logging.getLogger("MJ_BrowserAgent")

try:
    from playwright.sync_api import sync_playwright, Page, Browser, BrowserContext
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False


class WebBrowserAgent:
    """
    Dedicated Web Automation Agent powered by Playwright.
    Understands DOM structure, CSS/XPath selectors, semantic form fields,
    and handles secure credentials injection.
    """
    def __init__(self, headless: bool = False):
        self.headless = headless
        self._pw = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None

    def _ensure_browser(self):
        """Lazily initializes browser instance."""
        if not PLAYWRIGHT_AVAILABLE:
            raise RuntimeError("Playwright is not installed. Run 'pip install playwright && playwright install chromium'")

        if self._page and not self._page.is_closed():
            return

        if not self._pw:
            self._pw = sync_playwright().start()

        if not self._browser:
            try:
                self._browser = self._pw.chromium.launch(headless=self.headless)
            except Exception as e:
                logger.warning(f"Chromium launch failed ({e}), falling back to system browser channel")
                self._browser = self._pw.chromium.launch(headless=self.headless, channel="chrome")

        if not self._context:
            self._context = self._browser.new_context(viewport={"width": 1280, "height": 800})

        self._page = self._context.new_page()

    def navigate(self, url: str) -> Dict[str, Any]:
        """Navigates to specified URL."""
        try:
            self._ensure_browser()
            target = url.strip()
            if not (target.startswith("http://") or target.startswith("https://") or target.startswith("data:") or target.startswith("file://")):
                target = "https://" + target
            self._page.goto(target, wait_until="domcontentloaded", timeout=30000)
            title = self._page.title()
            return tool_response("browser_navigate", True, result=f"Navigated to '{title}' ({target})", data={"url": target, "title": title})
        except Exception as e:
            return tool_response("browser_navigate", False, error=str(e))

    def inspect_page(self) -> Dict[str, Any]:
        """Understands DOM structure and extracts interactive form fields, buttons, and titles."""
        try:
            self._ensure_browser()
            title = self._page.title()
            url = self._page.url

            # Extract interactive inputs
            inputs_info = self._page.evaluate("""() => {
                const results = [];
                const elements = document.querySelectorAll('input, textarea, select');
                elements.forEach((el, index) => {
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0 && el.type !== 'hidden') {
                        results.push({
                            index: index,
                            tag: el.tagName.toLowerCase(),
                            type: el.type || 'text',
                            name: el.name || '',
                            id: el.id || '',
                            placeholder: el.placeholder || '',
                            value: el.type === 'password' ? '***' : (el.value || ''),
                            label: el.labels && el.labels[0] ? el.labels[0].innerText.trim() : ''
                        });
                    }
                });
                return results;
            }""")

            buttons_info = self._page.evaluate("""() => {
                const btns = [];
                document.querySelectorAll('button, input[type="submit"], a[role="button"]').forEach(b => {
                    const text = (b.innerText || b.value || '').trim();
                    if (text) btns.push(text);
                });
                return btns.slice(0, 10);
            }""")

            return tool_response("browser_inspect", True, result=f"Inspected page '{title}' with {len(inputs_info)} interactive inputs", data={
                "title": title,
                "url": url,
                "inputs": inputs_info,
                "buttons": buttons_info
            })
        except Exception as e:
            return tool_response("browser_inspect", False, error=str(e))

    def read_page(self) -> Dict[str, Any]:
        """Extracts visible text content from page."""
        try:
            self._ensure_browser()
            text_content = self._page.evaluate("() => document.body.innerText")
            # Truncate to first 3000 characters
            snippet = text_content[:3000].strip()
            return tool_response("browser_read", True, result=f"Read {len(text_content)} characters", data={"content": snippet})
        except Exception as e:
            return tool_response("browser_read", False, error=str(e))

    def click_element(self, selector: str) -> Dict[str, Any]:
        """Clicks element matching CSS selector, XPath, or text."""
        try:
            self._ensure_browser()
            # Try selector or text match
            if selector.startswith("//") or selector.startswith("#") or selector.startswith("."):
                self._page.click(selector, timeout=10000)
            else:
                self._page.click(f"text={selector}", timeout=10000)
            return tool_response("browser_click", True, result=f"Clicked element '{selector}'", data={"selector": selector})
        except Exception as e:
            return tool_response("browser_click", False, error=str(e))

    def type_text(self, selector: str, value: str) -> Dict[str, Any]:
        """Fills input field."""
        try:
            self._ensure_browser()
            self._page.fill(selector, value, timeout=10000)
            return tool_response("browser_fill", True, result=f"Filled field '{selector}'", data={"selector": selector})
        except Exception as e:
            return tool_response("browser_fill", False, error=str(e))

    def select_option(self, selector: str, value: str) -> Dict[str, Any]:
        """Selects dropdown option."""
        try:
            self._ensure_browser()
            self._page.select_option(selector, label=value)
            return tool_response("browser_select", True, result=f"Selected '{value}' in '{selector}'")
        except Exception as e:
            return tool_response("browser_select", False, error=str(e))

    def screenshot(self, path: Optional[str] = None) -> Dict[str, Any]:
        """Captures page screenshot."""
        try:
            self._ensure_browser()
            if not path:
                desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop")
                path = os.path.join(desktop_dir, f"MJ_Web_{int(time.time())}.png")
            self._page.screenshot(path=path)
            return tool_response("browser_screenshot", True, result=f"Screenshot saved to {path}", data={"path": path})
        except Exception as e:
            return tool_response("browser_screenshot", False, error=str(e))

    def login(self, service_key: str) -> Dict[str, Any]:
        """
        Securely logs into a website using credentials from the vault.
        NEVER outputs or logs the password.
        """
        try:
            cred = vault.get_credential(service_key)
            if not cred:
                return tool_response("browser_login", False, error=f"No stored credentials found for service '{service_key}' in vault")

            self._ensure_browser()
            username = cred["username"]
            password = cred["password"]

            # Smart DOM locator for username and password fields
            user_selectors = [
                "input[type='email']", "input[name*='user']", "input[name*='email']",
                "input[id*='user']", "input[id*='email']", "input[placeholder*='Email']",
                "input[placeholder*='Username']", "input[type='text']"
            ]
            pass_selectors = [
                "input[type='password']", "input[name*='pass']", "input[id*='pass']"
            ]

            user_filled = False
            for sel in user_selectors:
                if self._page.locator(sel).count() > 0:
                    self._page.fill(sel, username)
                    user_filled = True
                    break

            pass_filled = False
            for sel in pass_selectors:
                if self._page.locator(sel).count() > 0:
                    self._page.fill(sel, password)
                    pass_filled = True
                    break

            if not (user_filled and pass_filled):
                return tool_response("browser_login", False, error="Could not locate username/password fields on the page")

            # Check for CAPTCHA or OTP
            has_captcha = self._page.evaluate("""() => {
                return !!document.querySelector('.g-recaptcha, .h-captcha, iframe[src*="recaptcha"], iframe[src*="hcaptcha"]');
            }""")

            if has_captcha:
                return tool_response("browser_login", True, result="Credentials filled. CAPTCHA detected - please solve the CAPTCHA to complete login.", data={"captcha_required": True})

            # Click submit/login button
            submit_selectors = ["button[type='submit']", "input[type='submit']", "button:has-text('Login')", "button:has-text('Sign In')", "button:has-text('Submit')"]
            for s in submit_selectors:
                if self._page.locator(s).count() > 0:
                    try:
                        self._page.click(s, timeout=5000, no_wait_after=True)
                    except Exception:
                        pass
                    break

            time.sleep(1.0)
            return tool_response("browser_login", True, result=f"Credentials injected and submitted for '{service_key}'", data={"service": service_key, "user": username})
        except Exception as e:
            return tool_response("browser_login", False, error=str(e))

    def fill_form(self, form_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fills form fields using structured data (e.g. name, email, phone, college, course).
        Uses intelligent semantic matching across labels, names, and placeholders.
        """
        try:
            self._ensure_browser()
            filled_count = 0

            for key, val in form_data.items():
                if not val:
                    continue
                k_lower = key.lower()

                # Build candidate selectors
                candidates = [
                    f"input[name*='{k_lower}']",
                    f"input[id*='{k_lower}']",
                    f"input[placeholder*='{key}']",
                    f"input[aria-label*='{key}']",
                    f"textarea[name*='{k_lower}']"
                ]

                # Special mappings
                if "name" in k_lower:
                    candidates.insert(0, "input[name*='fname']")
                    candidates.insert(0, "input[autocomplete='name']")
                elif "email" in k_lower:
                    candidates.insert(0, "input[type='email']")
                elif "phone" in k_lower or "mobile" in k_lower:
                    candidates.insert(0, "input[type='tel']")
                    candidates.insert(0, "input[name*='mobile']")

                matched = False
                for c in candidates:
                    try:
                        loc = self._page.locator(c)
                        if loc.count() > 0 and loc.first.is_visible():
                            loc.first.fill(str(val))
                            filled_count += 1
                            matched = True
                            break
                    except Exception:
                        pass

            return tool_response("browser_form_fill", True, result=f"Filled {filled_count} form fields matching user information", data={"fields_matched": filled_count})
        except Exception as e:
            return tool_response("browser_form_fill", False, error=str(e))

    def validate_form(self) -> Dict[str, Any]:
        """Checks if form fields have errors or missing required inputs."""
        try:
            self._ensure_browser()
            validation = self._page.evaluate("""() => {
                const errors = [];
                const requiredInputs = document.querySelectorAll('input[required], select[required], textarea[required]');
                requiredInputs.forEach(el => {
                    if (!el.value || el.value.trim() === '') {
                        errors.push({
                            field: el.name || el.id || 'Unknown',
                            issue: 'Required field is empty'
                        });
                    }
                });
                return {
                    is_valid: errors.length === 0,
                    errors: errors
                };
            }""")
            return tool_response("browser_validate_form", True, result="Form validation checked", data=validation)
        except Exception as e:
            return tool_response("browser_validate_form", False, error=str(e))

    def submit_form(self, submit_selector: Optional[str] = None) -> Dict[str, Any]:
        """Submits the active form."""
        try:
            self._ensure_browser()
            if submit_selector:
                self._page.click(submit_selector, timeout=5000, no_wait_after=True)
            else:
                selectors = ["button[type='submit']", "input[type='submit']", "button:has-text('Submit')", "button:has-text('Register')"]
                clicked = False
                for s in selectors:
                    loc = self._page.locator(s)
                    if loc.count() > 0 and loc.first.is_visible():
                        loc.first.click(timeout=5000, no_wait_after=True)
                        clicked = True
                        break
                if not clicked:
                    self._page.keyboard.press("Enter")
            
            time.sleep(1.0)
            return tool_response("browser_submit", True, result="Form submitted successfully", data={"url": self._page.url})
        except Exception as e:
            return tool_response("browser_submit", False, error=str(e))

    def close(self):
        """Closes browser session."""
        try:
            if self._page:
                self._page.close()
            if self._context:
                self._context.close()
            if self._browser:
                self._browser.close()
            if self._pw:
                self._pw.stop()
        except Exception:
            pass


# Global singleton instance
browser = WebBrowserAgent()
