import os
import sys
from typing import Dict, Any, Optional

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from terminal_controller import controller as terminal_controller
from app_automator import automator
from backend.tools.computer import tool_response


def open_file(file_name: str) -> Dict[str, Any]:
    """Finds and opens a document or file across system directories."""
    try:
        if not file_name:
            return tool_response("open_file", False, error="File name is required")
        res = terminal_controller.open_file(file_name)
        return tool_response("open_file", True, result=res, data={"file": file_name})
    except Exception as e:
        return tool_response("open_file", False, error=str(e))


def open_folder(folder_name: str) -> Dict[str, Any]:
    """Finds and opens a directory in Windows File Explorer."""
    try:
        if not folder_name:
            return tool_response("open_folder", False, error="Folder name is required")
        res = terminal_controller.open_folder(folder_name)
        return tool_response("open_folder", True, result=res, data={"folder": folder_name})
    except Exception as e:
        return tool_response("open_folder", False, error=str(e))


def create_folder(folder_name: str) -> Dict[str, Any]:
    """Creates a new directory in Desktop, Documents, or active context path."""
    try:
        if not folder_name:
            folder_name = "New Folder"
        res = terminal_controller.create_folder(folder_name)
        return tool_response("create_folder", True, result=res, data={"folder": folder_name})
    except Exception as e:
        return tool_response("create_folder", False, error=str(e))


def delete_folder(folder_name: str) -> Dict[str, Any]:
    """Deletes target directory."""
    try:
        if not folder_name:
            return tool_response("delete_folder", False, error="Folder name is required")
        res = terminal_controller.delete_folder(folder_name)
        return tool_response("delete_folder", True, result=res, data={"folder": folder_name})
    except Exception as e:
        return tool_response("delete_folder", False, error=str(e))


def rename_folder(old_name: str, new_name: str) -> Dict[str, Any]:
    """Renames target directory."""
    try:
        if not old_name or not new_name:
            return tool_response("rename_folder", False, error="Both old and new folder names are required")
        res = terminal_controller.rename_folder(old_name, new_name)
        return tool_response("rename_folder", True, result=res, data={"old": old_name, "new": new_name})
    except Exception as e:
        return tool_response("rename_folder", False, error=str(e))


def create_file(file_name: str, initial_content: str = "") -> Dict[str, Any]:
    """Creates a new document or text file."""
    try:
        if not file_name:
            file_name = "New Document.txt"
        res = terminal_controller.create_file(file_name)
        if initial_content:
            found = automator._find_file(file_name)
            if found:
                with open(found, "w", encoding="utf-8") as f:
                    f.write(initial_content)
        return tool_response("create_file", True, result=res, data={"file": file_name})
    except Exception as e:
        return tool_response("create_file", False, error=str(e))


def delete_file(file_name: str) -> Dict[str, Any]:
    """Deletes target file from disk."""
    try:
        if not file_name:
            return tool_response("delete_file", False, error="File name is required")
        res = terminal_controller.delete_file(file_name)
        return tool_response("delete_file", True, result=res, data={"file": file_name})
    except Exception as e:
        return tool_response("delete_file", False, error=str(e))


def rename_file(old_name: str, new_name: str) -> Dict[str, Any]:
    """Renames target file."""
    try:
        if not old_name or not new_name:
            return tool_response("rename_file", False, error="Both old and new file names are required")
        res = terminal_controller.rename_file(old_name, new_name)
        return tool_response("rename_file", True, result=res, data={"old": old_name, "new": new_name})
    except Exception as e:
        return tool_response("rename_file", False, error=str(e))


def read_file_content(file_name: str) -> Dict[str, Any]:
    """Reads content of a text file."""
    try:
        found = automator._find_file(file_name)
        if not found or not os.path.exists(found):
            return tool_response("read_file_content", False, error=f"File not found: {file_name}")
        with open(found, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        return tool_response("read_file_content", True, result=f"Read {len(content)} characters from {file_name}", data={"path": found, "content": content})
    except Exception as e:
        return tool_response("read_file_content", False, error=str(e))
