import os
import sys
import logging
from typing import Dict, Any, Optional

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app_automator import automator
from backend.tools.computer import tool_response
from backend.memory.contacts import contacts_manager
from backend.memory.conversations import conversation_manager
import config

logger = logging.getLogger("MJ_WhatsAppAgent")


class WhatsAppAgent:
    """
    WhatsApp Communication Agent.
    Manages contact lookup, message sending, file sharing,
    call triggering, conversation memory, and autonomous auto-reply.
    """
    def find_contact(self, contact_query: str) -> Dict[str, Any]:
        contact = contacts_manager.find_contact(contact_query)
        if contact:
            return tool_response("find_contact", True, result=f"Found contact {contact['name']}", data=contact)
        return tool_response("find_contact", False, error=f"Contact '{contact_query}' not found")

    def send_message(self, contact_name: str, message: str) -> Dict[str, Any]:
        """Sends WhatsApp message via desktop automator and records in persistent memory."""
        try:
            if not contact_name or not message:
                return tool_response("send_whatsapp", False, error="Both contact and message are required")

            # Check contact alias
            contact = contacts_manager.find_contact(contact_name)
            target = contact["name"] if contact else contact_name

            res = automator.send_whatsapp_message(target, message)

            # Record in cross-channel memory
            conversation_manager.record_message(target, sender="mj", channel="whatsapp", content=message)

            return tool_response("send_whatsapp", True, result=res, data={"contact": target, "message": message})
        except Exception as e:
            return tool_response("send_whatsapp", False, error=str(e))

    def send_file(self, contact_name: str, file_path_or_query: str) -> Dict[str, Any]:
        """Sends file to contact."""
        try:
            res = automator.send_file_whatsapp(contact_name, file_path_or_query)
            conversation_manager.record_message(contact_name, sender="mj", channel="whatsapp", content=f"[Sent File: {file_path_or_query}]")
            return tool_response("send_file_whatsapp", True, result=res)
        except Exception as e:
            return tool_response("send_file_whatsapp", False, error=str(e))

    def start_call(self, contact_name: str, call_type: str = "voice") -> Dict[str, Any]:
        """Initiates voice or video call on WhatsApp Desktop."""
        try:
            res = automator.whatsapp_call(contact_name, call_type=call_type)
            return tool_response("whatsapp_call", True, result=res, data={"contact": contact_name, "type": call_type})
        except Exception as e:
            return tool_response("whatsapp_call", False, error=str(e))

    def get_conversation(self, contact_name: str, limit: int = 10) -> Dict[str, Any]:
        """Retrieves stored conversation history for contact."""
        try:
            msgs = conversation_manager.get_recent_messages(contact_name, limit=limit)
            return tool_response("get_conversation", True, result=f"Retrieved {len(msgs)} messages", data={"messages": msgs})
        except Exception as e:
            return tool_response("get_conversation", False, error=str(e))

    def summarize_conversation(self, contact_name: str) -> Dict[str, Any]:
        """Summarizes recent WhatsApp dialogue for user report."""
        try:
            msgs = conversation_manager.get_recent_messages(contact_name, limit=15)
            if not msgs:
                return tool_response("summarize_conversation", True, result=f"No recent messages found with {contact_name}.", data={"summary": "None"})

            # Simple extractive/conversational summary
            history_text = "\n".join([f"{m['sender']}: {m['content']}" for m in msgs])
            summary = f"Recent messages with {contact_name}:\n{history_text}"
            return tool_response("summarize_conversation", True, result=summary, data={"summary": summary})
        except Exception as e:
            return tool_response("summarize_conversation", False, error=str(e))

    def handle_incoming_message(self, sender: str, incoming_text: str, send_to_desktop: bool = True) -> Dict[str, Any]:
        """
        Evaluates incoming message against contact's autonomy mode:
        MANUAL, SUGGEST_REPLY, AUTO_REPLY, FULL_AUTONOMOUS
        """
        contact = contacts_manager.find_contact(sender)
        auto_reply_enabled = contact.get("auto_reply", 0) if contact else 0
        mode = contact.get("autonomy_mode", "SMART_AUTONOMY") if contact else "SMART_AUTONOMY"

        # Record incoming message in memory
        conversation_manager.record_message(sender, sender="contact", channel="whatsapp", content=incoming_text)

        if not auto_reply_enabled and mode == "MANUAL":
            return {
                "action": "notify_user",
                "reply_sent": False,
                "note": f"New message from {sender}. Auto-reply is OFF."
            }

        # Generate autonomous contextual reply
        prompt = f"Sender {sender} wrote: '{incoming_text}'. You are MJ, an AI assistant representing {config.USER_TITLE}. Draft a short, polite, helpful 1-sentence reply."
        try:
            from brain import brain
            res = brain.process_command(prompt)
            reply = res.get("voice_response", "Thank you, I have received your message and will update you shortly.")
        except Exception:
            reply = "Got it, I will convey this to Sir."

        # Send if AUTO_REPLY or FULL_AUTONOMOUS
        if auto_reply_enabled or mode in ["AUTO_REPLY", "FULL_AUTONOMOUS"]:
            if send_to_desktop:
                self.send_message(sender, reply)
            else:
                conversation_manager.record_message(sender, sender="mj", channel="whatsapp", content=reply)
            return {"action": "auto_reply", "reply_sent": True, "reply": reply}

        return {"action": "suggest_reply", "reply_sent": False, "suggested_reply": reply}


# Global singleton instance
whatsapp_agent = WhatsAppAgent()
