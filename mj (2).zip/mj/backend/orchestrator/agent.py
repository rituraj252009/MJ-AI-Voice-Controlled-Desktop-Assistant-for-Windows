import os
import sys
import logging
from typing import Dict, Any, Optional, Callable

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import config
from backend.orchestrator.planner import TaskPlanner, TaskPlan
from backend.orchestrator.executor import TaskExecutor
from backend.orchestrator.router import ToolRouter

logger = logging.getLogger("MJ_MasterAgent")


class MasterAgent:
    """
    Unified Master Agent: Coordinates planning, tool selection,
    execution, verification, and cross-channel context.
    """
    def __init__(
        self,
        autonomy_mode: str = "SMART_AUTONOMY",
        on_dashboard_event: Optional[Callable[[str, Dict[str, Any]], None]] = None
    ):
        self.autonomy_mode = autonomy_mode
        self.on_dashboard_event = on_dashboard_event
        self.planner = TaskPlanner()
        self.executor = TaskExecutor(autonomy_mode=autonomy_mode, on_event_callback=self._handle_executor_event)
        self.router = ToolRouter()
        self.active_plan: Optional[TaskPlan] = None

    def _handle_executor_event(self, event_name: str, payload: Dict[str, Any]):
        if self.on_dashboard_event:
            try:
                self.on_dashboard_event(event_name, payload)
            except Exception:
                pass

    def run_goal(
        self,
        user_prompt: str,
        confirm_callback: Optional[Callable[[Any], bool]] = None
    ) -> Dict[str, Any]:
        """
        Takes a natural language prompt, plans steps, executes sequentially,
        and returns concise voice and structured output.
        """
        logger.info(f"Master Agent received goal: '{user_prompt}'")

        # 1. Plan task
        plan = self.planner.plan(user_prompt)
        self.active_plan = plan

        # 2. Execute plan
        result = self.executor.execute_plan(plan, confirm_callback=confirm_callback)

        # 3. Generate concise human voice response
        if result["success"]:
            if len(plan.steps) == 1:
                step_res = plan.steps[0].result or "पूरा हो गया"
                voice_msg = f"{step_res}"
            else:
                voice_msg = f"काम सफलतापूर्वक पूरा हो गया है, {config.USER_TITLE}। {result['summary']}"
        else:
            voice_msg = f"एक समस्या आई है, {config.USER_TITLE}। {result['summary']}"

        result["voice_response"] = voice_msg
        return result


# Global singleton instance
master_agent = MasterAgent()
