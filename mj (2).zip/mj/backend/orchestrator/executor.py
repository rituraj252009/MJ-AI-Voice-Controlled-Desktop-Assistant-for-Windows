import os
import sys
import time
import logging
from typing import Dict, Any, Optional, Callable

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.orchestrator.planner import TaskPlan, TaskStep
from backend.tools import computer
from backend.tools import files
from app_automator import automator

logger = logging.getLogger("MJ_Executor")


class TaskExecutor:
    """
    Executes task plans step-by-step with verification, retry logic,
    and security confirmation checks.
    """
    def __init__(
        self,
        autonomy_mode: str = "SMART_AUTONOMY",
        on_event_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None
    ):
        self.autonomy_mode = autonomy_mode  # ASSISTED, CONFIRM_BEFORE_ACTION, SMART_AUTONOMY, FULL_AUTONOMY
        self.on_event_callback = on_event_callback
        self.max_retries = 2

    def emit_event(self, event_name: str, payload: Dict[str, Any]):
        if self.on_event_callback:
            try:
                self.on_event_callback(event_name, payload)
            except Exception:
                pass

    def _execute_local_tool(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatches to registered tool functions."""
        tool_map = {
            "open_app": lambda p: computer.open_app(p.get("app") or p.get("app_name", "")),
            "close_app": lambda p: computer.close_app(p.get("app")),
            "open_url": lambda p: computer.open_url(p.get("url", "")),
            "search_web": lambda p: computer.search_web(p.get("query", "")),
            "play_youtube": lambda p: computer.play_youtube(p.get("query", "")),
            "click": lambda p: computer.click(p.get("x"), p.get("y"), p.get("button", "left")),
            "double_click": lambda p: computer.double_click(p.get("x"), p.get("y")),
            "type_text": lambda p: computer.type_text(p.get("text", ""), p.get("enter", False)),
            "press_key": lambda p: computer.press_key(p.get("key", "")),
            "hotkey": lambda p: computer.hotkey(p.get("keys", "")),
            "scroll": lambda p: computer.scroll(p.get("direction", "down"), p.get("amount", 500)),
            "screenshot": lambda p: computer.screenshot(p.get("path")),
            "read_screen": lambda p: computer.read_screen(),
            "find_on_screen": lambda p: computer.find_on_screen(p.get("template", ""), p.get("confidence", 0.8)),
            "run_safe_command": lambda p: computer.run_safe_command(p.get("command", "")),
            "set_volume": lambda p: computer.set_volume(int(p.get("level", 50))),
            "mute_volume": lambda p: computer.mute_volume(),
            "get_battery": lambda p: computer.get_battery(),
            "get_system_stats": lambda p: computer.get_system_stats(),
            "open_file": lambda p: files.open_file(p.get("file", "")),
            "open_folder": lambda p: files.open_folder(p.get("folder", "")),
            "create_folder": lambda p: files.create_folder(p.get("folder", "")),
            "delete_folder": lambda p: files.delete_folder(p.get("folder", "")),
            "rename_folder": lambda p: files.rename_folder(p.get("old", ""), p.get("new", "")),
            "create_file": lambda p: files.create_file(p.get("file", ""), p.get("content", "")),
            "delete_file": lambda p: files.delete_file(p.get("file", "")),
            "rename_file": lambda p: files.rename_file(p.get("old", ""), p.get("new", "")),
            "send_whatsapp": lambda p: automator.send_whatsapp_message(p.get("contact", ""), p.get("message", "")),
            "make_whatsapp_call": lambda p: automator.whatsapp_call(p.get("contact", ""), p.get("type", "voice")),
            "whatsapp_search": lambda p: automator.execute_context_task("search_contact", p.get("contact") or p.get("query", "")),
            "in_app_search": lambda p: automator.execute_context_task("search_inside", p.get("query", "")),
            "read_file_content": lambda p: files.read_file_content(p.get("file", "")),
            "media_control": lambda p: automator.execute_context_task("play_pause", ""),
            "open_first_video": lambda p: automator.execute_context_task("open_first", "")
        }

        # Check browser tools if imported
        try:
            from backend.tools import browser
            browser_tools = {
                "browser_navigate": lambda p: browser.navigate(p.get("url", "")),
                "browser_click": lambda p: browser.click_element(p.get("selector", "")),
                "browser_fill": lambda p: browser.type_text(p.get("selector", ""), p.get("value", "")),
                "browser_submit": lambda p: browser.submit_form(p.get("selector", "")),
                "browser_form_fill": lambda p: browser.fill_form(p.get("data", {}))
            }
            tool_map.update(browser_tools)
        except ImportError:
            pass

        if tool_name not in tool_map:
            return {"success": False, "tool": tool_name, "error": f"Tool '{tool_name}' not registered"}

        return tool_map[tool_name](params)

    def verify_step(self, step: TaskStep, execution_res: Dict[str, Any]) -> bool:
        """Verifies step outcome against expectations."""
        if not execution_res.get("success"):
            return False

        verification_mode = step.verification
        if verification_mode == "check_success":
            return bool(execution_res.get("success"))

        elif verification_mode == "check_app_open":
            # Give application up to 1.5s to appear in window context
            time.sleep(0.8)
            app_target = step.params.get("app", "").lower()
            fg_title = automator.get_active_window_title().lower()
            return app_target in fg_title or execution_res.get("success", False)

        elif verification_mode == "check_file_exists":
            file_name = step.params.get("file")
            if file_name:
                found = automator._find_file(file_name)
                return found is not None and os.path.exists(found)

        return True

    def execute_plan(
        self,
        plan: TaskPlan,
        confirm_callback: Optional[Callable[[TaskStep], bool]] = None
    ) -> Dict[str, Any]:
        """Runs the task plan sequentially with logging, verification, and safety checks."""
        plan.status = "executing"
        self.emit_event("task_started", {"goal": plan.goal, "total_steps": len(plan.steps)})

        step_results = []

        for idx, step in enumerate(plan.steps):
            plan.current_step_index = idx
            step.status = "running"
            self.emit_event("task_step", {"step_id": step.step_id, "description": step.description, "tool": step.tool})

            # Check safety / confirmation requirement
            requires_confirmation = (
                self.autonomy_mode == "CONFIRM_BEFORE_ACTION" or
                (self.autonomy_mode == "SMART_AUTONOMY" and step.risk_level == "high") or
                (self.autonomy_mode == "ASSISTED" and step.risk_level in ["medium", "high"])
            )

            if requires_confirmation:
                if confirm_callback:
                    allowed = confirm_callback(step)
                    if not allowed:
                        step.status = "skipped"
                        step.error = "Cancelled by user"
                        step_results.append(step.to_dict())
                        plan.status = "paused_by_user"
                        self.emit_event("task_paused", {"step_id": step.step_id, "reason": "User cancelled step"})
                        return {
                            "success": False,
                            "plan": plan.to_dict(),
                            "summary": f"Task paused: User declined action '{step.description}'"
                        }

            # Execute tool with retry logic
            success = False
            last_res = None
            for attempt in range(self.max_retries + 1):
                self.emit_event("tool_called", {"tool": step.tool, "params": step.params, "attempt": attempt + 1})
                raw_res = self._execute_local_tool(step.tool, step.params)
                
                # Normalize response format
                if isinstance(raw_res, str):
                    raw_res = {"success": True, "tool": step.tool, "result": raw_res}

                last_res = raw_res
                self.emit_event("tool_result", {"tool": step.tool, "result": raw_res})

                # Verify outcome
                verified = self.verify_step(step, raw_res)
                if verified:
                    success = True
                    break
                else:
                    time.sleep(0.5)

            if success:
                step.status = "success"
                step.result = last_res.get("result", "Completed")
                step_results.append(step.to_dict())
            else:
                step.status = "failed"
                step.error = last_res.get("error", "Verification failed")
                step_results.append(step.to_dict())
                plan.status = "failed"
                self.emit_event("task_failed", {"step_id": step.step_id, "error": step.error})
                return {
                    "success": False,
                    "plan": plan.to_dict(),
                    "summary": f"Task failed at step {step.step_id} ('{step.description}'): {step.error}"
                }

            time.sleep(0.2)

        plan.status = "completed"
        self.emit_event("task_completed", {"goal": plan.goal, "steps_completed": len(plan.steps)})

        return {
            "success": True,
            "plan": plan.to_dict(),
            "summary": f"Completed {len(plan.steps)} steps for '{plan.goal}'."
        }
