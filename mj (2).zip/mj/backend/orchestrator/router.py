import os
import sys
import logging
import requests
from typing import Dict, Any, Optional

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

logger = logging.getLogger("MJ_Router")


class ToolRouter:
    """
    Directs tool requests across local Python execution engines,
    browser automation, and n8n orchestration webhooks.
    """
    def __init__(self, n8n_url: Optional[str] = None, n8n_api_key: Optional[str] = None):
        self.n8n_url = n8n_url or os.getenv("N8N_URL", "http://localhost:5678")
        self.n8n_api_key = n8n_api_key or os.getenv("N8N_API_KEY", "")
        self.use_n8n_for_web = os.getenv("USE_N8N_FOR_WEB", "false").lower() == "true"

    def route_tool(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Routes tool call based on domain category."""
        # 1. Computer Control Tools (Always executed directly locally for <1ms latency)
        local_tools = [
            "open_app", "close_app", "open_url", "search_web", "play_youtube",
            "click", "double_click", "type_text", "press_key", "hotkey", "scroll",
            "screenshot", "read_screen", "find_on_screen", "run_safe_command",
            "set_volume", "mute_volume", "get_battery", "get_system_stats",
            "open_file", "open_folder", "create_folder", "delete_folder",
            "rename_folder", "create_file", "delete_file", "rename_file", "read_file_content"
        ]

        if tool_name in local_tools:
            from backend.orchestrator.executor import TaskExecutor
            executor = TaskExecutor()
            return executor._execute_local_tool(tool_name, params)

        # 2. Browser & Web Tools
        if tool_name.startswith("browser_"):
            try:
                from backend.tools import browser
                if hasattr(browser, tool_name.replace("browser_", "")):
                    method = getattr(browser, tool_name.replace("browser_", ""))
                    return method(**params)
            except Exception as e:
                logger.warning(f"Local browser execution error: {e}")

        # 3. WhatsApp / Communication Tools
        if tool_name in ["send_whatsapp", "make_whatsapp_call", "whatsapp_search", "whatsapp_read", "whatsapp_reply", "send_file_whatsapp", "whatsapp_auto_reply"]:
            from backend.adapters.whatsapp_adapter import whatsapp_adapter
            if tool_name == "send_whatsapp":
                res = whatsapp_adapter.send_message(params.get("contact", ""), params.get("message", ""))
                return {"success": res.get("success", False), "result": res.get("result", "")}
            elif tool_name == "make_whatsapp_call":
                res = whatsapp_adapter.start_call(params.get("contact", ""), params.get("type", "voice"))
                return {"success": res.get("success", False), "result": res.get("result", "")}
            elif tool_name == "whatsapp_search":
                res = whatsapp_adapter.search_contact(params.get("contact", ""))
                return {"success": res.get("success", False), "result": res.get("result", "")}
            elif tool_name == "whatsapp_read":
                res = whatsapp_adapter.read_latest_message(params.get("contact"))
                return {"success": res.get("success", False), "result": res.get("result", "")}
            elif tool_name == "whatsapp_reply":
                res = whatsapp_adapter.reply_message(params.get("message", ""))
                return {"success": res.get("success", False), "result": res.get("result", "")}
            elif tool_name == "send_file_whatsapp":
                res = whatsapp_adapter.send_file(params.get("contact", ""), params.get("file", ""))
                return {"success": res.get("success", False), "result": res.get("result", "")}

        # 4. Optional n8n Webhook Forwarding
        if self.n8n_api_key and self.n8n_url:
            try:
                webhook_url = f"{self.n8n_url}/webhook/mj-tool"
                headers = {"Content-Type": "application/json", "X-N8N-API-KEY": self.n8n_api_key}
                payload = {"tool": tool_name, "params": params}
                res = requests.post(webhook_url, json=payload, headers=headers, timeout=5)
                if res.status_code == 200:
                    return res.json()
            except Exception as e:
                logger.error(f"n8n tool routing failed: {e}")

        return {"success": False, "tool": tool_name, "error": f"Tool '{tool_name}' routing unhandled"}
