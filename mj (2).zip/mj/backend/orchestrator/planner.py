import json
import re
import requests
from typing import List, Dict, Any, Optional

import config
from backend.intent_parser import intent_parser


class TaskStep:
    def __init__(self, step_id: int, description: str, tool: str, params: Dict[str, Any], verification: str = "check_success", risk_level: str = "low"):
        self.step_id = step_id
        self.description = description
        self.tool = tool
        self.params = params
        self.verification = verification
        self.risk_level = risk_level  # "low", "medium", "high"
        self.status = "pending"  # "pending", "running", "success", "failed", "skipped"
        self.result = None
        self.error = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_id": self.step_id,
            "description": self.description,
            "tool": self.tool,
            "params": self.params,
            "verification": self.verification,
            "risk_level": self.risk_level,
            "status": self.status,
            "result": self.result,
            "error": self.error
        }


class TaskPlan:
    def __init__(self, goal: str, steps: List[TaskStep]):
        self.goal = goal
        self.steps = steps
        self.current_step_index = 0
        self.status = "planned"  # "planned", "executing", "completed", "failed", "requires_confirmation"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "goal": self.goal,
            "status": self.status,
            "current_step_index": self.current_step_index,
            "steps": [s.to_dict() for s in self.steps]
        }


class TaskPlanner:
    """
    Decomposes natural language instructions into structured execution DAGs
    with verification conditions and risk levels.
    """
    def __init__(self, gemini_api_key: str = config.GEMINI_API_KEY, groq_api_key: str = config.GROQ_API_KEY):
        self.gemini_key = gemini_api_key
        self.groq_key = groq_api_key
        self.fast_model = getattr(config, "FAST_GEMINI_MODEL", "gemini-3.5-flash-lite")

    def _rule_based_plan(self, prompt: str) -> Optional[TaskPlan]:
        """Sub-millisecond heuristics for common compound multi-step commands."""
        # 1. Intent Parser Compound Decomposition
        parsed = intent_parser.parse(prompt)
        if parsed.get("is_compound"):
            steps = []
            for idx, item in enumerate(parsed["steps"]):
                s_id = idx + 1
                intent = item.get("intent")
                if intent == "open_app":
                    app = item.get("application", "")
                    steps.append(TaskStep(s_id, f"Open {app}", "open_app", {"app": app}, "check_app_open", "low"))
                elif intent == "search_in_app":
                    q = item.get("query", "")
                    app = item.get("application") or ""
                    first_app = steps[0].params.get("app", "").lower() if steps else ""
                    if "whatsapp" in app.lower() or "whatsapp" in first_app:
                        steps.append(TaskStep(s_id, f"Search contact '{q}' in WhatsApp", "whatsapp_search", {"contact": q}, "check_success", "low"))
                    elif "youtube" in app.lower() or "youtube" in first_app:
                        steps.append(TaskStep(s_id, f"Search YouTube for '{q}'", "play_youtube", {"query": q}, "check_success", "low"))
                    else:
                        steps.append(TaskStep(s_id, f"Search inside app for '{q}'", "in_app_search", {"query": q}, "check_success", "low"))
                elif intent == "send_message":
                    contact = item.get("contact", "")
                    msg = item.get("message", "")
                    steps.append(TaskStep(s_id, f"Send message to {contact} on WhatsApp", "send_whatsapp", {"contact": contact, "message": msg}, "check_success", "medium"))
                elif intent == "call":
                    contact = item.get("contact", "")
                    c_type = item.get("type", "voice")
                    steps.append(TaskStep(s_id, f"Call {contact} on WhatsApp", "make_whatsapp_call", {"contact": contact, "type": c_type}, "check_success", "medium"))
                elif intent == "type_in_app":
                    txt = item.get("text", "")
                    steps.append(TaskStep(s_id, "Type text into active app", "type_text", {"text": txt, "enter": False}, "check_success", "low"))
                elif intent == "media_control":
                    act = item.get("action", "play")
                    if act == "open_first_video":
                        steps.append(TaskStep(s_id, "Open first video result", "open_first_video", {}, "check_success", "low"))
                    else:
                        steps.append(TaskStep(s_id, f"{act.title()} video", "media_control", {"action": act}, "check_success", "low"))
            if steps:
                return TaskPlan(prompt, steps)

        p = prompt.lower().strip()

        # "Open Chrome and search X" / "Chrome kholo aur YouTube par X search karo"
        if ("chrome" in p or "browser" in p) and ("youtube" in p) and ("search" in p or "play" in p):
            query = ""
            # Handle "YouTube par <query> search karo"
            m_hindi = re.search(r'youtube\s+par\s+(.+?)(?:\s+search|\s+play|\s+chalao|\s+khojo|$)', p)
            if m_hindi:
                query = m_hindi.group(1).strip()
            else:
                m = re.search(r'(?:search|play|dhundho|khojo)\s+(.+)', p)
                if m:
                    query = m.group(1).replace("search", "").replace("karo", "").replace("kar", "").strip()
                else:
                    query = p
            steps = [
                TaskStep(1, "Open Chrome browser", "open_app", {"app": "chrome"}, "check_app_open", "low"),
                TaskStep(2, f"Search YouTube for '{query}'", "play_youtube", {"query": query}, "check_success", "low")
            ]
            return TaskPlan(prompt, steps)

        # "Open Chrome and search X on Google"
        if ("chrome" in p or "browser" in p) and ("google" in p or "search" in p) and "youtube" not in p:
            query = ""
            m = re.search(r'(?:search|khojo|dhundho)\s+(.+)', p)
            if m:
                query = m.group(1).replace("kar", "").replace("karo", "").strip()
            if query:
                steps = [
                    TaskStep(1, "Open Chrome browser", "open_app", {"app": "chrome"}, "check_app_open", "low"),
                    TaskStep(2, f"Search Google for '{query}'", "search_web", {"query": query}, "check_success", "low")
                ]
                return TaskPlan(prompt, steps)

        # "Open Notepad and type X and save"
        if "notepad" in p and ("write" in p or "type" in p or "likho" in p):
            text_to_type = ""
            m = re.search(r'(?:write|type|likho)\s+(.+)', p)
            if m:
                text_to_type = m.group(1).strip()
            steps = [
                TaskStep(1, "Open Notepad", "open_app", {"app": "notepad"}, "check_app_open", "low"),
                TaskStep(2, f"Type content into Notepad", "type_text", {"text": text_to_type, "enter": True}, "check_success", "low")
            ]
            if "save" in p or "bachao" in p:
                steps.append(TaskStep(3, "Save document shortcut", "hotkey", {"keys": "ctrl+s"}, "check_success", "medium"))
            return TaskPlan(prompt, steps)

        # "Send WhatsApp to X saying Y"
        if "whatsapp" in p and ("message" in p or "msg" in p or "bhejo" in p or "send" in p):
            m_contact = re.search(r'(?:to|message|bhejo)\s+([a-zA-Z0-9_\u0900-\u097F]+)', p)
            contact = m_contact.group(1) if m_contact else ""
            msg = ""
            m_msg = re.search(r'(?:saying|that|ki)\s+(.+)', p)
            if m_msg:
                msg = m_msg.group(1).strip()
            steps = [
                TaskStep(1, f"Send WhatsApp message to {contact}", "send_whatsapp", {"contact": contact, "message": msg}, "check_success", "medium")
            ]
            return TaskPlan(prompt, steps)

        return None

    def _build_planner_prompt(self, user_goal: str) -> str:
        return f"""You are the Master Task Planner for MJ AI Autonomous Agent on Windows.
The user wants to accomplish the following goal:
"{user_goal}"

Break this goal down into a logical, sequential plan.
AVAILABLE TOOLS:
- open_app(app: str)
- close_app(app: Optional[str])
- open_url(url: str)
- search_web(query: str)
- play_youtube(query: str)
- click(x: Optional[int], y: Optional[int], button: str)
- double_click(x: Optional[int], y: Optional[int])
- type_text(text: str, enter: bool)
- press_key(key: str)
- hotkey(keys: str)
- scroll(direction: str, amount: int)
- screenshot(path: Optional[str])
- read_screen()
- run_safe_command(command: str)
- set_volume(level: int)
- mute_volume()
- get_battery()
- get_system_stats()
- open_file(file: str)
- open_folder(folder: str)
- create_folder(folder: str)
- delete_folder(folder: str)
- create_file(file: str, content: str)
- delete_file(file: str)
- read_file_content(file: str)
- send_whatsapp(contact: str, message: str)
- make_whatsapp_call(contact: str, type: str)
- browser_navigate(url: str)
- browser_click(selector: str)
- browser_fill(selector: str, value: str)
- browser_submit(selector: str)
- browser_form_fill(form_data: dict)

RISK LEVELS:
- "low": safe read, open app, search
- "medium": messaging, file modification, volume
- "high": file deletion, form submission, money/auth changes

Return a JSON array of steps:
{{
  "goal": "{user_goal}",
  "steps": [
    {{
      "step_id": 1,
      "description": "Short explanation",
      "tool": "tool_name",
      "params": {{ "key": "value" }},
      "verification": "check_success",
      "risk_level": "low"
    }}
  ]
}}
"""

    def plan(self, user_goal: str) -> TaskPlan:
        """Plans multi-step execution for user goal."""
        # 1. Fast heuristics
        quick = self._rule_based_plan(user_goal)
        if quick:
            return quick

        # 2. Try Gemini
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.fast_model}:generateContent?key={self.gemini_key}"
            payload = {
                "contents": [{"parts": [{"text": self._build_planner_prompt(user_goal)}]}],
                "generationConfig": {"responseMimeType": "application/json", "temperature": 0.2}
            }
            res = requests.post(url, json=payload, timeout=6)
            if res.status_code == 200:
                data = json.loads(res.json()['candidates'][0]['content']['parts'][0]['text'])
                steps = [
                    TaskStep(
                        step_id=s.get("step_id", idx + 1),
                        description=s.get("description", ""),
                        tool=s.get("tool", "run_safe_command"),
                        params=s.get("params", {}),
                        verification=s.get("verification", "check_success"),
                        risk_level=s.get("risk_level", "low")
                    )
                    for idx, s in enumerate(data.get("steps", []))
                ]
                return TaskPlan(user_goal, steps)
        except Exception:
            pass

        # 3. Fallback to single-step execution
        single_step = TaskStep(1, f"Execute '{user_goal}'", "open_app", {"app": user_goal}, "check_success", "low")
        return TaskPlan(user_goal, [single_step])
