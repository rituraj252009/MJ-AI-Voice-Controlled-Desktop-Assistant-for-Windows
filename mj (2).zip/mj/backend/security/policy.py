from typing import Dict, Any, Tuple


class SecurityPolicy:
    """
    Manages risk levels, autonomy modes, and human-in-the-loop confirmations.
    """
    RISK_LOW = "low"
    RISK_MEDIUM = "medium"
    RISK_HIGH = "high"

    AUTONOMY_ASSISTED = "ASSISTED"
    AUTONOMY_CONFIRM_BEFORE_ACTION = "CONFIRM_BEFORE_ACTION"
    AUTONOMY_SMART_AUTONOMY = "SMART_AUTONOMY"
    AUTONOMY_FULL_AUTONOMY = "FULL_AUTONOMY"

    TOOL_RISK_MAP = {
        # Low risk actions: Read-only, application open, search
        "open_app": RISK_LOW,
        "search_web": RISK_LOW,
        "open_url": RISK_LOW,
        "play_youtube": RISK_LOW,
        "read_screen": RISK_LOW,
        "screenshot": RISK_LOW,
        "get_battery": RISK_LOW,
        "get_system_stats": RISK_LOW,
        "open_file": RISK_LOW,
        "open_folder": RISK_LOW,
        "read_file_content": RISK_LOW,
        "browser_navigate": RISK_LOW,
        "browser_inspect": RISK_LOW,
        "browser_read": RISK_LOW,

        # Medium risk actions: In-app controls, communication drafts
        "type_text": RISK_MEDIUM,
        "press_key": RISK_MEDIUM,
        "hotkey": RISK_MEDIUM,
        "scroll": RISK_MEDIUM,
        "set_volume": RISK_MEDIUM,
        "mute_volume": RISK_MEDIUM,
        "create_file": RISK_MEDIUM,
        "create_folder": RISK_MEDIUM,
        "rename_file": RISK_MEDIUM,
        "rename_folder": RISK_MEDIUM,
        "send_whatsapp": RISK_MEDIUM,
        "make_whatsapp_call": RISK_MEDIUM,
        "browser_click": RISK_MEDIUM,
        "browser_fill": RISK_MEDIUM,

        # High risk actions: Irreversible destructive or financial actions, form submit
        "delete_file": RISK_HIGH,
        "delete_folder": RISK_HIGH,
        "browser_submit": RISK_HIGH,
        "browser_form_submit": RISK_HIGH,
        "shutdown_laptop": RISK_HIGH,
        "run_safe_command": RISK_MEDIUM
    }

    @classmethod
    def get_tool_risk(cls, tool_name: str) -> str:
        return cls.TOOL_RISK_MAP.get(tool_name, cls.RISK_MEDIUM)

    @classmethod
    def requires_confirmation(cls, tool_name: str, autonomy_mode: str = AUTONOMY_SMART_AUTONOMY) -> Tuple[bool, str]:
        """
        Determines if an action requires explicit user permission.
        Returns: (requires_confirm: bool, prompt_question: str)
        """
        risk = cls.get_tool_risk(tool_name)

        if autonomy_mode == cls.AUTONOMY_FULL_AUTONOMY:
            # Full autonomy only confirms high risk actions like deletion or external submissions
            if risk == cls.RISK_HIGH:
                return True, f"This action is irreversible ({tool_name}). Do you want to proceed?"
            return False, ""

        elif autonomy_mode == cls.AUTONOMY_SMART_AUTONOMY:
            # Smart autonomy executes low and medium actions automatically, confirms high
            if risk == cls.RISK_HIGH:
                if "submit" in tool_name:
                    return True, "Form ready है. क्या मैं इसे submit कर दूँ? (Submit this form?)"
                elif "delete" in tool_name:
                    return True, "क्या आप वाकई इसे delete करना चाहते हैं? (Confirm deletion?)"
                return True, f"Action requires confirmation: {tool_name}. Proceed?"
            return False, ""

        elif autonomy_mode == cls.AUTONOMY_CONFIRM_BEFORE_ACTION:
            # Confirms before any action
            return True, f"Shall I execute {tool_name}?"

        elif autonomy_mode == cls.AUTONOMY_ASSISTED:
            # Confirms medium and high
            if risk in [cls.RISK_MEDIUM, cls.RISK_HIGH]:
                return True, f"Do you approve executing {tool_name}?"
            return False, ""

        return False, ""
