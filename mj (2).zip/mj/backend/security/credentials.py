import os
import sys
import json
import base64
import logging
from typing import Dict, Any, Optional, List
from cryptography.fernet import Fernet

logger = logging.getLogger("MJ_Security")

VAULT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "database")
KEY_FILE = os.path.join(VAULT_DIR, "vault.key")
VAULT_FILE = os.path.join(VAULT_DIR, "vault.enc")


class CredentialVault:
    """
    Secure Credential Storage Engine using AES-128-CBC / Fernet encryption.
    Guarantees passwords NEVER appear in:
    - AI Prompts
    - Terminal Logs
    - Transcripts / Chat Outputs
    - n8n payloads
    """
    def __init__(self):
        os.makedirs(VAULT_DIR, exist_ok=True)
        self._key = self._get_or_create_key()
        self._fernet = Fernet(self._key)

    def _get_or_create_key(self) -> bytes:
        if os.path.exists(KEY_FILE):
            with open(KEY_FILE, "rb") as f:
                return f.read().strip()
        else:
            key = Fernet.generate_key()
            with open(KEY_FILE, "wb") as f:
                f.write(key)
            return key

    def _load_vault(self) -> Dict[str, Any]:
        if not os.path.exists(VAULT_FILE):
            return {}
        try:
            with open(VAULT_FILE, "rb") as f:
                encrypted_data = f.read()
            if not encrypted_data:
                return {}
            decrypted_bytes = self._fernet.decrypt(encrypted_data)
            return json.loads(decrypted_bytes.decode("utf-8"))
        except Exception as e:
            logger.error(f"Failed to decrypt vault: {e}")
            return {}

    def _save_vault(self, data: Dict[str, Any]):
        json_bytes = json.dumps(data).encode("utf-8")
        encrypted_bytes = self._fernet.encrypt(json_bytes)
        with open(VAULT_FILE, "wb") as f:
            f.write(encrypted_bytes)

    def store_credential(self, service: str, username: str, password: str, extra: Optional[Dict[str, Any]] = None) -> bool:
        """Securely encrypts and stores credentials for a website or service."""
        vault = self._load_vault()
        vault[service.lower().strip()] = {
            "service": service,
            "username": username,
            "password": password,
            "extra": extra or {},
            "updated_at": os.path.getmtime(KEY_FILE)
        }
        self._save_vault(vault)
        return True

    def get_credential(self, service: str) -> Optional[Dict[str, Any]]:
        """Retrieves decrypted credentials strictly for DOM injection."""
        vault = self._load_vault()
        return vault.get(service.lower().strip())

    def list_services(self) -> List[str]:
        """Lists stored services without revealing usernames or passwords."""
        vault = self._load_vault()
        return list(vault.keys())

    def delete_credential(self, service: str) -> bool:
        vault = self._load_vault()
        key = service.lower().strip()
        if key in vault:
            del vault[key]
            self._save_vault(vault)
            return True
        return False

    @staticmethod
    def mask_text(text: str) -> str:
        """Returns safe masked preview."""
        return "********" if text else ""


# Global singleton instance
vault = CredentialVault()
