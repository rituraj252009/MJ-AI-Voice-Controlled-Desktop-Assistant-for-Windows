import difflib
from typing import Dict, Any, Optional, List
from backend.memory.database import db


class ContactManager:
    """Manages cross-channel contacts, phone numbers, and autonomy policies."""

    def find_contact(self, query: str) -> Optional[Dict[str, Any]]:
        """Finds contact by exact name, phone number, alias, or fuzzy matching."""
        if not query or not query.strip():
            return None
        q = query.strip().lower()

        with db.get_connection() as conn:
            cursor = conn.cursor()

            # 1. Exact phone or name match
            cursor.execute("SELECT * FROM contacts WHERE LOWER(name) = ? OR phone = ?", (q, q))
            row = cursor.fetchone()
            if row:
                return dict(row)

            # 2. Substring match
            cursor.execute("SELECT * FROM contacts WHERE LOWER(name) LIKE ? OR LOWER(alias) LIKE ?", (f"%{q}%", f"%{q}%"))
            row = cursor.fetchone()
            if row:
                return dict(row)

            # 3. Fuzzy match across all contact names
            cursor.execute("SELECT name FROM contacts")
            all_names = [r["name"] for r in cursor.fetchall()]
            matches = difflib.get_close_matches(q.title(), all_names, n=1, cutoff=0.6)
            if matches:
                cursor.execute("SELECT * FROM contacts WHERE name = ?", (matches[0],))
                row = cursor.fetchone()
                if row:
                    return dict(row)

        return None

    def find_all_matching_contacts(self, query: str) -> List[Dict[str, Any]]:
        """Finds all contacts matching query by exact, substring, or first name."""
        if not query or not query.strip():
            return []
        q = query.strip().lower()
        results = []
        seen_ids = set()

        with db.get_connection() as conn:
            cursor = conn.cursor()
            # 1. Exact or substring match
            cursor.execute("SELECT * FROM contacts WHERE LOWER(name) LIKE ? OR LOWER(alias) LIKE ?", (f"%{q}%", f"%{q}%"))
            for r in cursor.fetchall():
                d = dict(r)
                if d["id"] not in seen_ids:
                    seen_ids.add(d["id"])
                    results.append(d)

            # 2. Check first name equality (e.g. 'Rahul' matching 'Rahul Sharma')
            cursor.execute("SELECT * FROM contacts")
            for r in cursor.fetchall():
                d = dict(r)
                if d["id"] not in seen_ids:
                    first_name = d["name"].split()[0].lower() if d.get("name") else ""
                    if first_name == q:
                        seen_ids.add(d["id"])
                        results.append(d)

        return results

    def add_or_update_contact(
        self,
        name: str,
        phone: Optional[str] = None,
        notes: Optional[str] = None,
        autonomy_mode: str = "SMART_AUTONOMY",
        auto_reply: bool = False,
        auto_answer: bool = False
    ) -> Dict[str, Any]:
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO contacts (name, phone, notes, autonomy_mode, auto_reply, auto_answer)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET
                phone = COALESCE(excluded.phone, contacts.phone),
                notes = COALESCE(excluded.notes, contacts.notes),
                autonomy_mode = excluded.autonomy_mode,
                auto_reply = excluded.auto_reply,
                auto_answer = excluded.auto_answer
            """, (name.strip(), phone, notes, autonomy_mode, 1 if auto_reply else 0, 1 if auto_answer else 0))
            conn.commit()

        return self.find_contact(name)

    def set_autonomy(self, contact_name: str, auto_reply: Optional[bool] = None, auto_answer: Optional[bool] = None, mode: Optional[str] = None):
        contact = self.find_contact(contact_name)
        if not contact:
            return False

        updates = []
        params = []
        if auto_reply is not None:
            updates.append("auto_reply = ?")
            params.append(1 if auto_reply else 0)
        if auto_answer is not None:
            updates.append("auto_answer = ?")
            params.append(1 if auto_answer else 0)
        if mode:
            updates.append("autonomy_mode = ?")
            params.append(mode)

        if updates:
            params.append(contact["id"])
            with db.get_connection() as conn:
                conn.cursor().execute(f"UPDATE contacts SET {', '.join(updates)} WHERE id = ?", params)
                conn.commit()
        return True

    def list_contacts(self) -> List[Dict[str, Any]]:
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM contacts ORDER BY name ASC")
            return [dict(r) for r in cursor.fetchall()]


# Global singleton instance
contacts_manager = ContactManager()
