import time
from typing import Dict, Any, Optional, List
from backend.memory.database import db
from backend.memory.contacts import contacts_manager


class ConversationManager:
    """Manages cross-channel conversation memory, call logs, and context synthesis."""

    def record_message(self, contact_name: str, sender: str, channel: str, content: str) -> int:
        """Stores message across WhatsApp, Phone, or Voice chat."""
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO messages (contact_name, sender, channel, content)
            VALUES (?, ?, ?, ?)
            """, (contact_name, sender, channel, content))
            msg_id = cursor.lastrowid

            # Update contact's last contacted timestamp
            cursor.execute("""
            UPDATE contacts SET last_contacted = CURRENT_TIMESTAMP WHERE LOWER(name) = ?
            """, (contact_name.lower(),))
            conn.commit()
            return msg_id

    def get_recent_messages(self, contact_name: str, limit: int = 10) -> List[Dict[str, Any]]:
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            SELECT * FROM messages
            WHERE LOWER(contact_name) = ?
            ORDER BY timestamp DESC LIMIT ?
            """, (contact_name.lower(), limit))
            rows = cursor.fetchall()
            return [dict(r) for r in reversed(rows)]

    def record_call(
        self,
        call_id: str,
        contact_name: str,
        phone: str,
        direction: str,
        status: str = "completed",
        duration_seconds: int = 0,
        transcript: str = ""
    ):
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO calls (call_id, contact_name, phone, direction, status, duration_seconds, transcript)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(call_id) DO UPDATE SET
                status = excluded.status,
                ended_at = CURRENT_TIMESTAMP,
                duration_seconds = excluded.duration_seconds,
                transcript = excluded.transcript
            """, (call_id, contact_name, phone, direction, status, duration_seconds, transcript))
            conn.commit()

    def record_call_summary(self, call_id: str, contact_name: str, summary: str, action_items: str = ""):
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO call_summaries (call_id, contact_name, summary, action_items)
            VALUES (?, ?, ?, ?)
            """, (call_id, contact_name, summary, action_items))
            conn.commit()

    def get_cross_channel_context(self, contact_name: str) -> Dict[str, Any]:
        """
        Synthesizes cross-channel memory for a contact:
        - Contact details & notes
        - Last conversation messages
        - Last call date & summary
        - Active pending tasks
        """
        contact = contacts_manager.find_contact(contact_name)
        if not contact:
            return {"contact_name": contact_name, "found": False}

        recent_msgs = self.get_recent_messages(contact_name, limit=6)

        with db.get_connection() as conn:
            cursor = conn.cursor()

            # Latest call summary
            cursor.execute("""
            SELECT * FROM call_summaries
            WHERE LOWER(contact_name) = ?
            ORDER BY created_at DESC LIMIT 1
            """, (contact_name.lower(),))
            latest_call_summary = cursor.fetchone()

            # Pending tasks mentioning contact
            cursor.execute("""
            SELECT goal FROM tasks
            WHERE status != 'completed' AND LOWER(goal) LIKE ?
            LIMIT 3
            """, (f"%{contact_name.lower()}%",))
            pending_tasks = [r["goal"] for r in cursor.fetchall()]

        return {
            "found": True,
            "contact": contact,
            "recent_messages": recent_msgs,
            "latest_call_summary": dict(latest_call_summary) if latest_call_summary else None,
            "pending_tasks": pending_tasks
        }


# Global singleton instance
conversation_manager = ConversationManager()
