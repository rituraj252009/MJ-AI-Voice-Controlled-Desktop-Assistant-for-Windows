import os
import sys
import sqlite3
import json
import time
from typing import Dict, Any, Optional, List

DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "database")
DB_PATH = os.path.join(DB_DIR, "mj_memory.db")


class MemoryDatabase:
    """
    Persistent SQLite Cross-Channel Memory Engine.
    Stores and connects contacts, messages, calls, summaries, tasks,
    user preferences, and autonomy rules across all interfaces.
    """
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_schema()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # 1. Users table (User profile and saved form information)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                title TEXT DEFAULT 'Sir',
                email TEXT,
                phone TEXT,
                college TEXT,
                course TEXT,
                dob TEXT,
                address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # 2. Contacts table (Cross-channel identities)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                alias TEXT,
                phone TEXT,
                whatsapp_jid TEXT,
                relationship TEXT,
                notes TEXT,
                autonomy_mode TEXT DEFAULT 'SMART_AUTONOMY',
                auto_reply INTEGER DEFAULT 0,
                auto_answer INTEGER DEFAULT 0,
                last_contacted TIMESTAMP
            )
            """)

            # 3. Conversations table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_id INTEGER,
                channel TEXT NOT NULL, -- 'whatsapp', 'phone', 'desktop', 'voice'
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ended_at TIMESTAMP,
                status TEXT DEFAULT 'active',
                FOREIGN KEY (contact_id) REFERENCES contacts(id)
            )
            """)

            # 4. Messages table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id INTEGER,
                contact_name TEXT,
                sender TEXT NOT NULL, -- 'user', 'contact', 'mj'
                channel TEXT NOT NULL,
                content TEXT NOT NULL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (conversation_id) REFERENCES conversations(id)
            )
            """)

            # 5. Calls table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS calls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                call_id TEXT UNIQUE,
                contact_name TEXT,
                phone TEXT,
                direction TEXT NOT NULL, -- 'inbound', 'outbound'
                status TEXT DEFAULT 'ringing', -- 'ringing', 'in-progress', 'completed', 'failed'
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ended_at TIMESTAMP,
                duration_seconds INTEGER DEFAULT 0,
                transcript TEXT
            )
            """)

            # 6. Call Summaries table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS call_summaries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                call_id TEXT,
                contact_name TEXT,
                summary TEXT NOT NULL,
                action_items TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)

            # 7. Tasks table (Autonomous multi-step workflows)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                goal TEXT NOT NULL,
                status TEXT DEFAULT 'planned', -- 'planned', 'executing', 'completed', 'failed'
                total_steps INTEGER DEFAULT 0,
                current_step INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP
            )
            """)

            # 8. Task History (Step-by-step audit log)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                step_number INTEGER,
                tool_called TEXT,
                tool_params TEXT,
                result TEXT,
                status TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks(id)
            )
            """)

            # 9. Preferences and Automation Rules
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS automation_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                contact_name TEXT,
                rule_type TEXT NOT NULL, -- 'auto_reply', 'auto_call', 'block', 'vip'
                condition_param TEXT,
                action_param TEXT,
                is_enabled INTEGER DEFAULT 1
            )
            """)

            # Seed default user if not exists
            cursor.execute("SELECT COUNT(*) FROM users")
            if cursor.fetchone()[0] == 0:
                cursor.execute("""
                INSERT INTO users (name, title, email, phone, college, course)
                VALUES ('Rituraj', 'Sir Rituraj', 'rituraj@example.com', '+919876543210', 'Engineering College', 'B.Tech CSE')
                """)

            # Seed sample contact
            cursor.execute("SELECT COUNT(*) FROM contacts WHERE name = 'Rahul'")
            if cursor.fetchone()[0] == 0:
                cursor.execute("""
                INSERT INTO contacts (name, alias, phone, notes, autonomy_mode, auto_reply, auto_answer)
                VALUES ('Rahul', 'rahul, bro', '+919999988888', 'College project teammate', 'SMART_AUTONOMY', 1, 1)
                """)

            conn.commit()


# Global singleton instance
db = MemoryDatabase()
