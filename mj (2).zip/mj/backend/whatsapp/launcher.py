import os
import time
import subprocess
import logging
from typing import Dict, Any, Optional
import ctypes

from backend.ui_controller import ui_controller
from backend.whatsapp.detector import whatsapp_detector

logger = logging.getLogger("MJ_WhatsAppLauncher")

class WhatsAppLauncher:
    """
    Handles launching, restoring, and bringing WhatsApp Desktop into the foreground.
    Replaces blind time.sleep() with event-driven window verification.
    """

    PROCESS_NAMES = ["whatsapp.root.exe", "whatsapp.exe"]

    def __init__(self):
        self.user32 = ctypes.windll.user32

    def get_whatsapp_window(self) -> Optional[Dict[str, Any]]:
        """
        Locates the main WhatsApp application window HWND.
        Ignores IME and GDI+ helper windows.
        """
        wins = ui_controller.find_windows(process_names=self.PROCESS_NAMES)
        if not wins:
            return None

        # Prefer window named 'WhatsApp' or contact name, excluding helper windows
        for w in wins:
            t = w.get("title", "")
            if t and not any(skip in t for skip in ["GDI+", "MSCTFIME", "Default IME", "NotifyIcon"]):
                return w

        # Secondary check: any window with process name that is visible or has non-empty title
        for w in wins:
            if w.get("title"):
                return w

        return wins[0] if wins else None

    def get_whatsapp_hwnd(self) -> Optional[int]:
        """Returns the main WhatsApp HWND if present."""
        w = self.get_whatsapp_window()
        return w["hwnd"] if w else None

    def is_foreground(self) -> bool:
        """Returns True if WhatsApp is currently the foreground window."""
        fg = self.user32.GetForegroundWindow()
        if not fg:
            return False
        proc = ui_controller.get_process_name(fg)
        return any(p in proc for p in self.PROCESS_NAMES)

    def activate_or_launch(self, prefer_beta: bool = False, timeout: float = 4.0) -> Dict[str, Any]:
        """
        Brings WhatsApp Desktop to the foreground. If not running, launches it.
        Uses intelligent event-driven waiting to confirm the window is ready.
        """
        # 1. Check if already foreground
        hwnd = self.get_whatsapp_hwnd()
        if hwnd and self.is_foreground():
            return {"success": True, "hwnd": hwnd, "action": "already_focused", "message": "WhatsApp is open."}

        # 2. If window exists, restore and bring to foreground
        if hwnd:
            success = ui_controller.bring_to_foreground(hwnd)
            if success:
                # Wait briefly for rendering to settle
                time.sleep(0.08)
                return {"success": True, "hwnd": hwnd, "action": "restored", "message": "WhatsApp is open."}

        # 3. If not running or window not accessible, launch target
        target = whatsapp_detector.get_preferred_target(prefer_beta=prefer_beta)
        launch_type = target.get("type", "web_fallback")

        if launch_type == "web_fallback":
            # Only fallback to browser if desktop is completely unavailable
            import webbrowser
            webbrowser.open(target.get("url", "https://web.whatsapp.com"))
            return {"success": True, "hwnd": None, "action": "web_fallback", "message": "Opened WhatsApp Web in your browser."}

        # Launch official Desktop
        app_id = target.get("app_id") or whatsapp_detector.UWP_STABLE_APP_ID
        try:
            subprocess.Popen(
                ["explorer.exe", f"shell:AppsFolder\\{app_id}"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except Exception:
            try:
                subprocess.Popen(
                    ["powershell", "-NoProfile", "-Command", "Start-Process 'whatsapp:'"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            except Exception as e:
                logger.error(f"WhatsApp launch error: {e}")
                return {"success": False, "error": f"Failed to launch WhatsApp: {e}"}

        # 4. Event-driven wait for WhatsApp window to appear and gain focus
        found = ui_controller.wait_for_condition(
            lambda: self.get_whatsapp_hwnd() is not None,
            timeout=timeout,
            interval=0.1
        )

        if found:
            hwnd = self.get_whatsapp_hwnd()
            if hwnd:
                ui_controller.bring_to_foreground(hwnd)
            return {"success": True, "hwnd": hwnd, "action": "launched", "message": "WhatsApp is open."}

        # Secondary fallback: try protocol handler 'whatsapp:' if UWP shell launch timed out
        try:
            subprocess.Popen(
                ["cmd.exe", "/c", "start", "whatsapp:"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            found_retry = ui_controller.wait_for_condition(
                lambda: self.get_whatsapp_hwnd() is not None,
                timeout=2.5,
                interval=0.1
            )
            if found_retry:
                hwnd = self.get_whatsapp_hwnd()
                if hwnd:
                    ui_controller.bring_to_foreground(hwnd)
                return {"success": True, "hwnd": hwnd, "action": "launched_protocol", "message": "WhatsApp is open."}
        except Exception:
            pass

        return {"success": False, "error": "WhatsApp Desktop could not be opened or focused."}

# Global singleton instance
whatsapp_launcher = WhatsAppLauncher()
