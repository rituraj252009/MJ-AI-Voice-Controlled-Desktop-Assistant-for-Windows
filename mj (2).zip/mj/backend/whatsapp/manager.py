import logging
from typing import Dict, Any, Optional

from backend.whatsapp.detector import whatsapp_detector, WhatsAppDetector
from backend.whatsapp.launcher import whatsapp_launcher, WhatsAppLauncher
from backend.whatsapp.ui_controller import whatsapp_ui, WhatsAppUIController
from backend.whatsapp.action_executor import whatsapp_executor, WhatsAppActionExecutor
from backend.whatsapp.context_manager import whatsapp_context, WhatsAppContextManager

logger = logging.getLogger("MJ_WhatsAppManager")

class WhatsAppManager:
    """
    Unified Orchestrator & Facade for WhatsApp Desktop on Windows.
    Coordinates detection, launching, UI interaction, action execution,
    and conversational context.
    """

    def __init__(self):
        self.detector = whatsapp_detector
        self.launcher = whatsapp_launcher
        self.ui = whatsapp_ui
        self.executor = whatsapp_executor
        self.context = whatsapp_context

    def open(self, prefer_beta: bool = False) -> Dict[str, Any]:
        return self.executor.open_whatsapp(prefer_beta=prefer_beta)

    def search_contact(self, contact_name: str) -> Dict[str, Any]:
        return self.executor.search_contact(contact_name)

    def send_message(self, contact_name: str, message: str) -> Dict[str, Any]:
        return self.executor.send_message(contact_name, message)

    def reply(self, message: str) -> Dict[str, Any]:
        return self.executor.reply_message(message)

    def read_latest(self, contact_name: Optional[str] = None) -> Dict[str, Any]:
        return self.executor.read_latest_message(contact_name=contact_name)

    def read_unread(self) -> Dict[str, Any]:
        return self.executor.read_unread_messages()

    def send_file(self, contact_name: str, file_query: str) -> Dict[str, Any]:
        return self.executor.send_file(contact_name, file_query)

    def call(self, contact_name: Optional[str] = None, call_type: str = "voice") -> Dict[str, Any]:
        return self.executor.start_call(contact_name=contact_name, call_type=call_type)

    def get_status(self) -> Dict[str, Any]:
        return self.executor.get_status()

# Global singleton instance
whatsapp_manager = WhatsAppManager()
