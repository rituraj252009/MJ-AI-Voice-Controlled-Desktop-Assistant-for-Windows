import time
import logging
from typing import Dict, Any, Optional

from backend.context_engine import context_engine

logger = logging.getLogger("MJ_WhatsAppContextManager")

class WhatsAppContextManager:
    """
    Maintains short-term task and conversation memory for WhatsApp Desktop.
    Enables multi-turn conversational follow-ups:
    - 'WhatsApp kholo' -> current_app = 'whatsapp'
    - 'Ravi ka chat kholo' -> current_chat = 'Ravi', current_contact = 'Ravi'
    - 'Usko bolo kal aaunga' -> pronoun 'usko' resolves to 'Ravi'
    - 'Is message ka reply karo: okay' -> replies in active chat
    """

    PRONOUNS = ["usko", "unko", "usse", "use", "unhe", "him", "her", "them", "this person", "that person"]

    def __init__(self):
        self.state: Dict[str, Any] = {
            "current_app": "whatsapp",
            "current_window": None,
            "current_chat": "",
            "current_contact": "",
            "current_message_context": "",
            "last_action": "",
            "last_timestamp": 0.0
        }

    def update_context(
        self,
        chat: Optional[str] = None,
        contact: Optional[str] = None,
        message: Optional[str] = None,
        action: Optional[str] = None,
        window: Optional[int] = None
    ):
        """Updates internal WhatsApp context and syncs with global ContextEngine."""
        now = time.time()
        if chat:
            self.state["current_chat"] = chat.strip()
            self.state["current_contact"] = chat.strip()
        if contact:
            self.state["current_contact"] = contact.strip()
            if not self.state["current_chat"]:
                self.state["current_chat"] = contact.strip()
        if message:
            self.state["current_message_context"] = message.strip()
        if action:
            self.state["last_action"] = action.strip()
        if window:
            self.state["current_window"] = window
        self.state["last_timestamp"] = now

        # Sync with global ContextEngine
        context_engine.update_task_state(
            action=self.state["last_action"] or "whatsapp_active",
            target=self.state["current_contact"] or self.state["current_chat"],
            task="whatsapp",
            app="whatsapp"
        )

    def get_active_contact(self) -> str:
        """Returns the currently active contact or chat name."""
        return self.state.get("current_contact") or self.state.get("current_chat") or ""

    def resolve_contact(self, raw_contact_name: str) -> str:
        """
        Resolves pronouns ('usko', 'him', 'her') to the active contact.
        If empty or pronoun, returns the current contact.
        """
        clean = raw_contact_name.strip().lower()
        if not clean or clean in self.PRONOUNS:
            return self.get_active_contact()

        # Check if query ends or starts with pronoun
        for p in self.PRONOUNS:
            if clean == p or clean.startswith(p + " ") or clean.endswith(" " + p):
                return self.get_active_contact()

        return raw_contact_name.strip()

    def get_status(self) -> Dict[str, Any]:
        """Returns a snapshot of current WhatsApp context state."""
        return dict(self.state)

    def clear(self):
        """Resets active contact/chat context."""
        self.state["current_chat"] = ""
        self.state["current_contact"] = ""
        self.state["current_message_context"] = ""
        self.state["last_action"] = ""

# Global singleton instance
whatsapp_context = WhatsAppContextManager()
