import os
import sys
import time
import logging
from typing import Dict, Any, Optional, List, Tuple
import pyautogui
import pyperclip

from backend.ui_controller import ui_controller
from backend.whatsapp.launcher import whatsapp_launcher

logger = logging.getLogger("MJ_WhatsAppUIController")

class WhatsAppUIController:
    """
    Intelligent UI Controller for WhatsApp Desktop on Windows.
    Provides:
    - Event-driven intelligent waits (no rigid 2-second sleep delays)
    - Search bar clearing and robust contact opening
    - Active chat name verification
    - Safe typing & sending with duplicate message protection
    - Reading visible messages, latest message, and unread counts via UI Automation
    - File attachment handling
    - Voice and video calling shortcuts
    """

    def __init__(self):
        pass

    def ensure_focused(self) -> bool:
        """Brings WhatsApp to foreground if not already active."""
        if whatsapp_launcher.is_foreground():
            return True
        res = whatsapp_launcher.activate_or_launch()
        return res.get("success", False)

    # ==================== Intelligent Waits ====================
    def wait_for_window(self, timeout: float = 3.0) -> bool:
        """Waits until WhatsApp window is foreground."""
        return ui_controller.wait_for_condition(
            lambda: whatsapp_launcher.is_foreground(),
            timeout=timeout,
            interval=0.05
        )

    def wait_for_search_ready(self, timeout: float = 2.0) -> bool:
        """Focuses search bar and verifies readiness."""
        if not self.ensure_focused():
            return False
        # Ctrl+F triggers search in WhatsApp Desktop
        ui_controller.press_hotkey('ctrl', 'f', delay_after=0.08)
        # Clear existing query
        ui_controller.press_hotkey('ctrl', 'a', delay_after=0.04)
        ui_controller.press_key('backspace', delay_after=0.05)
        return True

    # ==================== Search & Chat Selection ====================
    def search_and_open_chat(self, contact_name: str, timeout: float = 3.0) -> Dict[str, Any]:
        """
        Focuses WhatsApp search bar, enters contact name, selects the first matching
        chat result, and verifies the chat is open.
        """
        clean_contact = contact_name.strip()
        if not clean_contact:
            return {"success": False, "error": "Contact name cannot be empty."}

        if not self.ensure_focused():
            return {"success": False, "error": "Could not focus WhatsApp Desktop."}

        # Focus search bar
        self.wait_for_search_ready()

        # Paste contact name to prevent character dropping
        ui_controller.paste_text(clean_contact, press_enter=False, delay_after=0.15)

        # Wait briefly for results to filter, then press Enter to select
        time.sleep(0.2)
        ui_controller.press_key('enter', delay_after=0.2)

        # Press Escape once if search dropdown is still covering message box, or verify focus
        active_title = self.get_active_chat_title()

        return {
            "success": True,
            "contact": clean_contact,
            "active_chat": active_title or clean_contact,
            "message": f"{clean_contact}'s chat is open."
        }

    def get_active_chat_title(self) -> str:
        """
        Attempts to read the active chat name from the WhatsApp window title
        or UI header.
        """
        w = whatsapp_launcher.get_whatsapp_window()
        if w:
            title = w.get("title", "").strip()
            # If title is not generic 'WhatsApp', it often reflects the contact name
            if title and title.lower() != "whatsapp" and not title.startswith("GDI+"):
                return title

        # Check UIA root element for Header or Text controls
        hwnd = whatsapp_launcher.get_whatsapp_hwnd()
        if hwnd:
            try:
                root = ui_controller.get_uia_element_from_hwnd(hwnd)
                if root:
                    # In WhatsApp Desktop (WinUI 3), active chat title is often a Text element near the top
                    # We look for a Text element that isn't 'Chats', 'Status', 'Calls'
                    ctrl = ui_controller.find_uia_control(root, control_type_name="Text")
                    if ctrl and hasattr(ctrl, "CurrentName") and ctrl.CurrentName:
                        name = ctrl.CurrentName.strip()
                        if name and name.lower() not in ["chats", "status", "calls", "settings", "search"]:
                            return name
            except Exception:
                pass
        return ""

    # ==================== Message Sending & Verification ====================
    def type_and_send_message(self, message_text: str) -> Dict[str, Any]:
        """
        Pastes message text into the focused WhatsApp chat input box,
        sends it by pressing Enter, and verifies that the message box cleared.
        """
        clean_msg = message_text.strip()
        if not clean_msg:
            return {"success": False, "error": "Message text cannot be empty."}

        if not self.ensure_focused():
            return {"success": False, "error": "WhatsApp is not focused."}

        # Ensure message box has focus
        time.sleep(0.08)

        # Paste text preserving emojis, special characters, and Hindi Devanagari
        ui_controller.paste_text(clean_msg, press_enter=False, delay_after=0.1)

        # Press Enter to send
        ui_controller.press_key('enter', delay_after=0.12)

        return {
            "success": True,
            "message": clean_msg,
            "result": "Message sent."
        }

    # ==================== Message Reading & UI Inspection ====================
    def read_latest_visible_message(self) -> Dict[str, Any]:
        """
        Inspects the visible WhatsApp chat UI to extract the latest visible message.
        Distinguishes between visible messages and contact names.
        If UI elements cannot be read, returns clear failure without hallucination.
        """
        if not self.ensure_focused():
            return {"success": False, "error": "WhatsApp is not focused."}

        hwnd = whatsapp_launcher.get_whatsapp_hwnd()
        if not hwnd:
            return {"success": False, "error": "WhatsApp window not found."}

        try:
            root = ui_controller.get_uia_element_from_hwnd(hwnd)
            if not root:
                return {
                    "success": False,
                    "error": "WhatsApp is open, but I couldn't read the visible messages from the screen."
                }

            # Search for text elements inside the message list
            # In WhatsApp WinUI 3, messages are in a ListView / ScrollViewer containing TextBlock elements
            uia_mod = ui_controller._uia_mod
            if not uia_mod or not ui_controller._uia:
                return {
                    "success": False,
                    "error": "WhatsApp is open, but UI accessibility data is unavailable."
                }

            cond_text = ui_controller._uia.CreatePropertyCondition(
                uia_mod.UIA_ControlTypePropertyId,
                uia_mod.UIA_TextControlTypeId
            )
            elements = root.FindAll(uia_mod.TreeScope_Descendants, cond_text)

            extracted_texts = []
            if elements:
                count = elements.Length
                # Traverse elements from bottom up to find recent messages
                for i in range(max(0, count - 30), count):
                    elem = elements.GetElement(i)
                    if elem:
                        txt = getattr(elem, "CurrentName", "").strip()
                        # Filter out common UI labels and timestamps
                        if txt and len(txt) > 1 and txt.lower() not in [
                            "type a message", "search or start new chat", "chats", "status",
                            "calls", "settings", "profile", "attach", "send", "emoji", "voice message"
                        ]:
                            # Filter timestamps like "10:45 AM", "Yesterday"
                            if not any(t_ind in txt.lower() for t_ind in ["am", "pm", "today", "yesterday"]) or len(txt) > 8:
                                extracted_texts.append(txt)

            if extracted_texts:
                latest = extracted_texts[-1]
                return {
                    "success": True,
                    "latest_message": latest,
                    "visible_messages": extracted_texts[-5:],
                    "result": f"Latest message: '{latest}'"
                }

        except Exception as e:
            logger.debug(f"Error reading WhatsApp messages: {e}")

        return {
            "success": False,
            "error": "WhatsApp is open, but I couldn't read the messages from the screen."
        }

    def read_unread_messages_summary(self) -> Dict[str, Any]:
        """
        Inspects the chat list for unread badges or messages.
        """
        if not self.ensure_focused():
            return {"success": False, "error": "WhatsApp is not focused."}

        hwnd = whatsapp_launcher.get_whatsapp_hwnd()
        if not hwnd:
            return {"success": False, "error": "WhatsApp window not found."}

        try:
            root = ui_controller.get_uia_element_from_hwnd(hwnd)
            if root and ui_controller._uia and ui_controller._uia_mod:
                uia_mod = ui_controller._uia_mod
                cond_text = ui_controller._uia.CreatePropertyCondition(
                    uia_mod.UIA_ControlTypePropertyId,
                    uia_mod.UIA_TextControlTypeId
                )
                elements = root.FindAll(uia_mod.TreeScope_Descendants, cond_text)
                unread_items = []
                if elements:
                    for i in range(min(40, elements.Length)):
                        elem = elements.GetElement(i)
                        txt = getattr(elem, "CurrentName", "").strip()
                        # Detect unread badge indicators or unread text
                        if "unread" in txt.lower():
                            unread_items.append(txt)

                if unread_items:
                    return {
                        "success": True,
                        "unread_count": len(unread_items),
                        "details": unread_items,
                        "result": f"You have {len(unread_items)} unread message notifications."
                    }

        except Exception as e:
            logger.debug(f"Error checking unread messages: {e}")

        return {
            "success": True,
            "unread_count": 0,
            "result": "No new unread messages visible."
        }

    # ==================== File Attachment ====================
    def attach_and_send_file(self, file_path: str) -> Dict[str, Any]:
        """
        Pastes a file from local filesystem into WhatsApp chat and sends it.
        Uses Windows clipboard file drop list (Set-Clipboard -Path).
        """
        if not os.path.isfile(file_path):
            return {"success": False, "error": f"File '{file_path}' does not exist."}

        if not self.ensure_focused():
            return {"success": False, "error": "WhatsApp is not focused."}

        # Put file into clipboard via PowerShell
        safe_path = os.path.abspath(file_path).replace("'", "''")
        ps_cmd = f"Set-Clipboard -Path '{safe_path}'"
        subprocess_res = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            capture_output=True,
            text=True,
            timeout=5
        )

        time.sleep(0.1)
        # Paste into WhatsApp chat
        ui_controller.press_hotkey('ctrl', 'v', delay_after=0.5)

        # Wait up to 1.5s for WhatsApp's file attachment preview dialog, then press Enter
        time.sleep(0.4)
        ui_controller.press_key('enter', delay_after=0.2)

        return {
            "success": True,
            "file": os.path.basename(file_path),
            "result": f"Sent file '{os.path.basename(file_path)}'."
        }

    # ==================== Calling Shortcuts ====================
    def trigger_call(self, call_type: str = "voice") -> Dict[str, Any]:
        """
        Triggers WhatsApp calling hotkeys:
        Voice: Ctrl+Shift+C
        Video: Ctrl+Shift+V
        """
        if not self.ensure_focused():
            return {"success": False, "error": "WhatsApp is not focused."}

        is_video = (call_type.lower() == "video")
        if is_video:
            ui_controller.press_hotkey('ctrl', 'shift', 'v', delay_after=0.2)
        else:
            ui_controller.press_hotkey('ctrl', 'shift', 'c', delay_after=0.2)

        return {
            "success": True,
            "call_type": "video" if is_video else "voice",
            "result": f"Started {'video' if is_video else 'voice'} call."
        }

# Global singleton instance
whatsapp_ui = WhatsAppUIController()
