import os
import time
import logging
from typing import Dict, Any, Optional, List

from backend.whatsapp.detector import whatsapp_detector
from backend.whatsapp.launcher import whatsapp_launcher
from backend.whatsapp.ui_controller import whatsapp_ui
from backend.whatsapp.context_manager import whatsapp_context
from backend.memory.contacts import contacts_manager
from backend.memory.conversations import conversation_manager

logger = logging.getLogger("MJ_WhatsAppActionExecutor")

class WhatsAppActionExecutor:
    """
    Executes WhatsApp operations with action verification, duplicate message
    protection, contact safety, and natural concise responses.
    """

    def __init__(self):
        # Recent message cache for duplicate send protection: {(contact, message): timestamp}
        self._recent_sends: Dict[tuple, float] = {}

    def _is_duplicate_send(self, contact: str, message: str, window_seconds: float = 6.0) -> bool:
        """Determines if the exact message was just sent to the same contact within the window."""
        key = (contact.lower().strip(), message.strip())
        now = time.time()
        last_time = self._recent_sends.get(key, 0.0)
        if (now - last_time) < window_seconds:
            return True
        return False

    def _record_send(self, contact: str, message: str):
        key = (contact.lower().strip(), message.strip())
        self._recent_sends[key] = time.time()
        # Clean up entries older than 30s
        now = time.time()
        self._recent_sends = {k: v for k, v in self._recent_sends.items() if (now - v) < 30.0}

    # ==================== 1. Open WhatsApp ====================
    def open_whatsapp(self, prefer_beta: bool = False) -> Dict[str, Any]:
        """Brings official WhatsApp Desktop to the foreground."""
        res = whatsapp_launcher.activate_or_launch(prefer_beta=prefer_beta)
        if res.get("success"):
            hwnd = res.get("hwnd")
            whatsapp_context.update_context(action="opened", window=hwnd)
            return {
                "success": True,
                "action": "open_whatsapp",
                "voice_response": "WhatsApp is open.",
                "summary": "WhatsApp Desktop opened and brought to foreground."
            }
        return {
            "success": False,
            "action": "open_whatsapp",
            "voice_response": "Could not open WhatsApp Desktop.",
            "summary": res.get("error", "Launch failed")
        }

    # ==================== 2. Search & Open Chat ====================
    def search_contact(self, contact_name: str) -> Dict[str, Any]:
        """Searches for contact in WhatsApp, opens their chat, and updates context."""
        clean = whatsapp_context.resolve_contact(contact_name)
        if not clean:
            return {
                "success": False,
                "voice_response": "Whose chat would you like me to open on WhatsApp?",
                "summary": "No contact specified"
            }

        # Check contact safety for ambiguity
        matches = contacts_manager.find_all_matching_contacts(clean)
        if len(matches) > 1:
            names = [m["name"] for m in matches[:3]]
            return {
                "success": False,
                "requires_clarification": True,
                "voice_response": f"I found multiple contacts matching {clean}: {', '.join(names)}. Which one do you mean?",
                "summary": f"Ambiguous contact query '{clean}' matches {names}"
            }

        target_name = matches[0]["name"] if matches else clean

        res = whatsapp_ui.search_and_open_chat(target_name)
        if res.get("success"):
            whatsapp_context.update_context(chat=target_name, contact=target_name, action="opened_chat")
            return {
                "success": True,
                "contact": target_name,
                "voice_response": f"{target_name}'s chat is open.",
                "summary": f"Opened chat with {target_name} on WhatsApp."
            }

        return {
            "success": False,
            "voice_response": f"WhatsApp is open, but I couldn't find {target_name}.",
            "summary": f"Could not find contact '{target_name}'"
        }

    # ==================== 3. Send Message ====================
    def send_message(self, contact_name: str, message_text: str) -> Dict[str, Any]:
        """
        Sends a WhatsApp message to the contact with duplicate protection and contact safety.
        """
        clean_msg = message_text.strip()
        if not clean_msg:
            return {
                "success": False,
                "voice_response": "What message would you like me to send?",
                "summary": "Empty message payload"
            }

        target = whatsapp_context.resolve_contact(contact_name)
        if not target:
            # Check if an active chat is already open in WhatsApp
            target = whatsapp_context.get_active_contact()
            if not target:
                return {
                    "success": False,
                    "voice_response": "Who would you like me to send this message to?",
                    "summary": "No recipient specified"
                }

        # Contact Safety: Check for ambiguity
        matches = contacts_manager.find_all_matching_contacts(target)
        if len(matches) > 1 and not (target.lower() == matches[0]["name"].lower()):
            names = [m["name"] for m in matches[:3]]
            return {
                "success": False,
                "requires_clarification": True,
                "voice_response": f"I found multiple contacts matching {target}: {', '.join(names)}. Which one do you mean?",
                "summary": f"Ambiguous contact '{target}'"
            }

        resolved_name = matches[0]["name"] if matches else target

        # Duplicate Message Protection
        if self._is_duplicate_send(resolved_name, clean_msg):
            logger.warning(f"Prevented duplicate send to {resolved_name}: '{clean_msg}'")
            return {
                "success": True,
                "duplicate_prevented": True,
                "voice_response": f"Sent to {resolved_name}.",
                "summary": f"Message already submitted to {resolved_name} (duplicate retry blocked)."
            }

        # Open chat if not currently active
        current_chat = whatsapp_context.state.get("current_chat", "").lower()
        if current_chat != resolved_name.lower():
            search_res = whatsapp_ui.search_and_open_chat(resolved_name)
            if not search_res.get("success"):
                return {
                    "success": False,
                    "voice_response": f"WhatsApp is open, but I couldn't locate {resolved_name}.",
                    "summary": f"Failed to open chat for {resolved_name}"
                }
            time.sleep(0.1)

        # Type and send
        send_res = whatsapp_ui.type_and_send_message(clean_msg)
        if send_res.get("success"):
            self._record_send(resolved_name, clean_msg)
            whatsapp_context.update_context(chat=resolved_name, contact=resolved_name, message=clean_msg, action="sent_message")
            conversation_manager.record_message(resolved_name, sender="mj", channel="whatsapp", content=clean_msg)
            return {
                "success": True,
                "contact": resolved_name,
                "message": clean_msg,
                "voice_response": f"Sent to {resolved_name}.",
                "summary": f"Sent message to {resolved_name} on WhatsApp."
            }

        return {
            "success": False,
            "voice_response": f"Failed to send message to {resolved_name}.",
            "summary": send_res.get("error", "Failed to send")
        }

    # ==================== 4. Reply to Message ====================
    def reply_message(self, message_text: str) -> Dict[str, Any]:
        """Replies to the currently active conversation or contact context."""
        active_contact = whatsapp_context.get_active_contact()
        if not active_contact:
            # Fallback to inspecting active window
            active_contact = whatsapp_ui.get_active_chat_title()

        if not active_contact:
            return {
                "success": False,
                "voice_response": "There is no active WhatsApp conversation to reply to.",
                "summary": "No active conversation context"
            }

        return self.send_message(active_contact, message_text)

    # ==================== 5. Read Messages ====================
    def read_latest_message(self, contact_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Reads the latest visible message from WhatsApp Desktop.
        Distinguishes between visible messages and contact names.
        Never hallucinates message contents.
        """
        target = whatsapp_context.resolve_contact(contact_name) if contact_name else whatsapp_context.get_active_contact()
        if target:
            current_chat = whatsapp_context.state.get("current_chat", "").lower()
            if current_chat != target.lower():
                self.search_contact(target)
                time.sleep(0.15)

        res = whatsapp_ui.read_latest_visible_message()
        if res.get("success"):
            msg = res.get("latest_message", "")
            whatsapp_context.update_context(message=msg, action="read_message")
            sender = target or "this chat"
            return {
                "success": True,
                "latest_message": msg,
                "voice_response": f"Latest message in {sender}: {msg}",
                "summary": f"Read latest message: {msg}"
            }

        return {
            "success": False,
            "voice_response": res.get("error", "I couldn't read the visible messages from WhatsApp."),
            "summary": "UI message inspection unavailable"
        }

    def read_unread_messages(self) -> Dict[str, Any]:
        """Summarizes unread WhatsApp notifications."""
        res = whatsapp_ui.read_unread_messages_summary()
        count = res.get("unread_count", 0)
        if count > 0:
            return {
                "success": True,
                "unread_count": count,
                "voice_response": f"You have {count} unread WhatsApp notifications.",
                "summary": res.get("result", "")
            }
        return {
            "success": True,
            "unread_count": 0,
            "voice_response": "You have no unread messages.",
            "summary": "No unread messages found."
        }

    # ==================== 6. Media / File Sending ====================
    def send_file(self, contact_name: str, file_query: str) -> Dict[str, Any]:
        """Locates requested file locally and sends it via WhatsApp."""
        from app_automator import automator

        target = whatsapp_context.resolve_contact(contact_name)
        if not target:
            target = whatsapp_context.get_active_contact()
        if not target:
            return {
                "success": False,
                "voice_response": "Who should I send this file to on WhatsApp?",
                "summary": "No recipient specified"
            }

        # Resolve file path
        clean_file = file_query.strip()
        for p in ["file ", "the file ", "called ", "named ", "my "]:
            if clean_file.lower().startswith(p):
                clean_file = clean_file[len(p):].strip()

        found_path = automator._find_file(clean_file)
        if not found_path:
            return {
                "success": False,
                "voice_response": f"I couldn't find the file '{clean_file}' on your computer.",
                "summary": f"File '{clean_file}' not found locally"
            }

        # Open chat if not already active
        current_chat = whatsapp_context.state.get("current_chat", "").lower()
        if current_chat != target.lower():
            self.search_contact(target)
            time.sleep(0.2)

        # Attach and send file
        res = whatsapp_ui.attach_and_send_file(found_path)
        if res.get("success"):
            fname = os.path.basename(found_path)
            whatsapp_context.update_context(chat=target, contact=target, action="sent_file")
            conversation_manager.record_message(target, sender="mj", channel="whatsapp", content=f"[Sent File: {fname}]")
            return {
                "success": True,
                "file": fname,
                "voice_response": f"Sent {fname} to {target}.",
                "summary": f"Uploaded and sent file '{fname}' to {target}."
            }

        return {
            "success": False,
            "voice_response": f"Failed to attach file for {target}.",
            "summary": res.get("error", "Attachment failed")
        }

    # ==================== 7. Calls ====================
    def start_call(self, contact_name: Optional[str] = None, call_type: str = "voice") -> Dict[str, Any]:
        """Initiates voice or video call on WhatsApp Desktop."""
        target = whatsapp_context.resolve_contact(contact_name) if contact_name else whatsapp_context.get_active_contact()
        if target:
            current_chat = whatsapp_context.state.get("current_chat", "").lower()
            if current_chat != target.lower():
                self.search_contact(target)
                time.sleep(0.2)

        res = whatsapp_ui.trigger_call(call_type=call_type)
        if res.get("success"):
            desc = "video call" if "video" in call_type.lower() else "call"
            name = target or "them"
            return {
                "success": True,
                "voice_response": f"Starting {desc} with {name}.",
                "summary": f"Initiated {call_type} call to {name}."
            }
        return {
            "success": False,
            "voice_response": "Failed to start WhatsApp call.",
            "summary": res.get("error", "Call trigger failed")
        }

    # ==================== 8. WhatsApp Status ====================
    def get_status(self) -> Dict[str, Any]:
        """Reports local WhatsApp installation, process, window, and context status."""
        pref = whatsapp_detector.get_preferred_target()
        is_installed = whatsapp_detector.is_desktop_installed()
        is_running = whatsapp_detector.is_process_running()
        hwnd = whatsapp_launcher.get_whatsapp_hwnd()
        active_chat = whatsapp_context.get_active_contact()

        status_parts = []
        if is_installed:
            status_parts.append(f"WhatsApp Desktop: installed ({pref.get('name')})")
        else:
            status_parts.append("WhatsApp Desktop: not installed (Web fallback available)")

        status_parts.append(f"Process: {'running' if is_running else 'stopped'}")
        status_parts.append(f"Window: {'detected' if hwnd else 'hidden/tray'}")
        if active_chat:
            status_parts.append(f"Active chat: {active_chat}")

        voice_msg = f"WhatsApp Desktop is {'running' if is_running else 'installed'}. "
        if active_chat:
            voice_msg += f"Active conversation with {active_chat}."
        else:
            voice_msg += "No conversation currently selected."

        return {
            "success": True,
            "is_installed": is_installed,
            "is_running": is_running,
            "target": pref,
            "hwnd": hwnd,
            "active_chat": active_chat,
            "voice_response": voice_msg,
            "summary": " | ".join(status_parts)
        }

# Global singleton instance
whatsapp_executor = WhatsAppActionExecutor()
