import os
import sys
import subprocess
import logging
from typing import Dict, Any, Optional, List

logger = logging.getLogger("MJ_WhatsAppDetector")

class WhatsAppDetector:
    """
    Detects WhatsApp installations on Windows according to strict target priority:
    Priority 1: Official WhatsApp Desktop (Stable UWP / Win32)
    Priority 2: Other local WhatsApp installations (Beta / standalone)
    Priority 3: Browser fallback (Web) ONLY if desktop is genuinely unavailable or requested.
    """

    UWP_STABLE_APP_ID = "5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App"
    UWP_STABLE_FAMILY = "5319275A.WhatsAppDesktop_cv1g1gvanyjgm"
    UWP_BETA_APP_ID = "5319275A.51895FA4EA97F_cv1g1gvanyjgm!App"
    UWP_BETA_FAMILY = "5319275A.51895FA4EA97F"

    PROCESS_NAMES = ["whatsapp.root.exe", "whatsapp.exe"]

    def __init__(self):
        self._cached_detection: Optional[Dict[str, Any]] = None

    def detect_all_installations(self) -> List[Dict[str, Any]]:
        """
        Detects all valid local WhatsApp installations on the user's PC.
        Returns a list of installation descriptors sorted by priority.
        """
        installations = []

        # 1. Detect Official UWP Stable
        stable_info = self._check_appx_package(self.UWP_STABLE_FAMILY)
        if stable_info:
            installations.append({
                "type": "uwp_stable",
                "name": "WhatsApp Desktop (Official Stable)",
                "app_id": self.UWP_STABLE_APP_ID,
                "path": stable_info.get("InstallLocation", ""),
                "version": stable_info.get("Version", ""),
                "priority": 1,
                "is_beta": False
            })

        # 2. Detect Win32 Desktop Installation (Program Files / LocalAppData)
        win32_paths = [
            os.path.expandvars(r"%LOCALAPPDATA%\WhatsApp\WhatsApp.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\WhatsApp\WhatsApp.exe"),
            os.path.expandvars(r"%PROGRAMFILES(X86)%\WhatsApp\WhatsApp.exe")
        ]
        for p in win32_paths:
            if os.path.isfile(p):
                installations.append({
                    "type": "win32_stable",
                    "name": "WhatsApp Desktop (Win32)",
                    "app_id": None,
                    "path": p,
                    "version": "Win32",
                    "priority": 1,
                    "is_beta": False
                })
                break

        # 3. Detect WhatsApp Beta UWP
        beta_info = self._check_appx_package(self.UWP_BETA_FAMILY)
        if beta_info:
            installations.append({
                "type": "uwp_beta",
                "name": "WhatsApp Beta",
                "app_id": self.UWP_BETA_APP_ID,
                "path": beta_info.get("InstallLocation", ""),
                "version": beta_info.get("Version", ""),
                "priority": 2,
                "is_beta": True
            })

        # 4. Check running process as confirmation if package query was blocked
        if not installations and self.is_process_running():
            installations.append({
                "type": "running_process",
                "name": "WhatsApp Desktop (Running)",
                "app_id": self.UWP_STABLE_APP_ID,
                "path": "",
                "version": "Live",
                "priority": 1,
                "is_beta": False
            })

        return sorted(installations, key=lambda x: x["priority"])

    def _check_appx_package(self, package_family: str) -> Optional[Dict[str, str]]:
        """Queries Windows AppX package registry/PowerShell for package presence."""
        try:
            cmd = f"Get-AppxPackage *{package_family.split('_')[0]}* | Select-Object Name, PackageFamilyName, Version, InstallLocation | ConvertTo-Json"
            proc = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
                capture_output=True,
                text=True,
                timeout=4
            )
            if proc.returncode == 0 and proc.stdout.strip():
                import json
                data = json.loads(proc.stdout)
                if isinstance(data, list):
                    for item in data:
                        if package_family in item.get("PackageFamilyName", ""):
                            return item
                    return data[0] if data else None
                elif isinstance(data, dict):
                    if package_family in data.get("PackageFamilyName", ""):
                        return data
                    return data
        except Exception as e:
            logger.debug(f"Appx query for {package_family} failed: {e}")
        return None

    def get_preferred_target(self, prefer_beta: bool = False) -> Dict[str, Any]:
        """
        Selects the best WhatsApp target according to Priority rules:
        - Stable Desktop preferred over Beta.
        - Beta only if prefer_beta is True or stable is missing.
        - Web fallback only if no desktop exists.
        """
        all_inst = self.detect_all_installations()

        if prefer_beta:
            beta_inst = [i for i in all_inst if i.get("is_beta")]
            if beta_inst:
                return beta_inst[0]

        stable_inst = [i for i in all_inst if not i.get("is_beta")]
        if stable_inst:
            return stable_inst[0]

        if all_inst:
            return all_inst[0]

        # Priority 3: Browser Fallback
        return {
            "type": "web_fallback",
            "name": "WhatsApp Web",
            "url": "https://web.whatsapp.com",
            "priority": 3,
            "is_beta": False
        }

    def is_desktop_installed(self) -> bool:
        """Returns True if any local WhatsApp Desktop installation exists."""
        target = self.get_preferred_target()
        return target["type"] != "web_fallback"

    def is_process_running(self) -> bool:
        """Checks if a WhatsApp desktop process is running in Windows tasklist."""
        try:
            proc = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq whatsapp.root.exe", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                timeout=2
            )
            if "whatsapp.root.exe" in proc.stdout.lower():
                return True
            proc2 = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq whatsapp.exe", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                timeout=2
            )
            return "whatsapp.exe" in proc2.stdout.lower()
        except Exception:
            return False

# Global singleton instance
whatsapp_detector = WhatsAppDetector()
