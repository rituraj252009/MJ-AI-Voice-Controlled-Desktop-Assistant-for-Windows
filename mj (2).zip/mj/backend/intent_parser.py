import re
import logging
from typing import Dict, Any, Optional, List

logger = logging.getLogger("MJ_IntentParser")

class SpokenIntentParser:
    """
    Ultra-Fast Direct Intent & Entity Extractor for Hindi, Hinglish, and English commands (<1ms).
    Handles both English SVO ('Open WhatsApp', 'Search Amit') and Hindi/Hinglish SOV ('WhatsApp kholo', 'Amit ko search karo').
    Preserves names and message content verbatim without translation overhead.
    """

    APP_ALIASES = {
        "whatsapp": ["whatsapp", "watsap", "watshap", "wapp", "व्हाट्सएप", "व्हाट्सऐप"],
        "youtube": ["youtube", "yt", "you tube", "यूूट्यूब", "यूट्यूब"],
        "chrome": ["chrome", "chrom", "google chrome", "browser", "क्रोम"],
        "notepad": ["notepad", "notpad", "नोटपैड", "notes"],
        "calculator": ["calculator", "calc", "calculater", "कैलकुलेटर"],
        "explorer": ["explorer", "file explorer", "files", "my files", "फ़ाइल एक्सप्लोरर", "फाइलें"],
        "spotify": ["spotify", "sotify", "spotfy", "स्पॉटिफ़ाई"],
        "vscode": ["vscode", "vs code", "code editor", "code"],
        "settings": ["settings", "setting", "सेटिंग्स"]
    }

    def deduplicate_repeated_phrase(self, text: str) -> str:
        s = text.strip()
        tokens = s.split()
        n = len(tokens)
        if n >= 4 and n % 2 == 0:
            half = n // 2
            if tokens[:half] == tokens[half:]:
                return " ".join(tokens[:half])
        return s

    def normalize_text(self, text: str) -> str:
        t = text.strip()
        t = re.sub(r'[,;.!?]+', ' ', t)
        t = " ".join(t.split())
        return self.deduplicate_repeated_phrase(t)

    def match_known_app(self, text_segment: str) -> Optional[str]:
        s = text_segment.lower().strip()
        # Direct equality check
        for canonical, aliases in self.APP_ALIASES.items():
            if s == canonical or s in aliases:
                return canonical
        # Substring / word boundary check
        for canonical, aliases in self.APP_ALIASES.items():
            for a in aliases:
                if re.search(r'\b' + re.escape(a) + r'\b', s):
                    return canonical
        return None

    def parse_compound_command(self, raw_text: str) -> Optional[List[Dict[str, Any]]]:
        """Splits compound instructions joined with 'aur', 'and', 'phir', 'then', 'karke'."""
        # Check for barge-in redirection: e.g. "Stop. Open WhatsApp instead." or "Ruko, Chrome kholo"
        m_barge_redirect = re.search(
            r"^(?:stop|ruko|ruk jao|cancel|wait|thahro)[\s.,;!]+(?:ab\s+|instead\s+|balki\s+)?(.+)",
            raw_text.strip(),
            re.IGNORECASE
        )
        if m_barge_redirect:
            second_cmd = m_barge_redirect.group(1).strip()
            for suffix in [" instead", " instead.", " balki", " ab"]:
                if second_cmd.lower().endswith(suffix):
                    second_cmd = second_cmd[:-len(suffix)].strip()
            second_intent = self.parse_single_command(second_cmd)
            if second_intent and second_intent.get("intent") != "conversational":
                return [
                    {"intent": "stop_task", "action": "interrupt"},
                    second_intent
                ]

        split_pattern = r"\s+(?:aur|and|phir|then|karke)\s+"
        parts = re.split(split_pattern, raw_text, flags=re.IGNORECASE)
        if len(parts) >= 2:
            parsed_steps = []
            for p in parts:
                p_clean = p.strip()
                if p_clean:
                    intent = self.parse_single_command(p_clean)
                    if intent and intent.get("intent") != "conversational":
                        parsed_steps.append(intent)
            if len(parsed_steps) >= 2:
                return parsed_steps
        return None

    def parse_single_command(self, text: str) -> Dict[str, Any]:
        clean = self.normalize_text(text)
        lower = clean.lower()

        # Remove polite prefix
        clean_prompt = lower
        for prefix in ["mj ", "hey mj ", "hello mj ", "please ", "kripya ", "zara ", "sunno ", "suno "]:
            if clean_prompt.startswith(prefix):
                clean_prompt = clean_prompt[len(prefix):].strip()
        clean_prompt = clean_prompt.rstrip("?.!,; ")
        # Map speech misrecognitions for action verbs
        clean_prompt = re.sub(r'\b(kolum|kholam|khlo)\b', 'kholo', clean_prompt)
        clean = re.sub(r'\b(kolum|kholam|khlo)\b', 'kholo', clean)

        # ==================== 0. Immediate Stop / Barge-In Cancellation ====================
        if clean_prompt in [
            "stop", "ruko", "ruk jao", "cancel", "wait", "thahro", "rok do",
            "chup", "chup ho jao", "bas", "stop it", "stopp", "chup raho", "रुक जाओ", "रुको"
        ]:
            return {"intent": "stop_task", "action": "stop"}

        # ==================== 1. Media Playback Controls ====================
        if clean_prompt in ["play", "play it", "play video", "chalao", "ise chalao", "chalu karo", "resume", "play karo", "video play karo", "video chalao"]:
            return {"intent": "media_control", "action": "play", "app": "youtube"}

        if clean_prompt in ["pause", "pause it", "stop it", "roko", "ise roko", "pause karo", "video roko", "video pause karo"]:
            return {"intent": "media_control", "action": "pause", "app": "youtube"}

        if clean_prompt in ["mute", "unmute", "aawaz band karo", "aawaj band karo", "mute karo", "volume band karo"]:
            return {"intent": "media_control", "action": "mute", "app": "youtube"}

        if clean_prompt in ["fullscreen", "full screen", "bada karo", "fullscreen karo", "full screen karo"]:
            return {"intent": "media_control", "action": "fullscreen", "app": "youtube"}

        if any(clean_prompt == t for t in [
            "open first result", "open first video", "pehle video kholo", "first video play karo",
            "pehle result par click karo", "open the first result", "open the first video", "pehla video chalao",
            "open the first one", "open first one", "first wala kholo", "pehla wala kholo"
        ]):
            return {"intent": "media_control", "action": "open_first_video", "app": "youtube"}

        # ==================== 1.5 System Telemetry & Hardware Controls ====================
        if any(clean_prompt == t or clean_prompt.startswith(t) for t in [
            "what is my battery level", "what is the battery level", "battery level", "battery status",
            "battery kitni hai", "check battery", "battery percentage", "battery"
        ]):
            return {"intent": "get_battery"}

        m_vol = re.search(r"^(?:set\s+)?volume\s+(?:to\s+)?(\d+)(?:\s*percent|\s*%)?", clean_prompt)
        if not m_vol:
            m_vol = re.search(r"^aawaz\s+(?:ko\s+)?(\d+)(?:\s*percent)?\s*(?:karo|par karo)?", clean_prompt)
        if m_vol:
            return {"intent": "set_volume", "level": int(m_vol.group(1))}

        if any(clean_prompt == t for t in ["take a screenshot", "take screenshot", "screenshot lo", "screen capture", "screenshot"]):
            return {"intent": "screenshot"}

        if any(clean_prompt == t for t in [
            "put my laptop to sleep", "sleep laptop", "laptop sleep karo", "laptop ko sulao",
            "put laptop to sleep", "sleep my laptop"
        ]):
            return {"intent": "sleep_laptop"}

        # Contextual repeat / continuation
        if any(clean_prompt == t for t in [
            "do the same here", "do the same thing in this app", "do the same in this app",
            "yahan bhi yahi karo", "isme bhi yahi karo", "continue", "carry on"
        ]):
            return {"intent": "context_continue", "is_contextual": True}

        # ==================== 1.8 Diagnostic Commands ====================
        if clean_prompt in [
            "mj status", "status", "system status", "status check", "assistant status",
            "mj ka status", "status batao", "check status"
        ]:
            return {"intent": "mj_status"}

        if clean_prompt in [
            "whatsapp status", "whatsapp ka status", "whatsapp status batao",
            "check whatsapp status", "whatsapp check karo"
        ]:
            return {"intent": "whatsapp_status"}

        # ==================== 2. WhatsApp Operations ====================
        # --- 2.1 WhatsApp Search Contact / Open Chat ---
        # Pattern: "Search <contact> on WhatsApp" / "Find <contact> on WhatsApp"
        m_wa_search_svo = re.search(
            r"^(?:search|find|dhundho|khojo)\s+([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+(?:on\s+whatsapp|par\s+whatsapp|in\s+whatsapp)$",
            clean,
            re.IGNORECASE
        )
        if m_wa_search_svo:
            return {
                "intent": "whatsapp_search",
                "application": "whatsapp",
                "contact": m_wa_search_svo.group(1).strip()
            }

        # Pattern: "<contact> ko WhatsApp par search karo"
        m_wa_search_sov = re.search(
            r"^([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+ko\s+whatsapp\s+par\s+(?:search|dhundho|khojo)\s*(?:karo|kar do)?$",
            clean,
            re.IGNORECASE
        )
        if m_wa_search_sov:
            return {
                "intent": "whatsapp_search",
                "application": "whatsapp",
                "contact": m_wa_search_sov.group(1).strip()
            }

        # Pattern: "<contact> ka/ki chat kholo" / "Open <contact>'s chat"
        m_wa_chat_open = re.search(
            r"^([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+(?:ka|ki)\s+(?:chat|conversation)\s+(?:kholo|open karo)$",
            clean,
            re.IGNORECASE
        )
        if m_wa_chat_open:
            return {
                "intent": "whatsapp_search",
                "application": "whatsapp",
                "contact": m_wa_chat_open.group(1).strip()
            }

        m_wa_chat_open2 = re.search(
            r"^(?:open|kholo)\s+([a-zA-Z0-9_\u0900-\u097F\s]+?)(?:'s|\s+ka|\s+ki)?\s+chat(?:\s+on\s+whatsapp|\s+par\s+whatsapp)?$",
            clean,
            re.IGNORECASE
        )
        if m_wa_chat_open2:
            return {
                "intent": "whatsapp_search",
                "application": "whatsapp",
                "contact": m_wa_chat_open2.group(1).strip()
            }

        # --- 2.2 WhatsApp Message Reading / Information Access ---
        if clean_prompt in [
            "unread messages dikhao", "unread messages", "unread message dikhao",
            "check unread messages", "show unread messages", "unread messages batao"
        ]:
            return {"intent": "whatsapp_unread"}

        m_read_active = re.search(
            r"^(?:is chat ka\s+)?(?:latest|last)\s+message\s+(?:kya hai|read karo|batao|padho|sunao)\??$",
            clean,
            re.IGNORECASE
        )
        if m_read_active or clean_prompt in ["last message kya hai", "latest message kya hai", "is chat ka latest message read karo"]:
            return {"intent": "whatsapp_read", "contact": ""}

        m_read_contact = re.search(
            r"^([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+(?:ne kya message kiya|ke last message ko read karke batao|ka last message kya hai|ka latest message padho|ka message padho)",
            clean,
            re.IGNORECASE
        )
        if m_read_contact:
            return {"intent": "whatsapp_read", "contact": m_read_contact.group(1).strip()}

        # --- 2.3 WhatsApp Replies ---
        m_reply_ctx = re.search(
            r"^(?:is message ka|iska|is chat ka|this message ka)\s+reply\s+karo\s*[:]?\s*(.+)",
            clean,
            re.IGNORECASE
        )
        if m_reply_ctx:
            return {
                "intent": "whatsapp_reply",
                "message": m_reply_ctx.group(1).strip()
            }

        m_reply_svo = re.search(
            r"^reply\s+(?:that\s+|saying\s+|:\s*)?(.+)",
            clean,
            re.IGNORECASE
        )
        if m_reply_svo:
            return {
                "intent": "whatsapp_reply",
                "message": m_reply_svo.group(1).strip()
            }

        m_reply_contact = re.search(
            r"^([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+ko\s+reply\s+karo\s*[:]?\s*(.+)",
            clean,
            re.IGNORECASE
        )
        if m_reply_contact:
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": m_reply_contact.group(1).strip(),
                "message": m_reply_contact.group(2).strip()
            }

        # --- 2.4 WhatsApp Send File ---
        m_send_file1 = re.search(
            r"^([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+ko\s+(?:ye\s+|this\s+)?(.+?)\s+whatsapp\s+par\s+(?:bhejo|send karo)$",
            clean,
            re.IGNORECASE
        )
        if m_send_file1 and any(ext in m_send_file1.group(2).lower() for ext in ["file", "pdf", "image", "photo", "document", ".txt", ".png", ".jpg", ".docx"]):
            return {
                "intent": "whatsapp_send_file",
                "contact": m_send_file1.group(1).strip(),
                "file": m_send_file1.group(2).strip()
            }

        m_send_file2 = re.search(
            r"^send\s+(?:this\s+)?(.+?)\s+to\s+([a-zA-Z0-9_\u0900-\u097F\s]+?)(?:\s+on\s+whatsapp|\s+par\s+whatsapp)?$",
            clean,
            re.IGNORECASE
        )
        if m_send_file2 and any(ext in m_send_file2.group(1).lower() for ext in ["file", "pdf", "image", "photo", "document", ".txt", ".png", ".jpg", ".docx"]):
            return {
                "intent": "whatsapp_send_file",
                "contact": m_send_file2.group(2).strip(),
                "file": m_send_file2.group(1).strip()
            }

        m_send_file3 = re.search(
            r"^attach\s+(?:this\s+)?(.+?)(?:\s+in\s+(?:the\s+)?(?:current\s+)?whatsapp\s+chat)?$",
            clean,
            re.IGNORECASE
        )
        if m_send_file3:
            return {
                "intent": "whatsapp_send_file",
                "contact": "",
                "file": m_send_file3.group(1).strip()
            }

        # --- 2.5 WhatsApp Messaging ---
        # Pronoun & colloquial follow-ups: "Usko bolo ...", "Tell him ...", "Now send ..."
        m_pronoun_bolo = re.search(
            r"^(?:usko|unhe|unko|usse)\s+(?:bolo|message karo|kaho|batao)\s*(?:ki|that|saying)?\s*[:]?\s*(.+)",
            clean,
            re.IGNORECASE
        )
        if m_pronoun_bolo:
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": "usko",
                "message": m_pronoun_bolo.group(1).strip()
            }

        m_tell_him = re.search(
            r"^tell\s+(?:him|her|them)\s+(?:that\s+)?(.+)",
            clean,
            re.IGNORECASE
        )
        if m_tell_him:
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": "him",
                "message": m_tell_him.group(1).strip()
            }

        m_now_send = re.search(
            r"^now\s+send\s*[:]?\s*(.+)",
            clean,
            re.IGNORECASE
        )
        if m_now_send:
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": "",
                "message": m_now_send.group(1).strip()
            }

        # Pattern: Send '<msg>' to <contact> [on WhatsApp]
        m_send_to_wa = re.search(
            r"^send\s+['\"]?(.+?)['\"]?\s+to\s+([a-zA-Z0-9_\u0900-\u097F\s]+?)(?:\s+on\s+whatsapp|\s+par\s+whatsapp)?$",
            clean,
            re.IGNORECASE
        )
        if m_send_to_wa:
            payload = m_send_to_wa.group(1).strip().strip("'\"")
            recip = m_send_to_wa.group(2).strip()
            is_file = any(payload.lower().endswith(ext) for ext in [".pdf", ".txt", ".png", ".jpg", ".docx", ".mp4"]) or payload.lower() in ["this pdf", "pdf", "file", "this file", "image", "photo"]
            if not is_file:
                return {
                    "intent": "send_message",
                    "application": "whatsapp",
                    "contact": recip,
                    "message": payload
                }

        # WhatsApp par <contact> ko bolo <msg>
        m_wa_bolo = re.search(
            r"^(?:whatsapp\s+par\s+|on\s+whatsapp\s+)([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+ko\s+(?:bolo|kaho|message karo)\s*(?:ki|that|saying)?\s*[:]?\s*(.+)",
            clean,
            re.IGNORECASE
        )
        if m_wa_bolo:
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": m_wa_bolo.group(1).strip(),
                "message": m_wa_bolo.group(2).strip()
            }

        # Case A: "<contact> ko message bhejo/karo [saying/that/ki] <msg>" or "<contact> ko whatsapp par message bhejo..."
        m_msg_sov = re.search(
            r"^([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+(?:ko|को)\s+(?:whatsapp\s+par\s+|on\s+whatsapp\s+|व्हाट्सएप\s+पर\s+|व्हाट्सऐप\s+पर\s+)?(?:message|text|sandesh|मैसेज|संदेश)\s+(?:bhejo|karo|kar do|भेजो|करो)\s*(?:saying|that|ki|likho|कि|लिखो)?\s*[:]?\s*(.*)",
            clean,
            re.IGNORECASE
        )
        if m_msg_sov:
            contact = m_msg_sov.group(1).strip()
            msg_content = m_msg_sov.group(2).strip()
            for p in ["to ", "my "]:
                if contact.lower().startswith(p):
                    contact = contact[len(p):].strip()
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": contact,
                "message": msg_content
            }

        # Case B: "Send message to <contact> [saying/that/ki] <msg>" / "Message <contact> [saying/that/ki] <msg>"
        m_msg_svo = re.search(
            r"^(?:send\s+(?:a\s+)?message\s+(?:to\s+)?|message\s+|text\s+|bhejo\s+message\s+(?:to\s+)?|संदेश\s+भेजो\s+|मैसेज\s+भेजो\s+)"
            r"([a-zA-Z0-9_\u0900-\u097F\s]+?)"
            r"(?:\s+on\s+whatsapp|\s+par\s+whatsapp|\s+ko|\s+को)?\s+"
            r"(?:saying|that|ki|likho|कि|लिखो|message|संदेश)\s*[:]?\s*(.+)",
            clean,
            re.IGNORECASE
        )
        if m_msg_svo:
            contact = m_msg_svo.group(1).strip()
            msg_content = m_msg_svo.group(2).strip()
            for p in ["to ", "ko ", "my "]:
                if contact.lower().startswith(p):
                    contact = contact[len(p):].strip()
            if contact.lower().endswith(" ko") or contact.endswith(" को"):
                contact = contact[:-3].strip()
            if contact.strip() == "राच":
                contact = "Raj"
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": contact,
                "message": msg_content
            }

        # Case B2: "Message to <contact>" / "Send message to <contact>" (without body -> opens contact chat)
        m_msg_target_only = re.search(
            r"^(?:send\s+(?:a\s+)?message\s+(?:to\s+)?|message\s+(?:to\s+)?|text\s+(?:to\s+)?|संदेश\s+भेजो\s+|मैसेज\s+भेजो\s+|मैसेज\s+करो\s+)"
            r"([a-zA-Z0-9_\u0900-\u097F\s]+?)"
            r"(?:\s+(?:on\s+whatsapp|par\s+whatsapp|whatsapp|व्हाट्सएप\s+पर|व्हाट्सऐप\s+पर|ko|को))?$",
            clean,
            re.IGNORECASE
        )
        if m_msg_target_only:
            contact = m_msg_target_only.group(1).strip()
            for p in ["to ", "ko ", "my "]:
                if contact.lower().startswith(p):
                    contact = contact[len(p):].strip()
            if contact.lower().endswith(" ko") or contact.endswith(" को"):
                contact = contact[:-3].strip()
            if contact.strip() == "राच":
                contact = "Raj"
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": contact,
                "message": ""
            }

        # Case C: Contextual follow-up: "Send it" / "Bhejo ise" / "Send message"
        if clean_prompt in ["send it", "bhejo", "ise bhejo", "send karo", "send kar do", "send this", "bhej do", "send", "भेजो", "इसे भेजो"]:
            return {
                "intent": "send_message",
                "application": "whatsapp",
                "contact": "",
                "message": ""
            }

        # ==================== 3. WhatsApp / Phone Calling ====================
        wa_tail = r"(?:\s+(?:on\s+whatsapp|par\s+whatsapp|(?:whatsapp|व्हाट्सएप|व्हाट्सऐप)\s*(?:par|पर|pe|पे|on)?))?"
        # SOV: "<contact> ko [whatsapp par] call karo [whatsapp par]"
        m_call_sov = re.search(
            r"^([a-zA-Z0-9_\u0900-\u097F\s]+?)\s+(?:ko|को)\s+"
            r"(?:whatsapp\s+(?:par|पर)\s+|on\s+whatsapp\s+|व्हाट्सएप\s+(?:par|पर)\s+|व्हाट्सऐप\s+(?:par|पर)\s+)?"
            r"(?:voice\s+|video\s+|वॉइस\s+|वीडियो\s+)?"
            r"(?:call|phone|कॉल|फोन)\s+(?:karo|lagao|kar do|करो|लगाओ|कर दो)"
            + wa_tail + r"$",
            clean_prompt,
            re.IGNORECASE
        )
        if m_call_sov:
            contact = m_call_sov.group(1).strip()
            if contact.strip() == "राच":
                contact = "Raj"
            c_type = "video" if ("video" in clean_prompt or "वीडियो" in clean_prompt) else "voice"
            return {
                "intent": "call",
                "application": "whatsapp",
                "contact": contact,
                "type": c_type
            }

        # SVO: "Call [to] <contact> [ko] [on whatsapp]"
        m_call_svo = re.search(
            r"^(?:voice\s+|video\s+|वॉइस\s+|वीडियो\s+)?(?:call|phone|कॉल|फोन)\s+(?:karo|lagao|करो|लगाओ)?\s*(?:to\s+)?([a-zA-Z0-9_\u0900-\u097F\s]+?)(?:\s+(?:ko|को))?"
            + wa_tail + r"$",
            clean_prompt,
            re.IGNORECASE
        )
        if m_call_svo:
            contact = m_call_svo.group(1).strip()
            for p in ["to ", "ko ", "my "]:
                if contact.startswith(p):
                    contact = contact[len(p):].strip()
            if contact.endswith(" ko") or contact.endswith(" को"):
                contact = contact[:-3].strip()
            if contact.strip() == "राच":
                contact = "Raj"
            c_type = "video" if ("video" in clean_prompt or "वीडियो" in clean_prompt) else "voice"
            return {
                "intent": "call",
                "application": "whatsapp",
                "contact": contact,
                "type": c_type
            }

        if any(clean_prompt == t for t in ["call them", "call him", "call her", "unhe call karo", "call lagao", "call karo", "कॉल करो", "कॉल लगाओ"]):
            c_type = "video" if ("video" in clean_prompt or "वीडियो" in clean_prompt) else "voice"
            return {
                "intent": "call",
                "application": "whatsapp",
                "contact": "",
                "type": c_type
            }

        # ==================== 4. In-App & Contextual Searching ====================
        # Pattern: "Is app mein <query> search karo" / "In this app search <query>"
        m_ctx_search = re.search(
            r"^(?:in this (?:app|tab|window)|is (?:app|tab|window) mein|is (?:app|tab|window) me|isme|ismein|here|yahan)\s+(?:search|find|dhundho|khojo)?\s*(.+)",
            clean_prompt
        )
        if m_ctx_search:
            raw_q = m_ctx_search.group(1).strip()
            # Clean search/dhundho/karo
            for p in ["search ", "find ", "dhundho ", "khojo "]:
                if raw_q.startswith(p):
                    raw_q = raw_q[len(p):].strip()
            if raw_q.endswith(" ko search karo"):
                raw_q = raw_q[:-15].strip()
            elif raw_q.endswith(" search karo"):
                raw_q = raw_q[:-12].strip()
            elif raw_q.endswith(" dhundho"):
                raw_q = raw_q[:-8].strip()
            elif raw_q.endswith(" khojo"):
                raw_q = raw_q[:-6].strip()
            if raw_q.endswith(" ko"):
                raw_q = raw_q[:-3].strip()

            return {
                "intent": "search_in_app",
                "query": raw_q,
                "application": None,
                "is_contextual": True
            }

        # Pattern: "<app> mein/par <query> search/play karo" (e.g. "YouTube par Java DSA search karo")
        m_app_search = re.search(
            r"^([a-zA-Z0-9_\u0900-\u097F]+)\s+(?:mein|me|par|in)\s+(.+?)(?:\s+ko)?\s+(?:search|dhundho|khojo|play|chalao)\s*(?:karo|kar do)?$",
            clean_prompt
        )
        if m_app_search:
            app_word = m_app_search.group(1).strip()
            query = m_app_search.group(2).strip()
            matched_app = self.match_known_app(app_word)
            return {
                "intent": "search_in_app",
                "query": query,
                "application": matched_app or app_word,
                "is_contextual": False
            }

        # Pattern: "<query> search karo" / "<query> dhundho" / "<contact> ko search karo"
        m_sov_search = re.search(
            r"^(.+?)(?:\s+ko)?\s+(?:search|dhundho|khojo)\s*(?:karo|kar do)?$",
            clean_prompt
        )
        if m_sov_search and not clean_prompt.startswith("open") and not clean_prompt.startswith("kholo"):
            query = m_sov_search.group(1).strip()
            # Exclude trivial non-queries
            if query not in ["kya", "kaise", "yahan", "isme"]:
                return {
                    "intent": "search_in_app",
                    "query": query,
                    "application": None,
                    "is_contextual": True
                }

        # SVO Pattern: "Search <query> in <app>" / "Search <query>"
        m_svo_search = re.search(
            r"^(?:search|find|dhundho|khojo)\s+(?:for\s+)?(.+?)(?:\s+(?:in|inside|par|on)\s+(.+))?$",
            clean_prompt
        )
        if m_svo_search:
            query = m_svo_search.group(1).strip()
            loc = m_svo_search.group(2).strip() if m_svo_search.group(2) else ""
            # Check if this is a local folder request (e.g., "find my Downloads folder")
            q_lower = query.lower()
            if "folder" in q_lower or q_lower in ("downloads", "documents", "desktop"):
                fol_clean = q_lower
                for p in ["my ", "the ", "folder "]:
                    if fol_clean.startswith(p):
                        fol_clean = fol_clean[len(p):].strip()
                if fol_clean.endswith(" folder"):
                    fol_clean = fol_clean[:-7].strip()
                return {"intent": "open_folder", "folder": fol_clean}

            matched_app = self.match_known_app(loc) if loc else None
            is_ctx = (not loc) or any(c in loc for c in ["this", "it", "here", "is app", "is tab"])
            return {
                "intent": "search_in_app",
                "query": query,
                "application": matched_app,
                "is_contextual": is_ctx
            }

        # ==================== 5. In-App Typing & Writing ====================
        m_write = re.search(
            r"^(?:type|write|likho|enter)\s*(?:this\s*:\s*|that\s*:\s*|in it\s+|isme\s+)?(.+)",
            clean,
            re.IGNORECASE
        )
        if m_write:
            content = m_write.group(1).strip()
            for prefix in ["this: ", "this ", "that: ", "that ", ": "]:
                if content.lower().startswith(prefix):
                    content = content[len(prefix):].strip()
            return {
                "intent": "type_in_app",
                "text": content,
                "is_contextual": True
            }

        # ==================== 6. Contextual Saving & Closing ====================
        if any(clean_prompt.startswith(w) for w in ["save this", "save as", "save it as", "save karo", "ise save karo", "save document"]):
            save_name_match = re.search(r"save\s+(?:this\s+|document\s+|file\s+|it\s+)?(?:as\s+)?(.+)", clean_prompt)
            fname = save_name_match.group(1).strip() if save_name_match else ""
            if fname in ["file", "document", "it", "karo", "ise"]:
                fname = ""
            return {
                "intent": "save_file",
                "file_name": fname,
                "is_contextual": True
            }

        if clean_prompt in ["close it", "close this", "close this tab", "close window", "ise band karo", "band karo"]:
            return {
                "intent": "close_context",
                "is_contextual": True
            }

        # ==================== 7. Local Files & Folders ====================
        FILE_EXTENSIONS = ('.py', '.txt', '.pdf', '.docx', '.doc', '.json', '.csv', '.xlsx', '.png', '.jpg', '.mp4', '.mp3', '.md', '.cpp', '.java', '.html', '.css', '.js', '.c', '.rs')
        FILE_KEYWORDS = ('resume', 'cv', 'biodata', 'notes', 'document', 'spreadsheet', 'presentation')
        SPECIAL_FOLDERS = ('downloads', 'documents', 'desktop', 'pictures', 'videos', 'music')

        if any(clean_prompt == t for t in ["open my files", "open files", "show my files", "file explorer", "files dikhao", "open explorer"]):
            return {"intent": "open_explorer"}

        # Pattern: find/open <name> folder
        fol_match = re.search(r"^(?:open|show|find|kholo|dhundho)\s+(?:my\s+|the\s+)?folder(?:\s+(?:named|called)\s+|\s+)?(.+)", clean_prompt)
        if not fol_match:
            fol_match = re.search(r"^(?:open|show|find|kholo|dhundho)\s+(?:my\s+|the\s+)?(.+?)\s+folder$", clean_prompt)
        if fol_match:
            return {"intent": "open_folder", "folder": fol_match.group(1).strip()}

        file_match = re.search(r"^(?:open|find|kholo|dhundho)\s+(?:the\s+|my\s+)?(?:file|document)\s+(.+)", clean_prompt)
        if file_match:
            return {"intent": "open_file", "file": file_match.group(1).strip()}

        # ==================== 8. Application & File Launching (SVO and SOV) ====================
        def _classify_target(target_name: str) -> Dict[str, Any]:
            t = target_name.strip()
            t_lower = t.lower()
            # 1. Check if folder
            if t_lower in SPECIAL_FOLDERS or t_lower.endswith(" folder"):
                clean_fol = t_lower[:-7].strip() if t_lower.endswith(" folder") else t_lower
                return {"intent": "open_folder", "folder": clean_fol}
            # 2. Check if file (extension or file keywords)
            if any(t_lower.endswith(ext) for ext in FILE_EXTENSIONS) or any(fk in t_lower for fk in FILE_KEYWORDS):
                return {"intent": "open_file", "file": t}
            # 3. Application matching
            if t_lower.endswith(" app"):
                t_lower = t_lower[:-4].strip()
            matched_app = self.match_known_app(t_lower)
            return {"intent": "open_app", "application": matched_app or t}

        # SOV Pattern: "<app/file> kholo" / "<app/file> open karo" / "<app/file> chalao" / "<app/file> खोलो"
        m_open_sov = re.search(
            r"^([a-zA-Z0-9_.\u0900-\u097F\s]+?)\s+(?:kholo|open karo|start karo|chalao|launch karo|खोलो)$",
            clean_prompt
        )
        if m_open_sov:
            return _classify_target(m_open_sov.group(1))

        # SVO Pattern: "Open <app/file>" / "Launch <app>" / "Start <app>" / "Kholo <app/file>" / "Find <file>"
        m_open_svo = re.search(
            r"^(?:open|launch|start|kholo|chalao|find)\s+(?:my\s+|the\s+)?(.+)",
            clean_prompt
        )
        if m_open_svo:
            return _classify_target(m_open_svo.group(1))

        # Fallback
        return {
            "intent": "conversational",
            "raw_text": text
        }

    def parse(self, text: str) -> Dict[str, Any]:
        compound = self.parse_compound_command(text)
        if compound:
            return {
                "is_compound": True,
                "steps": compound,
                "raw_text": text
            }

        single = self.parse_single_command(text)
        single["is_compound"] = False
        single["raw_text"] = text
        return single


# Global singleton instance
intent_parser = SpokenIntentParser()
