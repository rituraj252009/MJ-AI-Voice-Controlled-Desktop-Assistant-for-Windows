import os
import time
import subprocess
import logging
from typing import Dict, Any, Optional, List

from backend.adapters.base_adapter import BaseAdapter
from backend.ui_controller import ui_controller
from backend.context_engine import context_engine
from backend.local_policy import local_policy

logger = logging.getLogger("MJ_ExplorerAdapter")

class ExplorerAdapter(BaseAdapter):
    """
    Dedicated Adapter for Windows File Explorer and Local File System.
    Guarantees:
    - Deep search across user folders without triggering web search
    - Opens files and folders natively in Windows Explorer
    - Operates file management (create, delete, rename, reveal)
    """

    def __init__(self):
        super().__init__("explorer")

    def is_installed(self) -> bool:
        return True

    def is_running(self) -> bool:
        wins = ui_controller.find_windows(process_names=["explorer.exe"])
        return len(wins) > 0

    def activate(self) -> bool:
        wins = ui_controller.find_windows(process_names=["explorer.exe"])
        for w in wins:
            if w["title"] and not w["title"] in ["Taskbar", "Program Manager", ""]:
                return ui_controller.bring_to_foreground(w["hwnd"])
        return self.open_explorer()

    def _get_search_roots(self) -> List[str]:
        user_home = os.path.expanduser("~")
        roots = [
            os.path.join(user_home, "Desktop"),
            os.path.join(user_home, "Documents"),
            os.path.join(user_home, "Downloads"),
            os.path.join(user_home, "Pictures"),
            os.path.join(user_home, "Videos"),
            os.path.join(user_home, "Music"),
            user_home
        ]
        return [r for r in roots if os.path.exists(r)]

    def find_local_folder(self, folder_name: str) -> Optional[str]:
        """Performs deep search for folder across user directories."""
        clean = folder_name.lower().strip()
        roots = self._get_search_roots()

        # 1. Exact top-level match
        for r in roots:
            p = os.path.join(r, clean)
            if os.path.isdir(p):
                return p

        # 2. Case-insensitive substring match (depth 2)
        skip_dirs = {"appdata", "node_modules", ".git", ".gemini", "venv", ".venv", "cache", "site-packages", ".config"}
        for r in roots:
            try:
                for root, dirs, _ in os.walk(r):
                    # Prune skip directories in-place for blazing fast scans
                    dirs[:] = [d for d in dirs if not d.startswith('.') and d.lower() not in skip_dirs]
                    depth = root[len(r):].count(os.sep)
                    if depth > 2:
                        continue
                    for d in dirs:
                        if clean in d.lower():
                            return os.path.join(root, d)
            except Exception:
                pass
        return None

    def find_local_file(self, file_name: str) -> Optional[str]:
        """Performs deep search for file across user directories."""
        clean = file_name.lower().strip()
        roots = self._get_search_roots()

        # 1. Exact top-level match
        for r in roots:
            p = os.path.join(r, clean)
            if os.path.isfile(p):
                return p

        # 2. Case-insensitive substring match (depth 3)
        skip_dirs = {"appdata", "node_modules", ".git", ".gemini", "venv", ".venv", "cache", "site-packages", ".config"}
        for r in roots:
            try:
                for root, dirs, files in os.walk(r):
                    # Prune skip directories in-place
                    dirs[:] = [d for d in dirs if not d.startswith('.') and d.lower() not in skip_dirs]
                    depth = root[len(r):].count(os.sep)
                    if depth > 3:
                        continue
                    for f in files:
                        if clean in f.lower():
                            return os.path.join(root, f)
            except Exception:
                pass
        return None

    def open_explorer(self, path: Optional[str] = None) -> bool:
        """Opens File Explorer at target directory or default Quick Access."""
        try:
            if path and os.path.exists(path):
                subprocess.Popen(["explorer.exe", path])
            else:
                subprocess.Popen(["explorer.exe"])
            context_engine.update_task_state(action="opened_explorer", app="explorer", target=path or "")
            return True
        except Exception as e:
            logger.error(f"open_explorer error: {e}")
            return False

    def open_folder(self, folder_name: str) -> Dict[str, Any]:
        """Finds and opens folder in File Explorer."""
        clean = folder_name.strip()
        found = self.find_local_folder(clean)
        if found:
            self.open_explorer(found)
            return {
                "success": True,
                "path": found,
                "result": f"Opened folder '{os.path.basename(found)}' in File Explorer, Sir."
            }
        # Strict local policy: NEVER fallback to Google search!
        return local_policy.handle_missing_local_target(clean, target_type="folder")

    def open_file(self, file_name: str) -> Dict[str, Any]:
        """Finds and opens file with associated program."""
        clean = file_name.strip()
        found = self.find_local_file(clean)
        if found:
            try:
                os.startfile(found)
                context_engine.update_task_state(action="opened_file", app="file", target=os.path.basename(found))
                return {
                    "success": True,
                    "path": found,
                    "result": f"Opened file '{os.path.basename(found)}', Sir."
                }
            except Exception as e:
                return {"success": False, "error": str(e)}
        # Strict local policy: NEVER fallback to Google search!
        return local_policy.handle_missing_local_target(clean, target_type="file")

    def execute_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        act = action.lower().strip()

        if act in ["open_explorer", "explorer"]:
            path = params.get("path")
            success = self.open_explorer(path)
            return {"success": success, "result": "Opened File Explorer, Sir."}

        elif act in ["open_folder", "folder"]:
            folder = params.get("folder") or params.get("name") or params.get("target") or ""
            return self.open_folder(folder)

        elif act in ["open_file", "file"]:
            f = params.get("file") or params.get("name") or params.get("target") or ""
            return self.open_file(f)

        return {"success": False, "error": f"Unknown explorer action '{action}'"}


# Global singleton instance
explorer_adapter = ExplorerAdapter()
