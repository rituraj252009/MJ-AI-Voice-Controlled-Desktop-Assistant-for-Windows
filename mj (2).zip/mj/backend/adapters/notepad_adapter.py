import os
import time
import subprocess
import logging
from typing import Dict, Any, Optional
import pyautogui

from backend.adapters.base_adapter import BaseAdapter
from backend.ui_controller import ui_controller
from backend.context_engine import context_engine

logger = logging.getLogger("MJ_NotepadAdapter")

class NotepadAdapter(BaseAdapter):
    """
    Dedicated Adapter for Notepad & Text Editing.
    Supports in-app operations: typing, saving, file naming, and menu control.
    """

    def __init__(self):
        super().__init__("notepad")

    def is_installed(self) -> bool:
        return True

    def is_running(self) -> bool:
        wins = ui_controller.find_windows(process_names=["notepad.exe"])
        return len(wins) > 0

    def get_notepad_hwnd(self) -> Optional[int]:
        wins = ui_controller.find_windows(process_names=["notepad.exe"])
        if wins:
            return wins[0]["hwnd"]
        return None

    def activate(self) -> bool:
        hwnd = self.get_notepad_hwnd()
        if hwnd:
            return ui_controller.bring_to_foreground(hwnd)
        try:
            subprocess.Popen(["notepad.exe"])
            time.sleep(0.3)
            context_engine.update_task_state(action="opened", app="notepad")
            return True
        except Exception:
            return False

    def write_text(self, text: str) -> Dict[str, Any]:
        """Pastes text into the active Notepad document."""
        self.activate()
        time.sleep(0.08)
        ui_controller.paste_text(text, delay_after=0.1)
        context_engine.update_task_state(action="typed_text", app="notepad")
        return {"success": True, "result": "Written text into Notepad, Sir."}

    def save_file(self, file_name: Optional[str] = None) -> Dict[str, Any]:
        """Saves current document; if file_name is specified, enters filename in Save dialog."""
        self.activate()
        time.sleep(0.08)
        ui_controller.press_hotkey('ctrl', 's', delay_after=0.3)

        if file_name:
            time.sleep(0.2)
            ui_controller.paste_text(file_name, press_enter=True, delay_after=0.2)
            context_engine.update_task_state(action="saved_file", target=file_name, app="notepad")
            return {"success": True, "result": f"Saved document as '{file_name}', Sir."}

        context_engine.update_task_state(action="saved_file", app="notepad")
        return {"success": True, "result": "Saved document, Sir."}

    def execute_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        act = action.lower().strip()

        if act in ["open", "activate", "launch"]:
            success = self.activate()
            return {"success": success, "result": "Opened Notepad, Sir."}

        elif act in ["write", "type", "write_text"]:
            text = params.get("text") or params.get("content") or ""
            return self.write_text(text)

        elif act in ["save", "save_as"]:
            fname = params.get("file_name") or params.get("filename") or params.get("name")
            return self.save_file(fname)

        return {"success": False, "error": f"Unknown notepad action '{action}'"}


# Global singleton instance
notepad_adapter = NotepadAdapter()
