import os
import time
import subprocess
import logging
from typing import Dict, Any, Optional, List
import pyautogui

from backend.adapters.base_adapter import BaseAdapter
from backend.ui_controller import ui_controller
from backend.context_engine import context_engine
from backend.local_policy import local_policy

logger = logging.getLogger("MJ_GenericAdapter")

class GenericAdapter(BaseAdapter):
    """
    Generic Windows UI & Application Control Adapter.
    Controls arbitrary desktop applications (VS Code, Calculator, Settings, etc.)
    using native Win32 activation, keyboard/mouse input, and UI Automation.
    """

    BUILTIN_APPS = {
        "calculator": "calc.exe",
        "calc": "calc.exe",
        "notepad": "notepad.exe",
        "paint": "mspaint.exe",
        "taskmgr": "taskmgr.exe",
        "cmd": "cmd.exe",
        "terminal": "wt.exe",
        "settings": "ms-settings:",
        "explorer": "explorer.exe",
        "vscode": "code"
    }

    def __init__(self):
        super().__init__("generic")

    def is_installed(self) -> bool:
        return True

    def is_running(self) -> bool:
        ctx = context_engine.get_active_context()
        return bool(ctx.get("active_window_hwnd"))

    def activate(self) -> bool:
        ctx = context_engine.get_active_context()
        hwnd = ctx.get("active_window_hwnd")
        if hwnd:
            return ui_controller.bring_to_foreground(hwnd)
        return False

    def find_start_menu_app(self, app_name: str) -> Optional[str]:
        """Searches Windows Start Menu shortcuts (.lnk) for matching application."""
        clean = app_name.lower().strip()
        search_dirs = [
            os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs"),
            os.path.expandvars(r"%ProgramData%\Microsoft\Windows\Start Menu\Programs")
        ]
        for sdir in search_dirs:
            if not os.path.exists(sdir):
                continue
            try:
                for root, _, files in os.walk(sdir):
                    for f in files:
                        if f.lower().endswith(".lnk") and clean in f.lower():
                            return os.path.join(root, f)
            except Exception:
                pass
        return None

    def open_app(self, app_name: str) -> Dict[str, Any]:
        """Launches a desktop app by name with strict local-first policy."""
        clean = app_name.lower().strip()

        # 1. Built-in apps
        if clean in self.BUILTIN_APPS:
            target_cmd = self.BUILTIN_APPS[clean]
            try:
                if target_cmd.startswith("ms-settings:"):
                    subprocess.Popen(["explorer.exe", target_cmd])
                else:
                    subprocess.Popen([target_cmd], shell=True)
                context_engine.update_task_state(action="opened", app=clean)
                return {"success": True, "result": f"Opened {clean.title()}, Sir."}
            except Exception as e:
                return {"success": False, "error": str(e)}

        # 2. Check running windows by process / title
        matched = ui_controller.find_windows(process_names=[clean], title_substr=clean)
        if matched:
            ui_controller.bring_to_foreground(matched[0]["hwnd"])
            context_engine.update_task_state(action="activated", app=clean)
            return {"success": True, "result": f"Switched to {clean.title()}, Sir."}

        # 3. Start Menu Shortcuts
        shortcut = self.find_start_menu_app(clean)
        if shortcut:
            try:
                os.startfile(shortcut)
                context_engine.update_task_state(action="launched", app=clean)
                return {"success": True, "result": f"Opened {os.path.splitext(os.path.basename(shortcut))[0]}, Sir."}
            except Exception as e:
                return {"success": False, "error": str(e)}

        # 4. Strict Local-First Policy: NEVER fallback to Google Search!
        return local_policy.handle_missing_local_target(clean, target_type="application")

    def execute_in_active_window(self, task_type: str, payload: str = "") -> Dict[str, Any]:
        """Performs a generic action inside the currently active foreground window."""
        ctx = context_engine.get_active_context()
        hwnd = ctx.get("active_window_hwnd")
        app = ctx.get("active_application") or "active window"

        if hwnd:
            ui_controller.bring_to_foreground(hwnd)

        t = task_type.lower().strip()
        if t in ["write_text", "type", "insert"]:
            ui_controller.paste_text(payload, press_enter=False, delay_after=0.1)
            return {"success": True, "result": f"Typed into {app}, Sir."}

        elif t in ["search_inside", "find"]:
            ui_controller.press_hotkey('ctrl', 'f', delay_after=0.1)
            ui_controller.press_hotkey('ctrl', 'a', delay_after=0.04)
            ui_controller.press_key('backspace', delay_after=0.05)
            ui_controller.paste_text(payload, press_enter=True, delay_after=0.2)
            return {"success": True, "result": f"Searching for '{payload}' in {app}, Sir."}

        elif t in ["press_key", "key"]:
            ui_controller.press_key(payload, delay_after=0.05)
            return {"success": True, "result": f"Pressed {payload}, Sir."}

        elif t in ["hotkey", "shortcut"]:
            keys = [k.strip().lower() for k in payload.split("+")]
            ui_controller.press_hotkey(*keys, delay_after=0.1)
            return {"success": True, "result": f"Executed shortcut {payload}, Sir."}

        elif t in ["scroll"]:
            direction = payload.lower().strip()
            amount = -500 if direction == "down" else 500
            pyautogui.scroll(amount)
            return {"success": True, "result": f"Scrolled {direction}, Sir."}

        elif t in ["save"]:
            ui_controller.press_hotkey('ctrl', 's', delay_after=0.2)
            if payload:
                time.sleep(0.15)
                ui_controller.paste_text(payload, press_enter=True, delay_after=0.2)
            return {"success": True, "result": f"Saved document in {app}, Sir."}

        elif t in ["close", "close_window"]:
            ui_controller.press_hotkey('alt', 'f4', delay_after=0.2)
            return {"success": True, "result": f"Closed {app}, Sir."}

        return {"success": False, "error": f"Unknown generic task '{task_type}'"}

    def execute_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        act = action.lower().strip()

        if act in ["open_app", "open", "launch"]:
            app_name = params.get("app") or params.get("name") or params.get("target") or ""
            return self.open_app(app_name)

        elif act in ["context_task", "in_app_action"]:
            task = params.get("task", "write_text")
            payload = params.get("payload", "")
            return self.execute_in_active_window(task, payload)

        return {"success": False, "error": f"Unknown generic action '{action}'"}


# Global singleton instance
generic_adapter = GenericAdapter()
