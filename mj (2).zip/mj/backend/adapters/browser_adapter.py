import os
import time
import urllib.parse
import webbrowser
import logging
from typing import Dict, Any, Optional, List
import pyautogui
import pyperclip

from backend.adapters.base_adapter import BaseAdapter
from backend.ui_controller import ui_controller
from backend.context_engine import context_engine

logger = logging.getLogger("MJ_BrowserAdapter")

class BrowserAdapter(BaseAdapter):
    """
    Dedicated Browser & YouTube Control Adapter for Chrome and Edge.
    Solves the 'new tab on every command' problem:
    - Reuses existing active browser windows and YouTube tabs.
    - Controls YouTube playback (play, pause, search, mute, fullscreen) in the active tab.
    - Performs in-page search via native YouTube shortcut '/' without reloading.
    - Opens a new tab ONLY when explicitly requested.
    """

    BROWSER_PROCESSES = ["chrome.exe", "msedge.exe", "brave.exe", "firefox.exe"]

    def __init__(self):
        super().__init__("browser")
        self.active_tab_type = "general"
        self.last_query = ""

    def is_installed(self) -> bool:
        return True

    def is_running(self) -> bool:
        wins = ui_controller.find_windows(process_names=self.BROWSER_PROCESSES)
        return len(wins) > 0

    def find_browser_windows(self) -> List[Dict[str, Any]]:
        """Finds all open browser windows."""
        return ui_controller.find_windows(process_names=self.BROWSER_PROCESSES)

    def find_youtube_window(self) -> Optional[Dict[str, Any]]:
        """Finds browser window that currently has a YouTube tab open."""
        wins = self.find_browser_windows()
        for w in wins:
            if "youtube" in w["title"].lower():
                return w
        return None

    def activate(self) -> bool:
        """Brings the most relevant browser window to the foreground."""
        yt_win = self.find_youtube_window()
        if yt_win:
            return ui_controller.bring_to_foreground(yt_win["hwnd"])

        wins = self.find_browser_windows()
        if wins:
            return ui_controller.bring_to_foreground(wins[0]["hwnd"])

        # Launch default browser
        webbrowser.open("https://www.google.com")
        return True

    def open_youtube(self, query: Optional[str] = None, force_new_tab: bool = False) -> Dict[str, Any]:
        """
        Reuses existing YouTube tab if open; otherwise navigates current tab or opens browser.
        """
        yt_win = self.find_youtube_window()

        if yt_win and not force_new_tab:
            # YouTube tab is ALREADY OPEN! Reuse it!
            ui_controller.bring_to_foreground(yt_win["hwnd"])
            time.sleep(0.1)

            if query:
                return self.search_youtube(query)

            context_engine.update_task_state(action="activated_youtube", app="youtube", task="watching")
            return {
                "success": True,
                "reused_tab": True,
                "result": "Switched to your existing YouTube tab, Sir."
            }

        # Check if another browser window is active
        browser_wins = self.find_browser_windows()
        if browser_wins and not force_new_tab:
            # Navigate current tab of active browser window
            ui_controller.bring_to_foreground(browser_wins[0]["hwnd"])
            time.sleep(0.1)
            target_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(query)}" if query else "https://www.youtube.com"
            
            # Navigate current tab via address bar (Ctrl+L) to avoid new tab
            ui_controller.press_hotkey('ctrl', 'l', delay_after=0.05)
            ui_controller.paste_text(target_url, press_enter=True, delay_after=0.3)

            context_engine.update_task_state(action="navigated_youtube", app="youtube", target=query or "")
            return {
                "success": True,
                "reused_tab": True,
                "result": f"Opened YouTube{' for ' + query if query else ''} in current tab, Sir."
            }

        # Fallback: Open browser
        target_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(query)}" if query else "https://www.youtube.com"
        webbrowser.open(target_url)
        context_engine.update_task_state(action="opened_youtube", app="youtube", target=query or "")
        return {
            "success": True,
            "reused_tab": False,
            "result": f"Opened YouTube{' for ' + query if query else ''}, Sir."
        }

    def search_youtube(self, query: str) -> Dict[str, Any]:
        """
        Searches inside the currently active YouTube tab without opening a new tab.
        Uses YouTube's native in-page search shortcut '/' or URL bar navigation.
        """
        clean_query = query.strip()
        if not clean_query:
            return {"success": False, "error": "Search query is required"}

        yt_win = self.find_youtube_window()
        if yt_win:
            ui_controller.bring_to_foreground(yt_win["hwnd"])
            time.sleep(0.12)
            # In YouTube: '/' immediately focuses the YouTube in-page search box
            ui_controller.press_key('/', delay_after=0.08)
            ui_controller.press_hotkey('ctrl', 'a', delay_after=0.04)
            ui_controller.press_key('backspace', delay_after=0.05)
            ui_controller.paste_text(clean_query, press_enter=True, delay_after=0.3)
        else:
            # If not in YouTube, navigate
            return self.open_youtube(clean_query)

        self.last_query = clean_query
        context_engine.update_task_state(action="searched_youtube", target=clean_query, app="youtube", task="search_results")
        return {
            "success": True,
            "query": clean_query,
            "result": f"Searched '{clean_query}' inside YouTube, Sir."
        }

    def play_pause(self) -> Dict[str, Any]:
        """Toggles video playback in active YouTube tab using 'k' / spacebar."""
        yt_win = self.find_youtube_window()
        if yt_win:
            ui_controller.bring_to_foreground(yt_win["hwnd"])
            time.sleep(0.08)
            # 'k' is YouTube's standard, conflict-free play/pause shortcut
            ui_controller.press_key('k', delay_after=0.05)
            context_engine.update_task_state(action="toggled_play_pause", app="youtube")
            return {"success": True, "result": "Toggled YouTube video playback, Sir."}
        else:
            # Fallback to system media key
            pyautogui.press('playpause')
            return {"success": True, "result": "Toggled media playback, Sir."}

    def toggle_mute(self) -> Dict[str, Any]:
        """Toggles mute on YouTube video using 'm'."""
        yt_win = self.find_youtube_window()
        if yt_win:
            ui_controller.bring_to_foreground(yt_win["hwnd"])
            time.sleep(0.05)
            ui_controller.press_key('m', delay_after=0.05)
            return {"success": True, "result": "Toggled YouTube audio mute, Sir."}
        return {"success": False, "error": "No active YouTube window found"}

    def toggle_fullscreen(self) -> Dict[str, Any]:
        """Toggles fullscreen on YouTube video using 'f'."""
        yt_win = self.find_youtube_window()
        if yt_win:
            ui_controller.bring_to_foreground(yt_win["hwnd"])
            time.sleep(0.05)
            ui_controller.press_key('f', delay_after=0.05)
            return {"success": True, "result": "Toggled YouTube fullscreen, Sir."}
        return {"success": False, "error": "No active YouTube window found"}

    def open_first_video(self) -> Dict[str, Any]:
        """Selects and plays the first video result in search."""
        yt_win = self.find_youtube_window()
        if yt_win:
            ui_controller.bring_to_foreground(yt_win["hwnd"])
            time.sleep(0.1)
            # Press Tab to leave search bar, then Enter or navigate to first video
            ui_controller.press_key('tab', delay_after=0.05)
            ui_controller.press_key('enter', delay_after=0.2)
            context_engine.update_task_state(action="opened_first_video", app="youtube", task="playing_video")
            return {"success": True, "result": "Opened the first video on YouTube, Sir."}
        return {"success": False, "error": "No active YouTube window found"}

    def search_in_current_tab(self, query: str) -> Dict[str, Any]:
        """Navigates the currently focused browser tab without opening a new tab."""
        wins = self.find_browser_windows()
        if not wins:
            webbrowser.open(f"https://www.google.com/search?q={urllib.parse.quote_plus(query)}")
            return {"success": True, "result": f"Opened search for '{query}' in browser, Sir."}

        ui_controller.bring_to_foreground(wins[0]["hwnd"])
        time.sleep(0.08)
        search_url = f"https://www.google.com/search?q={urllib.parse.quote_plus(query)}"
        ui_controller.press_hotkey('ctrl', 'l', delay_after=0.04)
        ui_controller.paste_text(search_url, press_enter=True, delay_after=0.2)
        context_engine.update_task_state(action="searched_web", target=query, app="browser")
        return {"success": True, "result": f"Searched for '{query}' in current tab, Sir."}

    def execute_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Dispatches browser actions."""
        params = params or {}
        act = action.lower().strip()

        if act in ["open_youtube", "youtube"]:
            query = params.get("query")
            force_new = params.get("force_new_tab", False)
            return self.open_youtube(query=query, force_new_tab=force_new)

        elif act in ["search_youtube", "search_video"]:
            query = params.get("query") or params.get("target") or ""
            return self.search_youtube(query)

        elif act in ["play", "pause", "play_pause", "toggle_play"]:
            return self.play_pause()

        elif act in ["mute", "unmute"]:
            return self.toggle_mute()

        elif act in ["fullscreen"]:
            return self.toggle_fullscreen()

        elif act in ["open_first_video", "open_first_result", "first_video"]:
            return self.open_first_video()

        elif act in ["search_in_tab", "search_current_tab"]:
            query = params.get("query") or params.get("target") or ""
            return self.search_in_current_tab(query)

        elif act in ["new_tab"]:
            ui_controller.press_hotkey('ctrl', 't', delay_after=0.1)
            return {"success": True, "result": "Opened new browser tab, Sir."}

        elif act in ["close_tab"]:
            ui_controller.press_hotkey('ctrl', 'w', delay_after=0.1)
            return {"success": True, "result": "Closed active browser tab, Sir."}

        elif act in ["switch_tab"]:
            ui_controller.press_hotkey('ctrl', 'tab', delay_after=0.1)
            return {"success": True, "result": "Switched browser tab, Sir."}

        return {"success": False, "error": f"Unknown browser action '{action}'"}


# Global singleton instance
browser_adapter = BrowserAdapter()
