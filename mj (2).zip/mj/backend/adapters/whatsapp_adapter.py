import os
import time
import logging
from typing import Dict, Any, Optional, List

from backend.adapters.base_adapter import BaseAdapter
from backend.whatsapp.manager import whatsapp_manager

logger = logging.getLogger("MJ_WhatsAppAdapter")

class WhatsAppAdapter(BaseAdapter):
    """
    Dedicated Adapter for Official Installed WhatsApp Desktop on Windows.
    Backed by the modular WhatsAppManager:
    - Priority 1: Official WhatsApp Desktop (Stable)
    - Priority 2: WhatsApp Beta
    - Priority 3: Web fallback (only if desktop unavailable or requested)
    - Verification, duplicate message protection, contact safety, and pronoun awareness
    """

    UWP_STABLE_APP_ID = "5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App"
    UWP_BETA_APP_ID = "5319275A.51895FA4EA97F_cv1g1gvanyjgm!App"
    PROCESS_NAMES = ["whatsapp.root.exe", "whatsapp.exe"]

    def __init__(self):
        super().__init__("whatsapp")
        self.manager = whatsapp_manager

    @property
    def last_contact(self) -> str:
        return self.manager.context.state.get("current_contact", "")

    @last_contact.setter
    def last_contact(self, value: str):
        self.manager.context.state["current_contact"] = value

    @property
    def active_chat(self) -> str:
        return self.manager.context.state.get("current_chat", "")

    @active_chat.setter
    def active_chat(self, value: str):
        self.manager.context.state["current_chat"] = value

    def is_installed(self) -> bool:
        """Checks if official WhatsApp Desktop executable or package exists."""
        return self.manager.detector.is_desktop_installed()

    def is_running(self) -> bool:
        """Checks if WhatsApp process exists in desktop tasklist or window list."""
        return self.manager.detector.is_process_running() or (self.get_whatsapp_hwnd() is not None)

    def get_whatsapp_hwnd(self) -> Optional[int]:
        """Finds main WhatsApp application window HWND."""
        return self.manager.launcher.get_whatsapp_hwnd()

    def activate(self, prefer_beta: bool = False) -> bool:
        """
        Brings WhatsApp to foreground or launches the official desktop app.
        Never opens WhatsApp Web or browser fallback unless desktop is absent.
        """
        res = self.manager.open(prefer_beta=prefer_beta)
        return res.get("success", False)

    def search_contact(self, contact_name: str) -> Dict[str, Any]:
        """
        Focuses WhatsApp search bar, enters contact query, selects result, and updates context.
        """
        res = self.manager.search_contact(contact_name)
        return {
            "success": res.get("success", False),
            "contact": res.get("contact", contact_name),
            "result": res.get("voice_response", res.get("summary", "")),
            "requires_clarification": res.get("requires_clarification", False)
        }

    def type_message(self, message_text: str, send_now: bool = False) -> Dict[str, Any]:
        """
        Pastes message text into active WhatsApp chat input box.
        """
        if send_now:
            active_target = self.active_chat or self.last_contact
            res = self.manager.send_message(active_target, message_text)
            return {
                "success": res.get("success", False),
                "message": message_text,
                "sent": True,
                "result": res.get("voice_response", res.get("summary", ""))
            }
        else:
            self.manager.ui.ensure_focused()
            from backend.ui_controller import ui_controller
            ui_controller.paste_text(message_text, press_enter=False, delay_after=0.08)
            return {
                "success": True,
                "message": message_text,
                "sent": False,
                "result": f"Typed into WhatsApp chat."
            }

    def send_current_message(self) -> Dict[str, Any]:
        """Sends whatever text is currently in the message input box."""
        self.manager.ui.ensure_focused()
        from backend.ui_controller import ui_controller
        ui_controller.press_key('enter', delay_after=0.1)
        return {
            "success": True,
            "result": "Message sent on WhatsApp."
        }

    def send_message(self, contact_name: str, message: str) -> Dict[str, Any]:
        """Sends message with contact safety and duplicate protection."""
        res = self.manager.send_message(contact_name, message)
        return {
            "success": res.get("success", False),
            "result": res.get("voice_response", res.get("summary", "")),
            "requires_clarification": res.get("requires_clarification", False)
        }

    def reply_message(self, message: str) -> Dict[str, Any]:
        """Replies to current active conversation context."""
        res = self.manager.reply(message)
        return {
            "success": res.get("success", False),
            "result": res.get("voice_response", res.get("summary", ""))
        }

    def read_latest_message(self, contact_name: Optional[str] = None) -> Dict[str, Any]:
        """Reads latest visible message from active or requested chat."""
        res = self.manager.read_latest(contact_name=contact_name)
        return {
            "success": res.get("success", False),
            "latest_message": res.get("latest_message", ""),
            "result": res.get("voice_response", res.get("summary", ""))
        }

    def read_unread_messages(self) -> Dict[str, Any]:
        """Checks for unread message notifications."""
        res = self.manager.read_unread()
        return {
            "success": res.get("success", False),
            "unread_count": res.get("unread_count", 0),
            "result": res.get("voice_response", res.get("summary", ""))
        }

    def send_file(self, contact_name: str, file_query: str) -> Dict[str, Any]:
        """Uploads and sends file on WhatsApp."""
        res = self.manager.send_file(contact_name, file_query)
        return {
            "success": res.get("success", False),
            "result": res.get("voice_response", res.get("summary", ""))
        }

    def start_call(self, contact_name: Optional[str] = None, call_type: str = "voice") -> Dict[str, Any]:
        """Triggers Voice (Ctrl+Shift+C) or Video (Ctrl+Shift+V) call on WhatsApp Desktop."""
        res = self.manager.call(contact_name=contact_name, call_type=call_type)
        return {
            "success": res.get("success", False),
            "call_type": call_type,
            "contact": contact_name or self.active_chat,
            "result": res.get("voice_response", res.get("summary", ""))
        }

    def get_status(self) -> Dict[str, Any]:
        """Returns comprehensive WhatsApp status."""
        return self.manager.get_status()

    def execute_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Dispatches action to WhatsApp adapter."""
        params = params or {}
        act = action.lower().strip()

        if act in ["open", "activate", "launch"]:
            success = self.activate(prefer_beta=params.get("prefer_beta", False))
            return {"success": success, "result": "WhatsApp is open." if success else "Failed to open WhatsApp."}

        elif act in ["search_contact", "search", "open_chat"]:
            contact = params.get("contact") or params.get("target") or params.get("name") or ""
            return self.search_contact(contact)

        elif act in ["type_message", "type", "write"]:
            msg = params.get("message") or params.get("text") or ""
            send = params.get("send", False)
            return self.type_message(msg, send_now=send)

        elif act in ["send", "send_message", "send_it"]:
            contact = params.get("contact") or ""
            msg = params.get("message") or params.get("text") or ""
            if contact and msg:
                return self.send_message(contact, msg)
            elif msg:
                return self.reply_message(msg)
            else:
                return self.send_current_message()

        elif act in ["reply", "reply_message"]:
            msg = params.get("message") or params.get("text") or ""
            return self.reply_message(msg)

        elif act in ["read_latest", "read_latest_message", "read_message", "read"]:
            contact = params.get("contact") or ""
            return self.read_latest_message(contact_name=contact if contact else None)

        elif act in ["unread", "unread_messages", "check_unread"]:
            return self.read_unread_messages()

        elif act in ["send_file", "attach_file", "share_file"]:
            contact = params.get("contact") or ""
            fl = params.get("file") or params.get("file_query") or ""
            return self.send_file(contact, fl)

        elif act in ["call", "voice_call", "video_call"]:
            contact = params.get("contact") or ""
            c_type = "video" if "video" in act or params.get("type") == "video" else "voice"
            return self.start_call(contact, call_type=c_type)

        elif act in ["status", "whatsapp_status"]:
            st = self.get_status()
            return {"success": True, "result": st.get("voice_response", st.get("summary", ""))}

        return {"success": False, "error": f"Unknown WhatsApp action '{action}'"}

# Global singleton instance
whatsapp_adapter = WhatsAppAdapter()
