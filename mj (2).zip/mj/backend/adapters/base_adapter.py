import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

logger = logging.getLogger("MJ_BaseAdapter")

class BaseAdapter(ABC):
    """
    Standard Base Application Control Adapter.
    Defines unified contract for application-specific control, inspection, and verification.
    """
    def __init__(self, app_name: str):
        self.app_name = app_name

    @abstractmethod
    def is_installed(self) -> bool:
        """Checks if application is installed locally on the system."""
        pass

    @abstractmethod
    def is_running(self) -> bool:
        """Checks if application process or window is currently active."""
        pass

    @abstractmethod
    def activate(self) -> bool:
        """Brings existing application window to foreground or launches it."""
        pass

    @abstractmethod
    def execute_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Executes application-specific action (e.g. search, type, send, play, pause)."""
        pass

    def verify_action(self, action: str, params: Optional[Dict[str, Any]] = None) -> bool:
        """Verifies whether the executed action produced the intended UI state change."""
        return True
