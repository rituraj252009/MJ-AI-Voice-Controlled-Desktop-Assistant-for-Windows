from backend.adapters.base_adapter import BaseAdapter
from backend.adapters.whatsapp_adapter import whatsapp_adapter, WhatsAppAdapter
from backend.adapters.browser_adapter import browser_adapter, BrowserAdapter
from backend.adapters.explorer_adapter import explorer_adapter, ExplorerAdapter
from backend.adapters.notepad_adapter import notepad_adapter, NotepadAdapter
from backend.adapters.generic_adapter import generic_adapter, GenericAdapter

__all__ = [
    "BaseAdapter",
    "whatsapp_adapter", "WhatsAppAdapter",
    "browser_adapter", "BrowserAdapter",
    "explorer_adapter", "ExplorerAdapter",
    "notepad_adapter", "NotepadAdapter",
    "generic_adapter", "GenericAdapter"
]
