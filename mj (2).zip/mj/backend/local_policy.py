import os
import re
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("MJ_LocalPolicy")

class LocalFirstExecutionPolicy:
    """
    Local-First Execution Policy Engine for MJ.
    Guarantees:
    1. Local application, active context, and local files are ALWAYS attempted first.
    2. Web search or browser fallback is NEVER executed silently.
    3. If an app or file is missing locally, MJ communicates the local failure
       rather than popping Chrome or searching Google.
    4. Web searches occur ONLY when explicitly demanded by Sir (e.g. 'search on Google').
    """

    EXPLICIT_WEB_TRIGGERS = [
        "search on google", "search google", "google search", "google par search",
        "search on web", "web search", "google karo", "internet par search",
        "search online", "look up online", "google par dhundho"
    ]

    def is_explicit_web_search(self, user_command: str) -> bool:
        """Determines if the user explicitly requested a web or Google search."""
        cmd = user_command.lower().strip()
        return any(trig in cmd for trig in self.EXPLICIT_WEB_TRIGGERS)

    def handle_missing_local_target(self, target_name: str, target_type: str = "application") -> Dict[str, Any]:
        """
        Generates structured local failure response instead of opening Chrome.
        """
        logger.warning(f"Local-First Policy: {target_type} '{target_name}' not found locally. Blocked silent web fallback.")
        
        type_desc = "एप्लिकेशन" if target_type == "application" else ("फ़ोल्डर" if target_type == "folder" else "फ़ाइल")
        return {
            "success": False,
            "blocked_web_fallback": True,
            "target": target_name,
            "target_type": target_type,
            "voice_response": f"मुझे आपके लैपटॉप पर {target_name} {type_desc} नहीं मिला, सर। क्या आप इसे वेब पर खोजना चाहते हैं?",
            "summary": f"Target '{target_name}' not found locally. Web fallback prevented."
        }


# Global singleton instance
local_policy = LocalFirstExecutionPolicy()
