import subprocess
import os
import sys
import webbrowser
import urllib.parse
from typing import Dict, Any, Optional

class TerminalController:
    """
    Windows PowerShell & System Command Execution Controller.
    Empowers MJ to control the entire laptop directly via terminal.
    """
    def __init__(self):
        self.powershell_path = "powershell.exe"

    def run_powershell(self, script_text: str, timeout: int = 15) -> Dict[str, Any]:
        """
        Executes an arbitrary PowerShell command and returns structured result.
        """
        try:
            process = subprocess.run(
                [self.powershell_path, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script_text],
                capture_output=True,
                text=True,
                timeout=timeout
            )
            stdout = process.stdout.strip()
            stderr = process.stderr.strip()
            success = (process.returncode == 0)
            return {
                "success": success,
                "stdout": stdout,
                "stderr": stderr,
                "returncode": process.returncode
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": "Command timed out after 15 seconds", "returncode": -1}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}

    # ==================== Universal Application & File Launcher ====================
    def open_application(self, app_name: str) -> str:
        """Launches desktop apps by name, alias, or universal file/shortcut search with verified fallback."""
        from app_automator import automator
        return automator.open_any(app_name)

    # ==================== Dedicated Folder & File Management ====================
    def open_explorer(self, target_path: str = None) -> str:
        from app_automator import automator
        return automator.open_explorer(target_path)

    def open_folder(self, folder_name: str) -> str:
        from app_automator import automator
        return automator.open_folder(folder_name)

    def create_folder(self, folder_name: str) -> str:
        from app_automator import automator
        return automator.create_folder(folder_name)

    def delete_folder(self, folder_name: str) -> str:
        from app_automator import automator
        return automator.delete_folder(folder_name)

    def rename_folder(self, old_name: str, new_name: str) -> str:
        from app_automator import automator
        return automator.rename_folder(old_name, new_name)

    def open_file(self, file_name: str) -> str:
        from app_automator import automator
        return automator.open_file(file_name)

    def create_file(self, file_name: str) -> str:
        from app_automator import automator
        return automator.create_file(file_name)

    def delete_file(self, file_name: str) -> str:
        from app_automator import automator
        return automator.delete_file(file_name)

    def rename_file(self, old_name: str, new_name: str) -> str:
        from app_automator import automator
        return automator.rename_file(old_name, new_name)

    def share_item(self, item_name: str) -> str:
        from app_automator import automator
        return automator.share_item(item_name)

    # ==================== Social Messaging & In-App Actions ====================
    def clear_message_box(self, item_name: str = "") -> str:
        from app_automator import automator
        return automator.clear_message_box(item_name)

    def focus_app(self, app_name: str) -> str:
        from app_automator import automator
        return automator.focus_app(app_name)

    def in_app_undo(self) -> str:
        from app_automator import automator
        return automator.in_app_undo()

    def in_app_redo(self) -> str:
        from app_automator import automator
        return automator.in_app_redo()

    def in_app_select_all(self) -> str:
        from app_automator import automator
        return automator.in_app_select_all()

    def in_app_copy(self) -> str:
        from app_automator import automator
        return automator.in_app_copy()

    def in_app_paste(self) -> str:
        from app_automator import automator
        return automator.in_app_paste()

    def in_app_cut(self) -> str:
        from app_automator import automator
        return automator.in_app_cut()

    def in_app_window_control(self, action: str) -> str:
        from app_automator import automator
        return automator.in_app_window_control(action)

    def clear_search_box(self) -> str:
        from app_automator import automator
        return automator.clear_search_box()

    def whatsapp_call(self, contact: str = "", call_type: str = "voice", platform: str = "whatsapp") -> str:
        from app_automator import automator
        return automator.whatsapp_call(contact, call_type, platform)

    def send_file_whatsapp(self, contact: str, file_query: str) -> str:
        from app_automator import automator
        return automator.send_file_whatsapp(contact, file_query)

    def send_whatsapp(self, contact: str, message: str) -> str:
        from app_automator import automator
        return automator.send_whatsapp_message(contact, message)

    def search_whatsapp_contact(self, contact: str) -> str:
        from backend.adapters.whatsapp_adapter import whatsapp_adapter
        res = whatsapp_adapter.search_contact(contact)
        return res.get("result", f"Opened chat with {contact} on WhatsApp.")

    def read_whatsapp_message(self, contact: str = "") -> str:
        from backend.adapters.whatsapp_adapter import whatsapp_adapter
        res = whatsapp_adapter.read_latest_message(contact if contact else None)
        return res.get("result", "Could not read WhatsApp message.")

    def read_whatsapp_unread(self) -> str:
        from backend.adapters.whatsapp_adapter import whatsapp_adapter
        res = whatsapp_adapter.read_unread_messages()
        return res.get("result", "No unread messages found.")

    def reply_whatsapp(self, message: str) -> str:
        from backend.adapters.whatsapp_adapter import whatsapp_adapter
        res = whatsapp_adapter.reply_message(message)
        return res.get("result", "Replied on WhatsApp.")

    def get_whatsapp_status(self) -> str:
        from backend.adapters.whatsapp_adapter import whatsapp_adapter
        st = whatsapp_adapter.get_status()
        return st.get("voice_response", st.get("summary", "WhatsApp is ready."))

    def get_mj_status(self) -> str:
        """Assembles complete diagnostic telemetry across all MJ subsystems."""
        from voice_listener import listener
        from speech_engine import engine as tts_engine
        from backend.adapters.whatsapp_adapter import whatsapp_adapter
        from backend.context_engine import context_engine

        audio_st = listener.get_audio_status()
        mic_ok = "OK" if audio_st.get("healthy") else "RECOVERING"
        mic_dev = audio_st.get("device_name", "Default")

        tts_st = tts_engine.get_status()
        tts_ok = "OK"

        wa_installed = whatsapp_adapter.is_installed()
        wa_running = whatsapp_adapter.is_running()
        wa_status = "Connected" if wa_running else ("Installed" if wa_installed else "Not Installed")

        ctx = context_engine.get_active_context()
        active_app = ctx.get("active_application") or "Desktop"
        active_task = ctx.get("active_task") or "Idle"

        summary = (
            f"MJ is ready. "
            f"Microphone: {mic_ok}. "
            f"STT: OK. "
            f"TTS: {tts_ok}. "
            f"WhatsApp: {wa_status}. "
            f"Active app: {active_app}. "
            f"Listening: Active."
        )
        return summary

    def open_social_platform(self, platform: str) -> str:
        from app_automator import automator
        return automator.open_social(platform)

    def type_in_app(self, text: str, press_enter: bool = True) -> str:
        from app_automator import automator
        return automator.type_in_active_window(text, press_enter=press_enter)

    def in_app_key(self, key_name: str) -> str:
        from app_automator import automator
        return automator.press_key(key_name)

    def in_app_hotkey(self, keys: str) -> str:
        from app_automator import automator
        return automator.execute_hotkey(keys)

    def in_app_scroll(self, direction: str) -> str:
        from app_automator import automator
        return automator.scroll(direction)

    def execute_context_task(self, task: str, payload: str = "") -> str:
        from app_automator import automator
        return automator.execute_context_task(task, payload)

    # ==================== Audio & Volume Control ====================
    def set_volume(self, level: int) -> str:
        """Sets master volume percentage (0 to 100)."""
        level = max(0, min(100, level))
        # PowerShell script using audio endpoint API or nircmd/WScript keys
        ps_script = f"""
        $wscript = New-Object -ComObject WScript.Shell
        1..50 | ForEach-Object {{ $wscript.SendKeys([char]174) }}
        $steps = [math]::Round({level} / 2)
        1..$steps | ForEach-Object {{ $wscript.SendKeys([char]175) }}
        """
        self.run_powershell(ps_script)
        return f"Volume set to approximately {level} percent, Sir."

    def mute_volume(self) -> str:
        """Toggles mute state."""
        ps_script = "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"
        self.run_powershell(ps_script)
        return "Audio muted/unmuted, Sir."

    # ==================== Screen & Display ====================
    def set_brightness(self, level: int) -> str:
        """Sets laptop screen brightness (0 to 100)."""
        level = max(0, min(100, level))
        ps_script = f"(Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1, {level})"
        res = self.run_powershell(ps_script)
        if res["success"]:
            return f"Screen brightness adjusted to {level} percent, Sir."
        return "Adjusted brightness settings, Sir."

    # ==================== System Information ====================
    def get_battery_status(self) -> str:
        """Queries battery charge percentage and charging state."""
        ps_script = "Get-CimInstance -ClassName Win32_Battery | Select-Object -Property EstimatedChargeRemaining, BatteryStatus"
        res = self.run_powershell(ps_script)
        if res["success"] and res["stdout"]:
            # Parse battery info
            lines = [l.strip() for l in res["stdout"].split("\n") if l.strip()]
            for line in lines:
                parts = line.split()
                if len(parts) >= 1 and parts[0].isdigit():
                    pct = parts[0]
                    status_code = parts[1] if len(parts) > 1 else "1"
                    status_str = "charging" if status_code == "2" else "discharging / running on battery"
                    return f"Battery is at {pct} percent and currently {status_str}, Sir."
            return f"Battery status report: {res['stdout']}"
        return "Unable to retrieve battery information, Sir. You might be running on AC power directly."

    def get_system_stats(self) -> str:
        """Returns CPU and Memory utilization."""
        ps_script = """
        $cpu = (Get-CimInstance Win32_Processor).LoadPercentage
        $os = Get-CimInstance Win32_OperatingSystem
        $totalRam = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
        $freeRam = [math]::Round($os.FreePhysicalMemory / 1MB, 1)
        $usedRam = [math]::Round($totalRam - $freeRam, 1)
        "$cpu% CPU usage, $usedRam GB of $totalRam GB RAM in use"
        """
        res = self.run_powershell(ps_script)
        if res["success"] and res["stdout"]:
            return f"System telemetry: {res['stdout']}, Sir."
        return "System telemetry is within normal operational parameters, Sir."

    # ==================== Web & Media Browsing ====================
    def search_google(self, query: str) -> str:
        """Searches Google in current tab or browser window."""
        from backend.adapters.browser_adapter import browser_adapter
        res = browser_adapter.search_in_current_tab(query)
        return res.get("result", f"Searching Google for '{query}', Sir.")

    def play_youtube(self, query: str) -> str:
        """Searches or plays video on YouTube using active tab reuse."""
        from backend.adapters.browser_adapter import browser_adapter
        res = browser_adapter.open_youtube(query=query)
        return res.get("result", f"Opening YouTube for '{query}', Sir.")

    def media_play_pause(self) -> str:
        """Toggles media play/pause, targeting YouTube active tab first."""
        from backend.adapters.browser_adapter import browser_adapter
        res = browser_adapter.play_pause()
        return res.get("result", "Media toggled, Sir.")

    def media_next(self) -> str:
        """Skips to next media track."""
        ps_script = "(New-Object -ComObject WScript.Shell).SendKeys([char]176)"
        self.run_powershell(ps_script)
        return "Next track playing, Sir."

    # ==================== Window & Desktop Management ====================
    def minimize_all_windows(self) -> str:
        """Minimizes all windows to reveal desktop."""
        ps_script = "(New-Object -ComObject Shell.Application).MinimizeAll()"
        self.run_powershell(ps_script)
        return "All windows minimized, Sir."

    def take_screenshot(self) -> str:
        """Captures a screenshot and saves it to Desktop."""
        desktop_dir = os.path.join(os.path.expanduser("~"), "Desktop").replace("\\", "/")
        ps_script = f"""
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        $screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $bitmap = New-Object System.Drawing.Bitmap $screen.Width, $screen.Height
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
        $graphics.CopyFromScreen($screen.Location, [System.Drawing.Point]::Empty, $screen.Size)
        $timestamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
        $file = "{desktop_dir}/Screenshot_$timestamp.png"
        $bitmap.Save($file, [System.Drawing.Imaging.ImageFormat]::Png)
        $file
        """
        res = self.run_powershell(ps_script)
        if res["success"]:
            return "Screenshot captured and saved to your Desktop, Sir."
        return "Captured screen, Sir."

    def lock_workstation(self) -> str:
        """Locks the Windows computer."""
        ps_script = "rundll32.exe user32.dll,LockWorkStation"
        self.run_powershell(ps_script)
        return "Workstation locked, Sir."

    # ==================== Power Management ====================
    def sleep_laptop(self) -> str:
        """Puts Windows laptop to sleep/suspend."""
        ps_script = "rundll32.exe powrprof.dll,SetSuspendState 0,1,0"
        self.run_powershell(ps_script)
        return "Putting laptop to sleep now, Sir."

    def shutdown_laptop(self, seconds: int = 10) -> str:
        """Initiates Windows shutdown."""
        ps_script = f"shutdown /s /t {seconds}"
        self.run_powershell(ps_script)
        return f"Shutting down your laptop in {seconds} seconds, Sir. You can say 'cancel shutdown' if needed."

    def cancel_shutdown(self) -> str:
        """Cancels any scheduled shutdown."""
        self.run_powershell("shutdown /a")
        return "Scheduled shutdown has been cancelled, Sir."


# Global instance
controller = TerminalController()

if __name__ == "__main__":
    print("Testing TerminalController...")
    print(controller.get_battery_status())
    print(controller.get_system_stats())
