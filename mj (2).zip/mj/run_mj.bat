@echo off
title MJ AI Voice Terminal Assistant
color 0B
cls
echo =======================================================================
echo          STARTING MJ AI VOICE ASSISTANT (TERMINAL CONTROLLER)
echo =======================================================================
echo.
python mj.py
pause
