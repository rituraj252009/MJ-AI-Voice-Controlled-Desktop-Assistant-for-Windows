import io
import time
import wave
import queue
import collections
import base64
import threading
import logging
import numpy as np
import sounddevice as sd
import requests
from requests.adapters import HTTPAdapter
import config
from clap_detector import detector as clap_detector

logger = logging.getLogger("MJ_VoiceListener")

class AudioWatchdog(threading.Thread):
    """
    Background Watchdog that monitors microphone health, PortAudio stream activity,
    and audio device connectivity.
    If the stream goes stale (>12s with no callbacks or device disconnect),
    it automatically initiates a zero-crash stream restart and returns MJ to listening.
    """
    def __init__(self, listener, check_interval: float = 2.5, stale_timeout: float = 12.0):
        super().__init__(daemon=True, name="MJ_AudioWatchdog")
        self.listener = listener
        self.check_interval = check_interval
        self.stale_timeout = stale_timeout
        self.is_running = True
        self._last_default_device = None

    def run(self):
        while self.is_running:
            time.sleep(self.check_interval)
            if not self.listener.is_running:
                continue

            try:
                now = time.time()
                stream_dead = (self.listener.stream is None or not self.listener.stream.active)
                time_since_frame = now - self.listener.last_audio_time
                is_stale = time_since_frame > self.stale_timeout

                # Check default device change (e.g. bluetooth headset sleep/connect)
                device_changed = False
                try:
                    cur_dev = sd.default.device
                    if self._last_default_device is not None and cur_dev != self._last_default_device:
                        device_changed = True
                    self._last_default_device = cur_dev
                except Exception:
                    pass

                if stream_dead or is_stale or device_changed:
                    reason = "stream stopped" if stream_dead else ("no audio frames for >12s" if is_stale else "device changed")
                    if self.listener.on_recovery_callback:
                        self.listener.on_recovery_callback(f"[RECOVERY] Audio watchdog detected {reason}. Refreshing stream...")
                    self.listener.restart_stream()

            except Exception as e:
                logger.debug(f"Audio watchdog check error: {e}")

    def stop(self):
        self.is_running = False


class UnifiedAudioListener:
    """
    Rock-Solid, Persistent, Conflict-Free Audio Pipeline for MJ.
    - Single permanent microphone stream monitored by AudioWatchdog.
    - Continuous real-time listening & 0ms barge-in support.
    - Adaptive ambient noise calibration.
    - Automatic recovery on long idle, device sleeps, or driver glitches.
    - Wake-word detection ('Hey MJ', 'MJ', 'Sunno MJ') and acoustic clap detection.
    """

    WAKE_PHRASES = [
        "hey mj", "mj", "sunno mj", "suno mj", "hello mj", "namaste mj", "hi mj",
        "एमजे", "नमस्ते एमजे", "सुनो एमजे", "हे एमजे"
    ]

    def __init__(
        self,
        sample_rate: int = config.SAMPLE_RATE,
        silence_threshold: float = config.SILENCE_THRESHOLD,
        silence_duration: float = config.SILENCE_DURATION,
        max_duration: float = config.MAX_RECORDING_SECONDS,
        api_key: str = config.GROQ_API_KEY
    ):
        self.sample_rate = sample_rate
        self.silence_duration = silence_duration
        self.max_duration = max_duration
        self.api_key = api_key
        self.barge_in_threshold = getattr(config, "BARGE_IN_THRESHOLD", 0.035)
        self.groq_url = "https://api.groq.com/openai/v1/audio/transcriptions"

        self.block_size = 1024
        self.audio_queue = queue.Queue(maxsize=300)
        self.stream = None
        self.is_running = False
        self._stream_lock = threading.Lock()

        # Telemetry & Health Tracking
        self.last_audio_time = time.time()
        self.restart_count = 0
        self.on_recovery_callback = None

        # Persistent HTTP session with connection pooling for sub-300ms network requests
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=5, pool_maxsize=10, max_retries=1)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

        # Clamped baseline thresholds calibrated for laptop microphones
        self.ambient_rms = 0.0012
        self.speech_threshold = 0.0035
        self.silence_threshold = 0.0018

        # Watchdog monitor instance
        self.watchdog = None

    def start_stream(self):
        """Starts the persistent microphone stream and calibrates noise floor once."""
        with self._stream_lock:
            if self.is_running and self.stream and self.stream.active:
                return

            def _callback(indata, frames, time_info, status):
                if self.is_running:
                    self.last_audio_time = time.time()
                    try:
                        self.audio_queue.put_nowait(indata.copy())
                    except queue.Full:
                        try:
                            self.audio_queue.get_nowait()
                            self.audio_queue.put_nowait(indata.copy())
                        except Exception:
                            pass

            self.is_running = True
            try:
                self.stream = sd.InputStream(
                    samplerate=self.sample_rate,
                    channels=config.CHANNELS,
                    dtype='float32',
                    blocksize=self.block_size,
                    callback=_callback
                )
                self.stream.start()
                self.last_audio_time = time.time()

                # Calibrate ambient noise floor ONCE on startup (0.25s)
                time.sleep(0.25)
                calib_frames = []
                while not self.audio_queue.empty():
                    try:
                        calib_frames.append(self.audio_queue.get_nowait())
                    except Exception:
                        break

                if calib_frames:
                    self.ambient_rms = float(np.mean([np.sqrt(np.mean(f**2)) for f in calib_frames]))
                    self.speech_threshold = min(0.015, max(0.0055, self.ambient_rms * 2.8 + 0.0025))
                    self.silence_threshold = min(0.008, max(0.0025, self.ambient_rms * 1.6 + 0.0012))

                # Start watchdog if not running
                if self.watchdog is None or not self.watchdog.is_alive():
                    self.watchdog = AudioWatchdog(self)
                    self.watchdog.start()

            except Exception as e:
                logger.error(f"Error starting audio stream: {e}")
                self.is_running = False

    def stop_stream(self):
        """Gracefully closes stream on shutdown."""
        self.is_running = False
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None

    def restart_stream(self):
        """Self-healing restart to recover from stale PortAudio buffers or device sleeps."""
        with self._stream_lock:
            self.is_running = False
            if self.stream:
                try:
                    self.stream.stop()
                    self.stream.close()
                except Exception:
                    pass
                self.stream = None

            time.sleep(0.1)
            self.clear_queue()
            self.restart_count += 1
            self.start_stream()
            self.last_audio_time = time.time()

    def ensure_stream_alive(self):
        """Self-healing guard to ensure microphone stream is healthy before listening."""
        now = time.time()
        # If stream is marked running but hasn't received frames for >6.0s, refresh it
        if not self.is_running or not self.stream or not self.stream.active or (now - self.last_audio_time > 6.0):
            self.restart_stream()

    def clear_queue(self):
        """Flushes queue buffer."""
        while not self.audio_queue.empty():
            try:
                self.audio_queue.get_nowait()
            except Exception:
                break

    def get_audio_status(self) -> Dict[str, Any]:
        """Returns diagnostic health metrics for MJ status command."""
        now = time.time()
        stream_ok = bool(self.stream and self.stream.active)
        last_seen = round(now - self.last_audio_time, 2)
        dev_name = "Default Windows Input"
        try:
            dev_idx = sd.default.device[0]
            if dev_idx is not None and dev_idx >= 0:
                dev_info = sd.query_devices(dev_idx)
                dev_name = dev_info.get("name", dev_name)
        except Exception:
            pass

        return {
            "healthy": stream_ok and last_seen < 10.0,
            "stream_active": stream_ok,
            "device_name": dev_name,
            "last_audio_seen_seconds": last_seen,
            "restart_count": self.restart_count,
            "ambient_rms": round(self.ambient_rms, 5),
            "speech_threshold": round(self.speech_threshold, 5)
        }

    def check_for_double_clap(self, timeout: float = 0.35) -> bool:
        """Monitors frames from queue during SLEEP to catch double claps."""
        self.ensure_stream_alive()
        start = time.time()
        while (time.time() - start) < timeout:
            try:
                frame = self.audio_queue.get(timeout=0.08)
                if clap_detector.process_frame(frame):
                    self.clear_queue()
                    return True
            except queue.Empty:
                pass
        return False

    def listen_for_wake_or_clap(self, timeout: float = 0.5) -> Optional[Dict[str, Any]]:
        """
        Dual-mode trigger check during SLEEP/STANDBY:
        Catches either:
        1. Acoustic double-clap
        2. Spoken wake-phrase ('Hey MJ', 'MJ', or direct command)
        """
        self.ensure_stream_alive()
        start = time.time()
        wake_frames = []
        is_speech = False

        while (time.time() - start) < timeout:
            try:
                frame = self.audio_queue.get(timeout=0.08)
            except queue.Empty:
                continue

            # Check double-clap
            if clap_detector.process_frame(frame):
                self.clear_queue()
                return {"type": "clap", "text": ""}

            rms = float(np.sqrt(np.mean(frame**2)))
            if rms > self.speech_threshold:
                is_speech = True
                wake_frames.append(frame)
                break

        if is_speech:
            # User spoke! Capture brief speech window (~1.2s)
            capture_start = time.time()
            silent_count = 0
            while (time.time() - capture_start) < 2.0 and len(wake_frames) < 32:
                try:
                    f = self.audio_queue.get(timeout=0.08)
                    wake_frames.append(f)
                    f_rms = float(np.sqrt(np.mean(f**2)))
                    if f_rms < self.silence_threshold:
                        silent_count += 1
                        if silent_count >= 5:
                            break
                    else:
                        silent_count = 0
                except queue.Empty:
                    break

            if len(wake_frames) >= 6:
                # Build WAV and transcribe
                audio_arr = np.concatenate(wake_frames, axis=0)
                audio_int16 = (audio_arr * 32767).astype(np.int16)
                wav_buf = io.BytesIO()
                with wave.open(wav_buf, 'wb') as wf:
                    wf.setnchannels(config.CHANNELS)
                    wf.setsampwidth(2)
                    wf.setframerate(self.sample_rate)
                    wf.writeframes(audio_int16.tobytes())
                wav_buf.seek(0)
                text = self.transcribe(wav_buf.read())
                if text:
                    return {"type": "voice", "text": text}

        return None

    def monitor_barge_in(self, is_speaking_check, on_interrupt_callback, timeout: float = 10.0):
        """
        Monitors microphone queue while MJ is speaking.
        If user cuts in with voice energy, immediately halts TTS in 0ms.
        """
        self.ensure_stream_alive()
        consecutive_spikes = 0
        start_time = time.time()
        while is_speaking_check() and (time.time() - start_time) < timeout:
            try:
                frame = self.audio_queue.get(timeout=0.035)
                rms = float(np.sqrt(np.mean(frame**2)))

                if rms > self.barge_in_threshold:
                    consecutive_spikes += 1
                    if consecutive_spikes >= 2:
                        on_interrupt_callback()
                        return [frame.copy()]
                else:
                    consecutive_spikes = 0
            except queue.Empty:
                pass
        return None

    def record_speech(self, prompt_callback=None, initial_chunks=None, is_active_check=None) -> bytes | None:
        """
        Continuously listens for speech with adaptive dynamic noise floor VAD.
        - Pre-listen health check guarantees stream is alive.
        - Stays in listening mode indefinitely when user is silent.
        - Immediately captures voice when user speaks and stops on natural pause.
        """
        self.ensure_stream_alive()
        silence_blocks_needed = max(7, int((self.silence_duration * self.sample_rate) / self.block_size))
        max_blocks = int((self.max_duration * self.sample_rate) / self.block_size)

        pre_buffer = collections.deque(maxlen=getattr(config, "PRE_SPEECH_BLOCKS", 8))
        recorded_chunks = list(initial_chunks) if initial_chunks else []
        is_speaking = bool(initial_chunks)
        speech_frames_detected = 2 if is_speaking else 0
        silent_blocks = 0
        total_blocks = len(recorded_chunks)

        if not initial_chunks:
            while self.audio_queue.qsize() > 8:
                try:
                    self.audio_queue.get_nowait()
                except Exception:
                    break

        if prompt_callback:
            prompt_callback("Listening...")

        while self.is_running:
            if is_active_check and not is_active_check():
                break

            try:
                frame = self.audio_queue.get(timeout=0.10)
            except queue.Empty:
                # Stream check: if queue is dry for too long, verify stream
                if (time.time() - self.last_audio_time) > 8.0:
                    self.ensure_stream_alive()
                continue

            rms = float(np.sqrt(np.mean(frame**2)))

            if not is_speaking:
                # Adapt baseline noise floor smoothly while idle
                self.ambient_rms = 0.98 * self.ambient_rms + 0.02 * rms
                self.speech_threshold = min(0.015, max(0.0055, self.ambient_rms * 2.8 + 0.0025))
                self.silence_threshold = min(0.008, max(0.0025, self.ambient_rms * 1.6 + 0.0012))

                pre_buffer.append(frame.copy())
                if rms > self.speech_threshold:
                    speech_frames_detected += 1
                    if speech_frames_detected >= 2:
                        is_speaking = True
                        recorded_chunks.extend(list(pre_buffer))
                        silent_blocks = 0
                        if prompt_callback:
                            prompt_callback("Speech detected...")
                else:
                    speech_frames_detected = 0
            else:
                recorded_chunks.append(frame)
                total_blocks += 1

                if rms < self.silence_threshold:
                    silent_blocks += 1
                else:
                    # Smoothed silence: isolated tiny clicks or breath noises don't freeze MJ
                    silent_blocks = max(0, silent_blocks - 1)

                if silent_blocks >= silence_blocks_needed or total_blocks >= max_blocks:
                    min_valid_blocks = silence_blocks_needed + 3
                    if len(recorded_chunks) < min_valid_blocks:
                        is_speaking = False
                        recorded_chunks = []
                        speech_frames_detected = 0
                        silent_blocks = 0
                        pre_buffer.clear()
                        if prompt_callback:
                            prompt_callback("Listening...")
                        continue
                    break

        if not recorded_chunks:
            return None

        # Build WAV in memory
        audio_array = np.concatenate(recorded_chunks, axis=0)
        peak_amp = float(np.max(np.abs(audio_array)))
        mean_rms = float(np.sqrt(np.mean(audio_array**2)))
        min_peak = getattr(config, "MIN_SPEECH_PEAK", 0.012)

        # Discard faint noise / room rumble to prevent Whisper hallucinating random phrases
        if peak_amp < min_peak or mean_rms < (self.ambient_rms * 1.35):
            return None

        audio_int16 = (audio_array * 32767).astype(np.int16)

        wav_buffer = io.BytesIO()
        with wave.open(wav_buffer, 'wb') as wf:
            wf.setnchannels(config.CHANNELS)
            wf.setsampwidth(2)
            wf.setframerate(self.sample_rate)
            wf.writeframes(audio_int16.tobytes())

        wav_buffer.seek(0)
        return wav_buffer.read()

    def _gemini_transcribe_fallback(self, wav_bytes: bytes) -> str:
        """Fallback transcription via Gemini Audio in case of Groq timeout or network issue."""
        try:
            b64 = base64.b64encode(wav_bytes).decode('utf-8')
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{config.FAST_GEMINI_MODEL}:generateContent?key={config.GEMINI_API_KEY}"
            payload = {
                "contents": [{
                    "parts": [
                        {"inlineData": {"mimeType": "audio/wav", "data": b64}},
                        {"text": "Transcribe the spoken audio verbatim into clean text (supporting English, Hindi, and Hinglish). Output ONLY the transcribed words without punctuation formatting or commentary. If silence or noise, return empty."}
                    ]
                }]
            }
            res = self.session.post(url, json=payload, timeout=3.5)
            if res.status_code == 200:
                raw = res.json().get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '').strip()
                return raw.replace('"', '').strip()
        except Exception:
            pass
        return ""

    def transcribe(self, wav_bytes: bytes) -> str:
        """Sends audio WAV bytes to Groq Whisper Turbo (<250ms transcription) with multilingual context."""
        if not wav_bytes:
            return ""

        headers = {"Authorization": f"Bearer {self.api_key}"}
        files = {"file": ("command.wav", io.BytesIO(wav_bytes), "audio/wav")}
        data = {
            "model": config.GROQ_WHISPER_MODEL,
            "response_format": "json",
            "temperature": getattr(config, "WHISPER_TEMPERATURE", 0.0),
            "prompt": (
                "नमस्ते, एमजे, सर, ऋतुराज, व्हाट्सऐप, क्रोम, यूट्यूब, नोटपैड, कैलकुलेटर, "
                "खोलो, ओपन, सर्च करो, प्ले करो, मैसेज भेजो, सुनो, बोलो, बंद करो, सो जाओ, "
                "हटाओ, मिटाओ, फाइल, फोल्डर, मिनिमाइज, विंडो, डेस्कटॉप, कॉल करो, "
                "MJ, Sir, Rituraj, WhatsApp, Chrome, YouTube, Notepad, Calculator, "
                "kholo, open, search karo, play karo, message bhejo, suno, bolo, band karo, so jao"
            )
        }

        timeout = getattr(config, "WHISPER_TIMEOUT", 3.5)
        try:
            response = self.session.post(self.groq_url, headers=headers, files=files, data=data, timeout=timeout)
            if response.status_code == 200:
                text = response.json().get("text", "").strip()
                text = text.strip('"\' ')
                if text:
                    return text
        except Exception:
            pass

        return self._gemini_transcribe_fallback(wav_bytes)

    def listen(self, status_callback=None, initial_chunks=None, is_active_check=None) -> str:
        """Listens continuously and returns transcribed text string immediately upon speech."""
        wav_data = self.record_speech(
            prompt_callback=status_callback,
            initial_chunks=initial_chunks,
            is_active_check=is_active_check
        )
        if not wav_data:
            return ""
        if status_callback:
            status_callback("Transcribing...")
        text = self.transcribe(wav_data)
        return text


# Global instance
listener = UnifiedAudioListener()

def listen(status_callback=None, initial_chunks=None, is_active_check=None) -> str:
    return listener.listen(status_callback, initial_chunks=initial_chunks, is_active_check=is_active_check)
