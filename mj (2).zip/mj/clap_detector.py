import time
import threading
import numpy as np
import config

class ClapDetector:
    """
    Acoustic Double-Clap Detector that processes audio blocks from the
    unified microphone stream without creating conflicting audio streams.
    """
    def __init__(
        self,
        threshold: float = config.CLAP_THRESHOLD,
        min_interval: float = config.CLAP_MIN_INTERVAL,
        max_interval: float = config.CLAP_MAX_INTERVAL,
        sample_rate: int = config.SAMPLE_RATE,
        block_size: int = config.CLAP_BLOCK_SIZE
    ):
        self.threshold = threshold
        self.min_interval = min_interval
        self.max_interval = max_interval
        self.sample_rate = sample_rate
        self.block_size = block_size

        self.last_clap_time = 0.0
        self.clap_count = 0

    def process_frame(self, indata) -> bool:
        """
        Processes a single audio frame from the unified stream.
        Returns True if a double-clap pattern was completed.
        """
        peak = np.max(np.abs(indata))
        current_time = time.time()

        if peak >= self.threshold:
            dt = current_time - self.last_clap_time

            if self.clap_count == 0:
                # First clap detected
                self.clap_count = 1
                self.last_clap_time = current_time
            elif self.clap_count == 1:
                if self.min_interval <= dt <= self.max_interval:
                    # Second clap confirmed!
                    self.clap_count = 0
                    self.last_clap_time = 0.0
                    return True
                elif dt > self.max_interval:
                    # Treat as new first clap
                    self.clap_count = 1
                    self.last_clap_time = current_time
        else:
            # Reset after max interval expires
            if self.clap_count == 1 and (current_time - self.last_clap_time) > self.max_interval:
                self.clap_count = 0

        return False

    def reset(self):
        self.clap_count = 0
        self.last_clap_time = 0.0


# Global instance
detector = ClapDetector()
