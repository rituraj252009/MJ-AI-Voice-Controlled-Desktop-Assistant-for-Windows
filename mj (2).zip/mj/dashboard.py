import os
import threading
from flask import Flask, render_template
from flask_socketio import SocketIO
from flask_cors import CORS
import config

app = Flask(__name__, template_folder="templates")
app.config['SECRET_KEY'] = 'mj_secret_neural_key_2026'
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Callback hooks for main application
on_command_callback = None
on_wake_callback = None
on_sleep_callback = None

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('connect')
def handle_connect():
    pass

@socketio.on('text_command')
def handle_text_command(data):
    text = data.get('text', '')
    if text and on_command_callback:
        threading.Thread(target=on_command_callback, args=(text,), daemon=True).start()

@socketio.on('trigger_wake')
def handle_trigger_wake():
    if on_wake_callback:
        threading.Thread(target=on_wake_callback, daemon=True).start()

@socketio.on('action_trigger')
def handle_action_trigger(data):
    action = data.get('action')
    if action == 'wake' and on_wake_callback:
        threading.Thread(target=on_wake_callback, daemon=True).start()
    elif action == 'sleep' and on_sleep_callback:
        threading.Thread(target=on_sleep_callback, daemon=True).start()

def emit_status(status: str):
    try:
        socketio.emit('status_update', {'status': status})
    except Exception:
        pass

def emit_transcript(text: str):
    try:
        socketio.emit('voice_transcript', {'text': text})
    except Exception:
        pass

def emit_reply(text: str):
    try:
        socketio.emit('assistant_reply', {'text': text})
    except Exception:
        pass

def emit_terminal_log(command: str, output: str = ""):
    try:
        socketio.emit('terminal_log', {'command': command, 'output': output})
    except Exception:
        pass

def emit_task_started(goal: str, total_steps: int = 1):
    try:
        socketio.emit('task_started', {'goal': goal, 'total_steps': total_steps})
    except Exception:
        pass

def emit_task_step(step_id: int, description: str, tool: str):
    try:
        socketio.emit('task_step', {'step_id': step_id, 'description': description, 'tool': tool})
    except Exception:
        pass

def emit_tool_called(tool: str, params: dict = None):
    try:
        socketio.emit('tool_called', {'tool': tool, 'params': params or {}})
    except Exception:
        pass

def emit_tool_result(tool: str, result: str):
    try:
        socketio.emit('tool_result', {'tool': tool, 'result': result})
    except Exception:
        pass

def emit_task_completed(goal: str, summary: str = ""):
    try:
        socketio.emit('task_completed', {'goal': goal, 'summary': summary})
    except Exception:
        pass

def emit_task_failed(step_id: int, error: str):
    try:
        socketio.emit('task_failed', {'step_id': step_id, 'error': error})
    except Exception:
        pass

def emit_call_status(status: str, caller: str = "", duration: int = 0):
    try:
        socketio.emit('call_status', {'status': status, 'caller': caller, 'duration': duration})
    except Exception:
        pass

def emit_message_event(channel: str, contact: str, sender: str, message: str):
    try:
        socketio.emit('message_event', {'channel': channel, 'contact': contact, 'sender': sender, 'message': message})
    except Exception:
        pass

def start_dashboard_server(host=config.DASHBOARD_HOST, port=config.DASHBOARD_PORT):
    """Starts the Flask-SocketIO server in a background daemon thread."""
    def _run():
        import logging
        log = logging.getLogger('werkzeug')
        log.setLevel(logging.ERROR)
        socketio.run(app, host=host, port=port, debug=False, use_reloader=False, allow_unsafe_werkzeug=True)

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    return t
