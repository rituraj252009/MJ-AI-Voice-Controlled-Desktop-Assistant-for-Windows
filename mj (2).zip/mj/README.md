# MJ — AI Voice-Controlled Computer Agent for Windows

**MJ** is an intelligent, context-aware AI computer-use agent for Windows designed to understand natural-language voice instructions, operate directly inside desktop applications, maintain multi-turn context, and execute complex multi-step workflows.

MJ goes far beyond simply launching executables. MJ understands what you want, determines where the task should be performed, executes in-app UI interactions, verifies the results, and continues naturally with follow-up commands.

> **Core Philosophy**: *Listen. Understand. Act. Verify. Remember. Continue.*

---

## Architecture Overview

```
                          USER
                           │
                           ▼
                    🎙 Voice Input
                           │
                           ▼
                    Speech-to-Text (Groq Whisper Turbo)
                           │
                           ▼
                 Language / Intent Layer (<1ms SVO/SOV)
                           │
                           ▼
                   Context Resolution (Active HWND, Tab, Process)
                           │
                           ▼
                    Command Planner
                           │
                           ▼
                     Command Router (Local-First Policy)
                           │
            ┌──────────────┼──────────────┐
            │              │              │
            ▼              ▼              ▼
       Applications    Files/Folders    System
            │              │              │
            ▼              ▼              ▼
      UI Automation    File System    Windows APIs
            │
            ▼
      Browser Automation (Tab Reuse)
            │
            ▼
      Action Verification
            │
            ▼
       Result / Response
            │
            ▼
        Text-to-Speech (Edge-TTS Neural)
            │
            ▼
           🔊 MJ
```

---

## Core Capabilities & Features

### ⚡ 1. Real-Time Voice Pipeline & Barge-In Interruption
- **Persistent Conflict-Free Audio Stream**: Calibrates ambient background noise floor dynamically once on startup.
- **Dynamic VAD & Silence Detection**: Sub-second speech cutoff for instant turnaround without artificial timeouts.
- **Voice Barge-In**: Interrupt MJ at any moment mid-speech. As soon as you speak, MJ cuts off her speech in **0ms** (`ctypes.windll.winmm.mciSendStringW`), carries the speech chunks into the new command, and executes immediately.
  > **Example**:
  > *MJ*: "Opening YouTube and searching for..."
  > *User*: "Stop. Open WhatsApp instead."
  > *MJ*: "Opening WhatsApp."

### 🧠 2. Dual-Tier AI Brain & Controlled Execution
- **Sub-Millisecond Heuristic Fast Path (<1ms)**: Local desktop commands and media actions execute with zero external API roundtrips.
- **Cognitive LLM Layer**: Powered by **Google Gemini Flash** with instant **Groq LLM** fallback for reasoning and complex planning.
- **Strict Sandbox**: The LLM cannot execute arbitrary shell commands directly; every action passes through a verified, safety-gated execution layer.

### 🌐 3. Direct Hindi, Hinglish & English Intent Understanding
- **Zero Translation Latency**: Direct parsing of English (SVO) and Hindi/Hinglish (SOV) word orders (*"WhatsApp kholo"*, *"Rahul ko message bhejo ki mai pahunch gaya"*).
- **Verbatim Entity Preservation**: Contact names, URLs, file paths, and message payloads are preserved word-for-word without translation artifacts.

### 🪟 4. Context-Aware Application & Tab Awareness
- **Live Active Window Tracking**: Tracks active application HWND, process executable (`WhatsApp.Root.exe`, `chrome.exe`, `notepad.exe`), window title, and active browser tab.
- **Deictic Pronoun Resolution**: Resolves contextual references (*"this app"*, *"here"*, *"this tab"*, *"continue"*, *"save it as..."*, *"close it"*) to the currently focused window.
- **Browser Tab Reuse**: When searching or playing YouTube, MJ inspects open Chrome/Edge windows and reuses the active tab instead of launching duplicate instances.

### 🏠 5. Strict Local-First Policy (No Silent Web Fallbacks)
- Requests for local applications, files, or folders execute locally across Start Menu, Program Files, Desktop, Documents, Downloads, and user directories.
- **Zero Silent Web Search**: Never silently defaults to a Google/Bing search when a local target is requested.

### 🧩 6. Deep In-App Automation (Adapters)
- **WhatsApp Adapter**: Native automation for official installed WhatsApp Desktop (`WhatsApp.Root.exe`). Handles contact search (`Ctrl+F`), chat selection, message pasting, sending, and voice calling (`Ctrl+Shift+C`).
- **Browser & YouTube Adapter**: Reuses existing browser sessions, controls playback (`k`, `space`, `m`, `f`, `j`, `l`), and performs in-page searches (`/`).
- **File Explorer Adapter**: Deep local filesystem search, folder navigation, and file management.
- **Notepad / Text Editor Adapter**: In-app writing, `Ctrl+S` document saving, and naming.
- **Generic Win32 / UIA Adapter**: Universal button clicking, menu navigation, and text field typing via `UIAutomationCore.dll`.

### 💻 7. Windows System Control & Telemetry
- Real-time battery status, system CPU/RAM telemetry, volume controls, mute/unmute, screenshots, screen lock, and laptop standby/shutdown.

### 👏 8. Double-Clap Activation & Standby Mode
- **Acoustic Clap Detector**: Wake MJ simply by clapping twice (👏 👏) or pressing Enter in the terminal.
- **Standby Mode**: Put MJ to sleep with *"Sleep"*, *"OK goodbye"*, or *"So jao"*.

### 🖥️ 9. Cyber HUD Web Dashboard
- Live holographic monitoring interface available at `http://127.0.0.1:5000` displaying system telemetry, active window context, transcript logs, and agent execution steps.

---

## Example Voice Commands

### Applications & In-App Control
- *"Open WhatsApp."*
- *"WhatsApp me Rahul ko message bhejo ki mai 5 minute me aa raha hu."*
- *"Call Priya on WhatsApp."*
- *"Open Notepad."* $\to$ *"Write my project notes: submission tomorrow."* $\to$ *"Save it as notes.txt."* $\to$ *"Close it."*

### YouTube & Browser Control
- *"Open YouTube."*
- *"Search Java DSA roadmap in this tab."*
- *"Open the first video."*
- *"Pause."* / *"Play it."* / *"Full screen karo."* / *"Mute karo."*

### Contextual Commands ("This App", "Here")
- *"Search Amit in this tab."*
- *"Is app mein Rahul ko search karo."*
- *"Search here."*
- *"Do the same thing in this app."*
- *"Close this window."*

### Local Files & Folders
- *"Open my resume."*
- *"Find my Downloads folder."*
- *"Open main.py."*
- *"Show my files."*

### System & Telemetry
- *"What is my battery level?"*
- *"Set volume to 50 percent."*
- *"Take a screenshot."*
- *"Put my laptop to sleep."*

### Barge-In & Interruption
- *"Stop."* / *"Ruko."* / *"Ruk jao."*
- *"Stop. Open WhatsApp instead."*

---

## Quick Start

### 1. Requirements
- **OS**: Windows 10 / 11
- **Python**: 3.10+ (tested on Python 3.15)
- **API Keys**: In `.env`:
  ```ini
  GEMINI_API_KEY="your-gemini-api-key"
  GROQ_API_KEY="your-groq-api-key"
  ```

### 2. Installation
```powershell
pip install -r requirements.txt
```

### 3. Launch MJ
```powershell
python mj.py
```
*or double-click `run_mj.bat`.*

---

## Verification & Automated Test Suites

MJ includes an automated test suite verifying intent parsing, context switching, in-app automation, and local-first policies:

```powershell
# Run PRD specification coverage suite
python -m unittest backend/tests/test_prd_spec.py

# Run full system upgrade suite
python -m unittest backend/tests/test_mj_upgrade.py

# Run full cross-channel end-to-end simulation
python backend/tests/test_end_to_end_suite.py
```
