import os
import sys
import time
import threading
from colorama import init, Fore, Style
import config
from speech_engine import speak, stop_speaking, engine as speech_engine
from voice_listener import listener as voice_listener
from brain import brain
from terminal_controller import controller as terminal_controller
import dashboard
from backend.orchestrator.agent import master_agent

# Initialize Colorama for Windows terminal
init(autoreset=True)

class MJAssistant:
    """
    Main Terminal Orchestrator for MJ Voice Assistant.
    Built on a Unified Conflict-Free Audio Stream:
    - Zero device conflicts or PortAudio deadlocks.
    - Continuous real-time listening & barge-in.
    - Adaptive ambient noise calibration.
    - Contextual memory of open applications and files.
    - Clean terminal display: [VOICE], [USER], [MJ].
    """
    STATE_IDLE = "IDLE"
    STATE_SLEEP = "IDLE"  # Backward compatibility with HUD
    STATE_ACTIVE = "ACTIVE"
    STATE_LISTENING = "LISTENING"
    STATE_PROCESSING = "PROCESSING"
    STATE_SPEAKING = "SPEAKING"
    STATE_INTERRUPTED = "INTERRUPTED"
    STATE_RECOVERING_AUDIO = "RECOVERING_AUDIO"
    STATE_ERROR = "ERROR"

    def __init__(self):
        self.state = self.STATE_IDLE
        self.is_running = True
        self._lock = threading.Lock()
        self._wake_event = threading.Event()

    def print_banner(self):
        banner = f"""
{Fore.CYAN}{Style.BRIGHT}================================================================================
  ███╗   ███╗     ██╗        AI VOICE TERMINAL ASSISTANT (ALWAYS-READY STREAM)
  ████╗ ████║     ██║        NAME: {config.ASSISTANT_NAME}  |  OPERATOR: {config.USER_TITLE}
  ██╔████╔██║     ██║        BRAIN: {config.FAST_GEMINI_MODEL} & GROQ
  ██║╚██╔╝██║██   ██║        VOICE: {config.TTS_VOICE} (HINDI MALE)
  ██║ ╚═╝ ██║╚█████╔╝        BARGE-IN: 0ms ACTIVE | AUDIO WATCHDOG: ONLINE
================================================================================{Fore.RESET}
{Fore.YELLOW}  [i] Dashboard HUD: http://{config.DASHBOARD_HOST}:{config.DASHBOARD_PORT}
  [i] Wake Trigger: Say 'Hey MJ', 'MJ', clap twice, or press ENTER
  [i] Barge-In: Speak at any time to interrupt MJ mid-sentence
  [i] Sleep Trigger: Say 'sleep', 'OK goodbye', or 'so jao'
================================================================================
"""
        print(banner)

    def log(self, tag: str, message: str, color=Fore.CYAN):
        """Standardized logger with categorized tags."""
        allowed_tags = [
            "VOICE", "USER", "MJ", "AGENT", "INITIALIZED", "CLAP DETECTED",
            "STATUS", "AUDIO", "STT", "TTS", "WAKE", "WHATSAPP", "WINDOW",
            "COMMAND", "LLM", "RECOVERY", "ERROR"
        ]
        if tag not in allowed_tags:
            return
        tag_colors = {
            "USER": Fore.YELLOW,
            "MJ": Fore.MAGENTA,
            "WHATSAPP": Fore.GREEN,
            "AUDIO": Fore.CYAN,
            "STT": Fore.CYAN,
            "TTS": Fore.MAGENTA,
            "WAKE": Fore.LIGHTGREEN_EX,
            "RECOVERY": Fore.RED,
            "ERROR": Fore.RED,
            "STATUS": Fore.BLUE,
            "AGENT": Fore.CYAN
        }
        c = tag_colors.get(tag, color)
        timestamp = time.strftime("%H:%M:%S")
        print(f"{Fore.WHITE}[{timestamp}] {c}[{tag}]{Fore.RESET} {message}")

    def set_state(self, new_state: str):
        with self._lock:
            self.state = new_state
            dashboard.emit_status(new_state)

    def on_double_clap(self):
        """Callback triggered when acoustic detector catches two claps."""
        if self.state == self.STATE_SLEEP:
            print()
            self.log("CLAP DETECTED", "Double clap confirmed! Waking up...", Fore.GREEN)
            self._wake_event.set()

    def wake_up(self, spoken_greeting: bool = True):
        """Transitions assistant from sleep to active."""
        self.set_state(self.STATE_ACTIVE)
        if spoken_greeting:
            greeting = f"नमस्ते {config.USER_TITLE}! मैं ऑनलाइन हूँ। बताइए मैं आपकी क्या सहायता कर सकता हूँ?"
            self.speak_with_barge_in(greeting)

    def go_to_sleep(self, spoken_farewell: bool = True):
        """Transitions assistant into sleep / standby mode."""
        farewell = f"अब मैं स्लीप मोड में जा रहा हूँ, {config.USER_TITLE}। जब भी ज़रूरत हो, दो बार ताली बजाएं।"
        if spoken_farewell:
            self.set_state(self.STATE_SPEAKING)
            self.log("MJ", f'"{farewell}"', Fore.MAGENTA)
            print()
            speak(farewell, blocking=True)
        self.set_state(self.STATE_SLEEP)
        self._wake_event.clear()

    def speak_with_barge_in(self, text: str):
        """
        Speaks text while actively monitoring for user interruption.
        If user speaks, audio terminates in 0ms and captures user's new command.
        """
        self.set_state(self.STATE_SPEAKING)
        self.log("MJ", f'"{text}"', Fore.MAGENTA)
        dashboard.emit_reply(text)

        # Start speech playback asynchronously
        speak(text, blocking=False)
        time.sleep(0.08)

        # Monitor microphone while speaking for barge-in
        def on_interrupt():
            self.set_state(self.STATE_INTERRUPTED)
            self.log("VOICE", "Barge-in interruption detected! Halting speech.", Fore.YELLOW)
            speech_engine.stop()

        interrupted_chunks = voice_listener.monitor_barge_in(
            is_speaking_check=lambda: speech_engine.is_speaking,
            on_interrupt_callback=on_interrupt
        )

        while speech_engine.is_speaking:
            time.sleep(0.02)

        print()
        self.set_state(self.STATE_ACTIVE)
        return interrupted_chunks

    def handle_command(self, user_text: str):
        """Processes voice or typed command from Sir."""
        user_text = user_text.strip()
        if not user_text:
            return None

        # Blank line before new user input for clean separation
        print()
        self.log("USER", f'"{user_text}"', Fore.YELLOW)
        dashboard.emit_transcript(user_text)

        # Check immediate sleep triggers (Strict: only sleep on explicit sleep commands!)
        lower_cmd = user_text.lower().strip()
        strict_sleep_triggers = [
            "sleep", "ok goodbye", "go to sleep", "shut down assistant",
            "so jao", "sojao", "alvida", "chup ho jao", "band ho jao", "सो जाओ", "अलविदा"
        ]
        is_explicit_sleep = any(lower_cmd == t or lower_cmd.startswith(t + " ") or lower_cmd.endswith(" " + t) for t in strict_sleep_triggers)
        if is_explicit_sleep:
            self.go_to_sleep()
            return None

        # Consult brain (Context-aware reasoning with sub-millisecond heuristics)
        self.set_state(self.STATE_PROCESSING)
        decision = brain.process_command(user_text)

        system_action = decision.get("system_action", "conversational")
        action_param = decision.get("action_param")
        terminal_cmd = decision.get("terminal_command")
        voice_response = decision.get("voice_response", f"जी {config.USER_TITLE}।")

        # =========================================================================
        # EXECUTE IN BACKGROUND SILENTLY (Terminal output suppressed as requested)
        # =========================================================================
        execution_output = ""
        if system_action == "stop_current":
            speech_engine.stop()
            interrupted_chunk = self.speak_with_barge_in(voice_response)
            return interrupted_chunk
        elif system_action == "sleep_assistant":
            if is_explicit_sleep:
                self.go_to_sleep()
                return None
            else:
                # Parting phrase (e.g. "see you next time") without explicit sleep: stay awake!
                self.speak_with_barge_in(voice_response)
                return None
        elif system_action == "autonomous_goal":
            goal = str(action_param) if action_param else user_text
            self.log("AGENT", f"Autonomous multi-step execution: '{goal}'", Fore.CYAN)
            res = master_agent.run_goal(goal)
            execution_output = res.get("summary", "")
            voice_response = res.get("voice_response", voice_response)
        elif system_action == "open_explorer":
            execution_output = terminal_controller.open_explorer()
        elif system_action == "open_folder" and action_param:
            execution_output = terminal_controller.open_folder(str(action_param))
        elif system_action == "create_folder":
            folder_name = str(action_param) if action_param else "New Folder"
            execution_output = terminal_controller.create_folder(folder_name)
        elif system_action == "delete_folder" and action_param:
            execution_output = terminal_controller.delete_folder(str(action_param))
        elif system_action == "rename_folder" and action_param:
            if isinstance(action_param, dict):
                execution_output = terminal_controller.rename_folder(action_param.get("old", ""), action_param.get("new", ""))
            elif isinstance(action_param, (list, tuple)) and len(action_param) >= 2:
                execution_output = terminal_controller.rename_folder(action_param[0], action_param[1])
        elif system_action == "open_file" and action_param:
            execution_output = terminal_controller.open_file(str(action_param))
        elif system_action == "create_file":
            file_name = str(action_param) if action_param else "New Document.txt"
            execution_output = terminal_controller.create_file(file_name)
        elif system_action == "delete_file" and action_param:
            execution_output = terminal_controller.delete_file(str(action_param))
        elif system_action == "rename_file" and action_param:
            if isinstance(action_param, dict):
                execution_output = terminal_controller.rename_file(action_param.get("old", ""), action_param.get("new", ""))
            elif isinstance(action_param, (list, tuple)) and len(action_param) >= 2:
                execution_output = terminal_controller.rename_file(action_param[0], action_param[1])
        elif system_action == "share_item" and action_param:
            execution_output = terminal_controller.share_item(str(action_param))
        elif system_action == "whatsapp_call":
            if isinstance(action_param, dict):
                contact = action_param.get("contact", "")
                call_type = action_param.get("type", "voice")
                platform = action_param.get("platform", "whatsapp")
                execution_output = terminal_controller.whatsapp_call(contact, call_type, platform)
            else:
                execution_output = terminal_controller.whatsapp_call(str(action_param) if action_param else "")
        elif system_action == "send_file_whatsapp" and action_param:
            if isinstance(action_param, dict):
                contact = action_param.get("contact", "")
                fl = action_param.get("file", "")
                execution_output = terminal_controller.send_file_whatsapp(contact, fl)
            else:
                execution_output = terminal_controller.send_file_whatsapp("", str(action_param))
        elif system_action == "clear_search_box":
            execution_output = terminal_controller.clear_search_box()
        elif system_action == "clear_message_box":
            execution_output = terminal_controller.clear_message_box(str(action_param) if action_param else "")
        elif system_action == "focus_app" and action_param:
            execution_output = terminal_controller.focus_app(str(action_param))
        elif system_action == "in_app_undo":
            execution_output = terminal_controller.in_app_undo()
        elif system_action == "in_app_redo":
            execution_output = terminal_controller.in_app_redo()
        elif system_action == "in_app_select_all":
            execution_output = terminal_controller.in_app_select_all()
        elif system_action == "in_app_copy":
            execution_output = terminal_controller.in_app_copy()
        elif system_action == "in_app_paste":
            execution_output = terminal_controller.in_app_paste()
        elif system_action == "in_app_cut":
            execution_output = terminal_controller.in_app_cut()
        elif system_action == "in_app_window_control" and action_param:
            execution_output = terminal_controller.in_app_window_control(str(action_param))
        elif system_action == "context_task":
            if isinstance(action_param, dict):
                task = action_param.get("task", "write_text")
                payload = action_param.get("payload", "")
                execution_output = terminal_controller.execute_context_task(task, payload)
            else:
                execution_output = terminal_controller.execute_context_task("write_text", str(action_param))
        elif system_action == "whatsapp_search" and action_param:
            execution_output = terminal_controller.search_whatsapp_contact(str(action_param))
            voice_response = execution_output
        elif system_action == "whatsapp_read":
            execution_output = terminal_controller.read_whatsapp_message(str(action_param) if action_param else "")
            voice_response = execution_output
        elif system_action == "whatsapp_unread":
            execution_output = terminal_controller.read_whatsapp_unread()
            voice_response = execution_output
        elif system_action == "whatsapp_reply" and action_param:
            execution_output = terminal_controller.reply_whatsapp(str(action_param))
            voice_response = execution_output
        elif system_action == "get_whatsapp_status":
            execution_output = terminal_controller.get_whatsapp_status()
            voice_response = execution_output
        elif system_action == "get_mj_status":
            execution_output = terminal_controller.get_mj_status()
            voice_response = execution_output
        elif system_action == "send_whatsapp_message":
            if isinstance(action_param, dict):
                contact = action_param.get("contact", "")
                msg = action_param.get("message", "")
                execution_output = terminal_controller.send_whatsapp(contact, msg)
            elif isinstance(action_param, str):
                execution_output = terminal_controller.send_whatsapp("", action_param)
            voice_response = execution_output
        elif system_action == "open_social" and action_param:
            execution_output = terminal_controller.open_social_platform(str(action_param))
        elif system_action == "type_in_app" and action_param:
            execution_output = terminal_controller.type_in_app(str(action_param))
        elif system_action == "in_app_key" and action_param:
            execution_output = terminal_controller.in_app_key(str(action_param))
        elif system_action == "in_app_hotkey" and action_param:
            execution_output = terminal_controller.in_app_hotkey(str(action_param))
        elif system_action == "in_app_scroll" and action_param:
            execution_output = terminal_controller.in_app_scroll(str(action_param))
        elif system_action in ["open_app", "open_any"] and action_param:
            execution_output = terminal_controller.open_application(str(action_param))
        elif system_action == "set_volume" and action_param:
            try:
                vol_num = int(''.join(filter(str.isdigit, str(action_param))))
                execution_output = terminal_controller.set_volume(vol_num)
            except Exception:
                execution_output = terminal_controller.set_volume(50)
        elif system_action == "mute":
            execution_output = terminal_controller.mute_volume()
        elif system_action == "get_battery":
            execution_output = terminal_controller.get_battery_status()
            voice_response = execution_output
        elif system_action == "get_system_stats":
            execution_output = terminal_controller.get_system_stats()
            voice_response = execution_output
        elif system_action == "google_search" and action_param:
            execution_output = terminal_controller.search_google(str(action_param))
        elif system_action == "youtube_play" and action_param:
            execution_output = terminal_controller.play_youtube(str(action_param))
        elif system_action == "media_control":
            execution_output = terminal_controller.media_play_pause()
        elif system_action == "minimize_windows":
            execution_output = terminal_controller.minimize_all_windows()
        elif system_action == "screenshot":
            execution_output = terminal_controller.take_screenshot()
        elif system_action == "lock_screen":
            execution_output = terminal_controller.lock_workstation()
        elif system_action == "sleep_laptop":
            execution_output = terminal_controller.sleep_laptop()
        elif system_action == "shutdown_laptop":
            execution_output = terminal_controller.shutdown_laptop()
        elif system_action == "cancel_shutdown":
            execution_output = terminal_controller.cancel_shutdown()

        # Run custom PowerShell command in background whenever returned
        if terminal_cmd:
            res = terminal_controller.run_powershell(terminal_cmd)
            dashboard.emit_terminal_log(terminal_cmd, res["stdout"] or res["stderr"])

        # Speak with Barge-In capability
        interrupted_chunk = self.speak_with_barge_in(voice_response)
        return interrupted_chunk

    def keyboard_listener_thread(self):
        """Allows Sir to type commands directly into terminal at any time."""
        while self.is_running:
            try:
                line = sys.stdin.readline()
                if not line:
                    break
                text = line.strip()
                if text:
                    speech_engine.stop()
                    if self.state == self.STATE_SLEEP:
                        self.wake_up(spoken_greeting=False)
                    self.handle_command(text)
                else:
                    if self.state == self.STATE_SLEEP:
                        self.wake_up(spoken_greeting=True)
            except Exception:
                break

    def run(self):
        """Master event loop powered by unified persistent audio stream."""
        self.print_banner()

        # Start permanent audio stream once
        voice_listener.start_stream()

        # Connect Dashboard callbacks
        dashboard.on_command_callback = self.handle_command
        dashboard.on_wake_callback = lambda: self.wake_up(spoken_greeting=True)
        dashboard.on_sleep_callback = lambda: self.go_to_sleep(spoken_farewell=True)

        def on_master_event(event_name, payload):
            if event_name == "task_started":
                dashboard.emit_task_started(payload.get("goal", ""), payload.get("total_steps", 1))
            elif event_name == "task_step":
                dashboard.emit_task_step(payload.get("step_id", 1), payload.get("description", ""), payload.get("tool", ""))
            elif event_name == "tool_called":
                dashboard.emit_tool_called(payload.get("tool", ""), payload.get("params", {}))
            elif event_name == "tool_result":
                dashboard.emit_tool_result(payload.get("tool", ""), str(payload.get("result", "")))
            elif event_name == "task_completed":
                dashboard.emit_task_completed(payload.get("goal", ""), payload.get("summary", ""))
            elif event_name == "task_failed":
                dashboard.emit_task_failed(payload.get("step_id", 0), payload.get("error", ""))

        master_agent.on_dashboard_event = on_master_event

        try:
            dashboard.start_dashboard_server()
        except Exception:
            pass

        # Start background keyboard thread
        kb_thread = threading.Thread(target=self.keyboard_listener_thread, daemon=True)
        kb_thread.start()

        self.set_state(self.STATE_IDLE)
        self.log("INITIALIZED", "Always-ready audio stream active. Say 'Hey MJ', clap twice, or press ENTER.", Fore.GREEN)
        print()

        carry_over_chunks = None

        def on_audio_recovery(msg: str):
            self.set_state(self.STATE_RECOVERING_AUDIO)
            self.log("RECOVERY", msg, Fore.RED)
            time.sleep(0.04)
            self.set_state(self.STATE_IDLE if self.state in [self.STATE_SLEEP, self.STATE_IDLE] else self.STATE_ACTIVE)

        voice_listener.on_recovery_callback = on_audio_recovery

        try:
            last_status = None
            def on_voice_status(status_msg):
                nonlocal last_status
                if status_msg != last_status:
                    self.log("VOICE", status_msg, Fore.CYAN)
                    last_status = status_msg

            while self.is_running:
                if self.state in [self.STATE_SLEEP, self.STATE_IDLE]:
                    last_status = None
                    # Dual-mode wake detector: acoustic double-clap OR spoken wake phrase
                    wake_res = voice_listener.listen_for_wake_or_clap(timeout=0.35)
                    if wake_res:
                        if wake_res.get("type") == "clap":
                            self.on_double_clap()
                        elif wake_res.get("type") == "voice":
                            text = wake_res.get("text", "").strip()
                            self.log("WAKE", f'Voice wake trigger detected: "{text}"', Fore.GREEN)
                            # Check if command followed wake word
                            cmd = text
                            for p in ["hey mj ", "mj ", "hello mj ", "suno mj ", "sunno mj "]:
                                if cmd.lower().startswith(p):
                                    cmd = cmd[len(p):].strip()
                            if cmd and cmd.lower() not in ["mj", "hey mj", "suno", "sunno"]:
                                self.wake_up(spoken_greeting=False)
                                carry_over_chunks = self.handle_command(cmd)
                            else:
                                self.wake_up(spoken_greeting=True)

                    if self._wake_event.is_set():
                        self.wake_up(spoken_greeting=True)
                else:
                    # MJ is active - continuously listen for voice commands without freezing or timeouts
                    self.set_state(self.STATE_LISTENING)
                    spoken_text = voice_listener.listen(
                        status_callback=on_voice_status,
                        initial_chunks=carry_over_chunks,
                        is_active_check=lambda: self.is_running and self.state not in [self.STATE_SLEEP, self.STATE_IDLE]
                    )
                    carry_over_chunks = None

                    if spoken_text:
                        last_status = None
                        carry_over_chunks = self.handle_command(spoken_text)

                    # Return to ACTIVE state if not sleeping so loop repeats smoothly
                    if self.state not in [self.STATE_SLEEP, self.STATE_IDLE]:
                        self.set_state(self.STATE_ACTIVE)

                    time.sleep(0.04)

        except KeyboardInterrupt:
            print()
            self.log("MJ", f"Shutting down MJ gracefully. Goodbye, {config.USER_TITLE}!", Fore.RED)
            speak(f"एमजे को बंद किया जा रहा है। अलविदा, {config.USER_TITLE}!", blocking=True)
            self.is_running = False
        finally:
            voice_listener.stop_stream()


if __name__ == "__main__":
    app = MJAssistant()
    app.run()
