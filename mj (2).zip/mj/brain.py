import json
import re
import requests
from typing import Dict, Any, List
import config
from app_automator import automator
from backend.intent_parser import intent_parser
from backend.context_engine import context_engine

class MJBrain:
    """
    Context-Aware Cognitive Core for MJ with sub-millisecond local routing,
    robust fuzzy matching, and low-latency cloud reasoning.
    """
    def __init__(self, api_key: str = config.GEMINI_API_KEY, model: str = config.FAST_GEMINI_MODEL):
        self.api_key = api_key
        self.model = model
        self.endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        self.groq_key = config.GROQ_API_KEY
        self.history: List[Dict[str, Any]] = []

    def _quick_heuristic_match(self, text: str) -> Dict[str, Any] | None:
        """
        Instant local heuristics (<1ms): Handles app opens (with typos/fuzzy logic),
        contextual tasks, WhatsApp messaging, and system controls without any cloud lag.
        """
        lower = text.lower().strip()
        cleaned = lower.replace(",", " ").replace(".", " ").replace(";", " ")
        cleaned = " ".join(cleaned.split()) # collapse whitespace
        # Collapse hyphenated spelled-out words (e.g. 'm-u-m-m-y' -> 'mummy', 'r-i-t-u-r-a-j' -> 'rituraj')
        cleaned = re.sub(r'(?<=\b[a-zA-Z])-(?=[a-zA-Z]\b)', '', cleaned)

        ctx = automator.get_context()
        active_app = ctx.get("app") or ""

        # Casual departure / parting phrase protection (DO NOT SLEEP on casual greetings!)
        if any(w in cleaned for w in ["see you next time", "see you later", "talk to you later", "catch you later", "phir milenge", "baad me milte", "baad mein milte", "alvida nahi"]):
            return {
                "thought": "Friendly departure greeting from Sir; assistant remains awake and listening",
                "system_action": "conversational",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"ज़रूर {config.USER_TITLE}! मैं यहीं आपकी सेवा में उपस्थित हूँ।"
            }

        # User Name / Identity Check
        if any(w in cleaned for w in ["what is my name", "what's my name", "who am i", "my name is", "mera naam kya hai", "mera naam", "main kaun hoon"]):
            user_name = getattr(config, 'USER_NAME', 'Rituraj')
            return {
                "thought": "User asking about his identity",
                "system_action": "conversational",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"आपका नाम {user_name} है, {config.USER_TITLE}!"
            }

        # Clear Search Box
        if cleaned in ["clear the search box", "clear search box", "clear search", "clear search input", "clear search bar", "clear the search", "search box saaf karo", "search box clear karo", "search saaf karo"] or "सर्च बॉक्स" in cleaned:
            return {
                "thought": "Sir requested to clear the search box",
                "system_action": "clear_search_box",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"सर्च बॉक्स साफ कर दिया है, {config.USER_TITLE}।"
            }

        # Multi-Step Autonomous Goal Heuristics (compound instructions with 'aur', 'and', 'phir', 'then', 'karke')
        is_compound = any(c in cleaned for c in [" aur ", " and ", " phir ", " then ", " karke "])
        has_multi_verbs = sum(1 for v in ["kholo", "open", "search", "dhundho", "message", "likho", "write", "call", "save", "login", "form", "summary"] if v in cleaned) >= 2
        is_special_workflow = any(s in cleaned for s in ["login karo", "form bhar do", "summary batao", "summarize", "jo call aaye", "answer karo"])

        if (is_compound and has_multi_verbs) or is_special_workflow:
            return {
                "thought": "Multi-step autonomous goal detected from command syntax",
                "system_action": "autonomous_goal",
                "action_param": text,
                "terminal_command": None,
                "voice_response": f"समझ गया {config.USER_TITLE}। योजना पर काम शुरू कर रहा हूँ।"
            }

        # 1. Strict Sleep Triggers (ONLY explicit commands)
        if any(cleaned == t or cleaned.startswith(t + " ") or cleaned.endswith(" " + t) for t in ["sleep", "ok goodbye", "go to sleep", "shut down assistant", "so jao", "sojao", "alvida", "chup ho jao", "band ho jao", "सो जाओ", "अलविदा"]):
            return {
                "thought": "Sir explicitly requested assistant to sleep",
                "system_action": "sleep_assistant",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"अब मैं स्लीप मोड में जा रहा हूँ, {config.USER_TITLE}। जब भी ज़रूरत हो, दो बार ताली बजाएं।"
            }

        # 2. Message Box & In-App Text Deletion (Never treat message/letter clearing as file deletion!)
        msg_delete_patterns = [
            "delete this invitation letter", "delete invitation letter", "delete the invitation letter",
            "clear this invitation letter", "clear the invitation letter", "clear invitation letter",
            "delete this letter", "delete the letter", "clear this letter", "clear the letter",
            "delete this message", "delete the message", "delete message", "delete messages",
            "clear the message box", "clear message box", "clear this message box", "clear my message box",
            "clear the input", "clear input", "clear chat box", "clear the chat box", "clear chat",
            "clear message", "clear the message", "delete draft", "clear draft",
            "delete this text", "delete the text", "delete text", "clear text", "clear the text",
            "erase this", "erase text", "erase message", "erase the message",
            "delete what i typed", "clear what i typed", "remove this message", "remove the message",
            "ye message hatao", "message delete karo", "message saaf karo", "invitation letter hatao",
            "likha hua mitao", "draft mitao", "chat saaf karo"
        ]
        if any(p in cleaned for p in msg_delete_patterns):
            item_desc = "निमंत्रण पत्र (invitation letter)" if any(w in cleaned for w in ["invitation", "letter"]) else "मैसेज"
            return {
                "thought": f"Sir requested to clear/delete {item_desc} in the message box / active app",
                "system_action": "clear_message_box",
                "action_param": item_desc,
                "terminal_command": None,
                "voice_response": f"मैसेज बॉक्स से {item_desc} हटा दिया गया है, {config.USER_TITLE}।"
            }

        # 3. High-Performance Direct Spoken Intent Parsing (<1ms)
        parsed_intent = intent_parser.parse(text)
        if parsed_intent.get("is_compound"):
            return {
                "thought": f"Compound multi-step goal: {text}",
                "system_action": "autonomous_goal",
                "action_param": text,
                "terminal_command": None,
                "voice_response": f"समझ गया {config.USER_TITLE}। योजना पर काम शुरू कर रहा हूँ।"
            }

        p_intent = parsed_intent.get("intent")
        if p_intent == "media_control":
            act = parsed_intent.get("action", "play")
            if act == "open_first_video":
                return {
                    "thought": "Open first video result",
                    "system_action": "context_task",
                    "action_param": {"task": "open_first", "payload": ""},
                    "terminal_command": None,
                    "voice_response": f"पहला वीडियो खोल रहा हूँ, {config.USER_TITLE}।"
                }
            else:
                return {
                    "thought": f"Media control: {act}",
                    "system_action": "media_control",
                    "action_param": act,
                    "terminal_command": None,
                    "voice_response": f"वीडियो {'प्ले' if act == 'play' else ('पॉज़' if act == 'pause' else act)} कर दिया है, {config.USER_TITLE}।"
                }

        elif p_intent == "mj_status":
            from terminal_controller import controller as term_ctrl
            status_summary = term_ctrl.get_mj_status()
            return {
                "thought": "Diagnostic status check requested",
                "system_action": "get_mj_status",
                "action_param": None,
                "terminal_command": None,
                "voice_response": status_summary
            }

        elif p_intent == "whatsapp_status":
            from terminal_controller import controller as term_ctrl
            wa_summary = term_ctrl.get_whatsapp_status()
            return {
                "thought": "WhatsApp status check requested",
                "system_action": "get_whatsapp_status",
                "action_param": None,
                "terminal_command": None,
                "voice_response": wa_summary
            }

        elif p_intent == "whatsapp_search":
            contact = parsed_intent.get("contact", "")
            return {
                "thought": f"Search contact {contact} on WhatsApp",
                "system_action": "whatsapp_search",
                "action_param": contact,
                "terminal_command": None,
                "voice_response": f"{contact}'s chat is open."
            }

        elif p_intent == "whatsapp_read":
            contact = parsed_intent.get("contact", "")
            return {
                "thought": f"Read WhatsApp message{' from ' + contact if contact else ''}",
                "system_action": "whatsapp_read",
                "action_param": contact,
                "terminal_command": None,
                "voice_response": f"Reading WhatsApp message..."
            }

        elif p_intent == "whatsapp_unread":
            return {
                "thought": "Check unread WhatsApp messages",
                "system_action": "whatsapp_unread",
                "action_param": None,
                "terminal_command": None,
                "voice_response": "Checking unread messages..."
            }

        elif p_intent == "whatsapp_reply":
            msg = parsed_intent.get("message", "")
            return {
                "thought": f"Reply in active WhatsApp chat: {msg}",
                "system_action": "whatsapp_reply",
                "action_param": msg,
                "terminal_command": None,
                "voice_response": "Replied."
            }

        elif p_intent == "whatsapp_send_file":
            c = parsed_intent.get("contact", "")
            f = parsed_intent.get("file", "")
            return {
                "thought": f"Send file {f} to {c} on WhatsApp",
                "system_action": "send_file_whatsapp",
                "action_param": {"contact": c, "file": f},
                "terminal_command": None,
                "voice_response": f"Sending file to {c}." if c else "Sending file."
            }

        elif p_intent == "send_message":
            contact = parsed_intent.get("contact", "")
            msg = parsed_intent.get("message", "")
            from backend.adapters.whatsapp_adapter import whatsapp_adapter
            resolved_contact = whatsapp_adapter.manager.context.resolve_contact(contact)
            if resolved_contact:
                contact = resolved_contact

            if contact and msg:
                return {
                    "thought": f"Send WhatsApp message to {contact}",
                    "system_action": "send_whatsapp_message",
                    "action_param": {"contact": contact, "message": msg},
                    "terminal_command": None,
                    "voice_response": f"{contact} को संदेश भेज दिया है, {config.USER_TITLE}।"
                }
            elif contact:
                return {
                    "thought": f"Search contact {contact}",
                    "system_action": "whatsapp_search",
                    "action_param": contact,
                    "terminal_command": None,
                    "voice_response": f"{contact} की चैट खोल दी है, {config.USER_TITLE}।"
                }
            elif msg:
                return {
                    "thought": f"Reply with message: {msg}",
                    "system_action": "whatsapp_reply",
                    "action_param": msg,
                    "terminal_command": None,
                    "voice_response": f"जवाब भेज दिया गया है, {config.USER_TITLE}।"
                }
            else:
                return {
                    "thought": "Send current message",
                    "system_action": "context_task",
                    "action_param": {"task": "send_it", "payload": ""},
                    "terminal_command": None,
                    "voice_response": f"मैसेज भेज दिया गया है, {config.USER_TITLE}।"
                }

        elif p_intent == "call":
            contact = parsed_intent.get("contact", "")
            c_type = parsed_intent.get("type", "voice")
            return {
                "thought": f"WhatsApp {c_type} call to {contact or 'active contact'}",
                "system_action": "whatsapp_call",
                "action_param": {"contact": contact, "type": c_type, "platform": "whatsapp"},
                "terminal_command": None,
                "voice_response": f"{contact + ' को व्हाट्सऐप पर कॉल मिला रहा हूँ' if contact else 'व्हाट्सऐप पर कॉल मिला रहा हूँ'}, {config.USER_TITLE}।"
            }

        elif p_intent == "search_in_app":
            query = parsed_intent.get("query", "")
            app = parsed_intent.get("application") or active_app
            if app == "youtube" or ("youtube" in (automator.get_active_window_title() or "").lower()):
                return {
                    "thought": f"Search YouTube for '{query}'",
                    "system_action": "youtube_play",
                    "action_param": query,
                    "terminal_command": None,
                    "voice_response": f"यूट्यूब पर '{query}' खोज रहा हूँ, {config.USER_TITLE}।"
                }
            else:
                return {
                    "thought": f"Search '{query}' in {app or 'active app'}",
                    "system_action": "context_task",
                    "action_param": {"task": "search_inside", "payload": query},
                    "terminal_command": None,
                    "voice_response": f"'{query}' खोज रहा हूँ, {config.USER_TITLE}।"
                }

        elif p_intent == "type_in_app":
            text_to_write = parsed_intent.get("text", "")
            return {
                "thought": f"Write text into active app",
                "system_action": "context_task",
                "action_param": {"task": "write_text", "payload": text_to_write},
                "terminal_command": None,
                "voice_response": f"लिख दिया गया है, {config.USER_TITLE}।"
            }

        elif p_intent == "save_file":
            fname = parsed_intent.get("file_name", "")
            return {
                "thought": f"Save file as {fname}",
                "system_action": "context_task",
                "action_param": {"task": "save_file", "payload": fname},
                "terminal_command": None,
                "voice_response": f"दस्तावेज़{' ' + fname + ' के रूप में' if fname else ''} सहेज लिया गया है, {config.USER_TITLE}।"
            }

        elif p_intent == "close_context":
            return {
                "thought": "Close active context/tab",
                "system_action": "context_task",
                "action_param": {"task": "close_context", "payload": ""},
                "terminal_command": None,
                "voice_response": f"बंद कर रहा हूँ, {config.USER_TITLE}।"
            }

        elif p_intent == "open_app":
            target_app = parsed_intent.get("application", "")
            resp = "WhatsApp is open." if target_app.lower() == "whatsapp" else f"{target_app.title()} खोल रहा हूँ, {config.USER_TITLE}।"
            return {
                "thought": f"Sir requested to open '{target_app}'",
                "system_action": "open_any",
                "action_param": target_app,
                "terminal_command": None,
                "voice_response": resp
            }

        elif p_intent == "stop_task":
            return {
                "thought": "Sir requested immediate stop or cancellation",
                "system_action": "stop_current",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"जी {config.USER_TITLE}, रोक दिया है।"
            }

        elif p_intent == "open_file":
            fl = parsed_intent.get("file", "")
            return {
                "thought": f"Sir requested to open file '{fl}'",
                "system_action": "open_file",
                "action_param": fl,
                "terminal_command": None,
                "voice_response": f"फ़ाइल {fl} खोल रहा हूँ, {config.USER_TITLE}।"
            }

        elif p_intent == "open_folder":
            fol = parsed_intent.get("folder", "")
            return {
                "thought": f"Sir requested to open folder '{fol}'",
                "system_action": "open_folder",
                "action_param": fol,
                "terminal_command": None,
                "voice_response": f"{fol.title()} फ़ोल्डर खोल रहा हूँ, {config.USER_TITLE}।"
            }

        elif p_intent == "get_battery":
            return {
                "thought": "Sir requested battery telemetry",
                "system_action": "get_battery",
                "action_param": None,
                "terminal_command": None,
                "voice_response": ""
            }

        elif p_intent == "set_volume":
            lvl = parsed_intent.get("level", 50)
            return {
                "thought": f"Sir requested volume set to {lvl}",
                "system_action": "set_volume",
                "action_param": lvl,
                "terminal_command": None,
                "voice_response": f"वॉल्यूम {lvl} प्रतिशत पर सेट कर दिया है, {config.USER_TITLE}।"
            }

        elif p_intent == "screenshot":
            return {
                "thought": "Sir requested screenshot",
                "system_action": "screenshot",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"स्क्रीनशॉट ले लिया गया है, {config.USER_TITLE}।"
            }

        elif p_intent == "sleep_laptop":
            return {
                "thought": "Sir requested laptop sleep",
                "system_action": "sleep_laptop",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"लैपटॉप को स्लीप मोड में डाल रहा हूँ, {config.USER_TITLE}।"
            }

        elif p_intent == "context_continue":
            return {
                "thought": "Continue/repeat context action in active window",
                "system_action": "context_task",
                "action_param": {"task": "continue", "payload": ""},
                "terminal_command": None,
                "voice_response": f"जी {config.USER_TITLE}, आगे बढ़ रहा हूँ।"
            }

        # 3. File Explorer & Open Files (NEVER search in browser!)
        if cleaned in ["open file", "open files", "open file explorer", "open explorer", "open my files", "show my files", "show files", "file explorer", "explorer", "file explorer kholo", "files dikhao", "file kholo", "फ़ाइल एक्सप्लोरर खोलो", "फाइल खोलो"]:
            return {
                "thought": "Sir requested to open File Explorer",
                "system_action": "open_explorer",
                "action_param": None,
                "terminal_command": "explorer.exe",
                "voice_response": f"फ़ाइल एक्सप्लोरर खोल रहा हूँ, {config.USER_TITLE}।"
            }

        # 3. Dedicated Folder Operations (Open, Create, Rename, Delete)
        # Open Folder
        open_folder_match = re.search(r"^(?:open|show|kholo)\s+(?:the\s+)?folder(?:\s+(?:named|called)\s+|\s+)?(.+)", cleaned)
        if not open_folder_match:
            open_folder_match = re.search(r"^(?:open|kholo)\s+(.+?)\s+folder$", cleaned)
        if open_folder_match:
            fol_name = open_folder_match.group(1).strip()
            return {
                "thought": f"Sir requested to open folder '{fol_name}'",
                "system_action": "open_folder",
                "action_param": fol_name,
                "terminal_command": None,
                "voice_response": f"फ़ाइल एक्सप्लोरर में {fol_name} फ़ोल्डर खोल रहा हूँ, {config.USER_TITLE}।"
            }

        if cleaned in ["open desktop", "open downloads", "open documents", "open pictures", "open videos", "open music", "desktop kholo", "downloads kholo", "documents kholo"]:
            f_target = cleaned.replace("open ", "").replace(" kholo", "").strip()
            return {
                "thought": f"Sir wants to open {f_target} folder",
                "system_action": "open_folder",
                "action_param": f_target,
                "terminal_command": None,
                "voice_response": f"आपका {f_target.title()} फ़ोल्डर खोल रहा हूँ, {config.USER_TITLE}।"
            }

        # Rename Folder
        rename_fol_match = re.search(r"rename\s+(?:the\s+)?folder\s+(.+?)\s+to\s+(.+)", cleaned)
        if not rename_fol_match:
            rename_fol_match = re.search(r"rename\s+(.+?)\s+folder\s+to\s+(.+)", cleaned)
        if rename_fol_match:
            old_f = rename_fol_match.group(1).strip()
            new_f = rename_fol_match.group(2).strip()
            return {
                "thought": f"Sir requested to rename folder '{old_f}' to '{new_f}'",
                "system_action": "rename_folder",
                "action_param": {"old": old_f, "new": new_f},
                "terminal_command": None,
                "voice_response": f"फ़ोल्डर {old_f} का नाम बदलकर {new_f} कर दिया गया है, {config.USER_TITLE}।"
            }

        # Delete Folder
        del_fol_match = re.search(r"(?:delete|remove|hatao)\s+(?:the\s+)?folder\s+(.+)", cleaned)
        if not del_fol_match:
            del_fol_match = re.search(r"(?:delete|remove|hatao)\s+(.+?)\s+folder$", cleaned)
        if del_fol_match:
            dname = del_fol_match.group(1).strip()
            return {
                "thought": f"Sir requested to delete folder '{dname}'",
                "system_action": "delete_folder",
                "action_param": dname,
                "terminal_command": None,
                "voice_response": f"फ़ोल्डर {dname} हटा दिया गया है, {config.USER_TITLE}।"
            }

        # Create Folder
        create_folder_match = re.search(r"(?:create|make|add|banao)\s+(?:a\s+)?(?:new\s+)?folder(?:\s+(?:named|called)\s+|\s+)?(.+)?", cleaned)
        if create_folder_match or "new folder" in cleaned or "naya folder" in cleaned:
            fname = "New Folder"
            if create_folder_match and create_folder_match.group(1):
                fname = create_folder_match.group(1).strip()
            return {
                "thought": f"Sir requested to create folder '{fname}' on Desktop",
                "system_action": "create_folder",
                "action_param": fname,
                "terminal_command": None,
                "voice_response": f"डेस्कटॉप पर नया फ़ोल्डर {fname} बना दिया गया है, {config.USER_TITLE}।"
            }

        # 4. Dedicated File Operations (Create, Open, Rename, Delete, Share)
        # Create File
        create_file_match = re.search(r"(?:create|make|add|banao)\s+(?:a\s+)?(?:new\s+)?file(?:\s+(?:named|called)\s+|\s+)?(.+)?", cleaned)
        if create_file_match:
            fl_name = create_file_match.group(1).strip() if create_file_match.group(1) else "New Document.txt"
            return {
                "thought": f"Sir requested to create file '{fl_name}'",
                "system_action": "create_file",
                "action_param": fl_name,
                "terminal_command": None,
                "voice_response": f"डेस्कटॉप पर नई फ़ाइल {fl_name} बना दी गई है, {config.USER_TITLE}।"
            }

        # Rename File
        rename_file_match = re.search(r"rename\s+(?:the\s+)?file\s+(.+?)\s+to\s+(.+)", cleaned)
        if rename_file_match:
            old_fl = rename_file_match.group(1).strip()
            new_fl = rename_file_match.group(2).strip()
            return {
                "thought": f"Sir requested to rename file '{old_fl}' to '{new_fl}'",
                "system_action": "rename_file",
                "action_param": {"old": old_fl, "new": new_fl},
                "terminal_command": None,
                "voice_response": f"फ़ाइल {old_fl} का नाम बदलकर {new_fl} कर दिया गया है, {config.USER_TITLE}।"
            }

        # Delete File
        del_file_match = re.search(r"(?:delete|remove|hatao)\s+(?:the\s+)?file\s+(.+)", cleaned)
        if del_file_match:
            fl_name = del_file_match.group(1).strip()
            return {
                "thought": f"Sir requested to delete file '{fl_name}'",
                "system_action": "delete_file",
                "action_param": fl_name,
                "terminal_command": None,
                "voice_response": f"फ़ाइल {fl_name} हटा दी गई है, {config.USER_TITLE}।"
            }

        # Open Specific File
        open_file_match = re.search(r"^(?:open|kholo)\s+(?:the\s+)?file\s+(.+)", cleaned)
        if not open_file_match:
            open_file_match = re.search(r"^(?:open|kholo)\s+document\s+(.+)", cleaned)
        if open_file_match:
            fl_name = open_file_match.group(1).strip()
            return {
                "thought": f"Sir requested to open file '{fl_name}'",
                "system_action": "open_file",
                "action_param": fl_name,
                "terminal_command": None,
                "voice_response": f"फ़ाइल {fl_name} खोल रहा हूँ, {config.USER_TITLE}।"
            }

        # Share / Reveal in Explorer
        share_match = re.search(r"(?:share|show)\s+(?:the\s+)?(?:folder\s+|file\s+)?(.+?)(?:\s+in explorer)?$", cleaned)
        if share_match and any(w in cleaned for w in ["share", "show in explorer", "reveal"]):
            sh_name = share_match.group(1).strip()
            return {
                "thought": f"Sir requested to share '{sh_name}'",
                "system_action": "share_item",
                "action_param": sh_name,
                "terminal_command": None,
                "voice_response": f"{sh_name} को शेयर करने के लिए चुन लिया गया है, {config.USER_TITLE}।"
            }

        # 5. WhatsApp & Social Calling (Voice & Video Calls)
        if any(cleaned == t or cleaned.startswith(t + " ") for t in ["call them", "call him", "call her", "call this person", "make a call", "voice call them", "video call them", "unhe call karo", "call lagao"]):
            call_type = "video" if "video" in cleaned else "voice"
            return {
                "thought": f"Sir requested to make a {call_type} call to active contact",
                "system_action": "whatsapp_call",
                "action_param": {"contact": "", "type": call_type, "platform": "whatsapp"},
                "terminal_command": None,
                "voice_response": f"व्हाट्सऐप पर कॉल मिला रहा हूँ, {config.USER_TITLE}।"
            }

        call_match = re.search(r"^(?:call|make a call to|voice call|video call|phone|ring|call lagao|call karo)\s+(?:to\s+)?(.+?)(?:\s+on\s+(whatsapp|instagram)|\s+par\s+(whatsapp|instagram))?$", cleaned)
        if call_match:
            target = call_match.group(1).strip()
            platform = call_match.group(2) or call_match.group(3) or "whatsapp"
            for p in ["to ", "my ", "ko "]:
                if target.startswith(p):
                    target = target[len(p):].strip()
                if target.endswith(" ko"):
                    target = target[:-3].strip()
            call_type = "video" if "video" in cleaned else "voice"
            return {
                "thought": f"Sir wants to {call_type} call {target} on {platform}",
                "system_action": "whatsapp_call",
                "action_param": {"contact": target, "type": call_type, "platform": platform},
                "terminal_command": None,
                "voice_response": f"{target} को {platform.title()} पर कॉल मिला रहा हूँ, {config.USER_TITLE}।"
            }

        # 6. Upload / Send File to Contact in WhatsApp
        file_send_match = re.search(r"(?:send|upload|share|bhejo)\s+(?:the\s+)?(?:file\s+|explorer file\s+|document\s+)?(.+?)\s+(?:to|with|ko)\s+([a-zA-Z0-9\s]+?)(?:\s+on whatsapp|\s+in whatsapp|\s+par)?$", cleaned)
        if file_send_match and any(w in cleaned for w in ["send", "upload", "share", "bhejo"]) and any(w in cleaned for w in ["to", "with", "ko"]):
            fl_name = file_send_match.group(1).strip()
            contact = file_send_match.group(2).strip()
            return {
                "thought": f"Sir wants to upload/send file '{fl_name}' to {contact} on WhatsApp",
                "system_action": "send_file_whatsapp",
                "action_param": {"file": fl_name, "contact": contact},
                "terminal_command": None,
                "voice_response": f"{contact} को व्हाट्सऐप पर फ़ाइल {fl_name} भेजी जा रही है, {config.USER_TITLE}।"
            }

        # 7. WhatsApp Messaging
        wa_match = re.search(r"(?:message|send message to|text|message bhejo)\s+([a-zA-Z0-9\s]+?)\s+(?:on whatsapp\s+|ko\s+)?(?:saying|that|ki)?\s*(.+)", cleaned)
        if wa_match and any(w in cleaned for w in ["message", "text", "whatsapp"]):
            contact = wa_match.group(1).strip()
            if contact.lower().startswith("to "):
                contact = contact[3:].strip()
            if contact.lower().endswith(" ko"):
                contact = contact[:-3].strip()
            if contact.strip() == "राच":
                contact = "Raj"
            msg = wa_match.group(2).strip()
            return {
                "thought": f"Sir wants to message {contact} on WhatsApp",
                "system_action": "send_whatsapp_message",
                "action_param": {"contact": contact, "message": msg},
                "terminal_command": None,
                "voice_response": f"{contact} को व्हाट्सऐप पर संदेश भेजा जा रहा है, {config.USER_TITLE}।"
            }

        # 6. Dedicated App Matches (including WhatsApp Stable vs Beta)
        if "second" in cleaned and "whatsapp" in cleaned:
            return {
                "thought": "Sir wants to open second WhatsApp",
                "system_action": "open_any",
                "action_param": "second_whatsapp",
                "terminal_command": None,
                "voice_response": f"वेब पर आपका दूसरा व्हाट्सऐप खोल रहा हूँ, {config.USER_TITLE}।"
            }

        if "beta" in cleaned and "whatsapp" in cleaned:
            return {
                "thought": "Sir explicitly requested WhatsApp Beta",
                "system_action": "open_any",
                "action_param": "whatsapp_beta",
                "terminal_command": None,
                "voice_response": f"व्हाट्सऐप बीटा खोल रहा हूँ, {config.USER_TITLE}।"
            }

        if any(w in cleaned for w in ["sotify", "spotify", "spotfy"]):
            return {
                "thought": "Sir wants Spotify",
                "system_action": "open_any",
                "action_param": "spotify",
                "terminal_command": None,
                "voice_response": f"स्पॉटिफ़ाई खोल रहा हूँ, {config.USER_TITLE}।"
            }

        if "whatsapp" in cleaned and not any(w in cleaned for w in ["message", "text", "send", "call", "कॉल", "मैसेज", "संदेश", "bhejo", "भेजो"]):
            return {
                "thought": "Sir wants stable WhatsApp",
                "system_action": "open_any",
                "action_param": "whatsapp",
                "terminal_command": None,
                "voice_response": f"व्हाट्सऐप खोल रहा हूँ, {config.USER_TITLE}।"
            }

        # 5. Contextual In-App Writing / Typing
        write_match = re.search(r"^(?:write|type|insert|likho)\s+(?:in it\s+|inside it\s+|this\s+|that\s+|isme\s+)?(.+)", cleaned)
        if write_match:
            content = write_match.group(1).strip()
            for prefix in ["that ", "this: ", "this "]:
                if content.startswith(prefix):
                    content = content[len(prefix):]
            return {
                "thought": f"Writing content into active {active_app or 'app'}",
                "system_action": "context_task",
                "action_param": {"task": "write_text", "payload": content},
                "terminal_command": None,
                "voice_response": f"{active_app or 'दस्तावेज़'} में लिख दिया गया है, {config.USER_TITLE}।"
            }

        # 5. Contextual In-App Searching
        search_match = re.search(r"^(?:search|find|look for|dhundho|khojo)\s+(?:in it\s+|inside it\s+|for\s+|isme\s+)?(.+)", cleaned)
        if search_match:
            query = search_match.group(1).strip()
            return {
                "thought": f"Searching for '{query}' in {active_app or 'app'}",
                "system_action": "context_task",
                "action_param": {"task": "search_inside", "payload": query},
                "terminal_command": None,
                "voice_response": f"'{query}' खोज रहा हूँ, {config.USER_TITLE}।"
            }

        # 6. Contextual Saving & Closing
        if any(w in cleaned for w in ["save this file", "save document", "save it", "save as", "save karo", "ise save karo"]):
            save_name_match = re.search(r"save (?:this file|document|it)?\s*as\s+(.+)", cleaned)
            filename = save_name_match.group(1).strip() if save_name_match else ""
            return {
                "thought": f"Saving current {active_app or 'file'}",
                "system_action": "context_task",
                "action_param": {"task": "save_file", "payload": filename},
                "terminal_command": None,
                "voice_response": f"दस्तावेज़{' ' + filename + ' के रूप में' if filename else ''} सहेज लिया गया है, {config.USER_TITLE}।"
            }

        if any(w in cleaned for w in ["close it", "close this", "close this tab", "close window", "band karo", "ise band karo"]):
            return {
                "thought": f"Closing active {active_app or 'window'}",
                "system_action": "context_task",
                "action_param": {"task": "close_context", "payload": ""},
                "terminal_command": None,
                "voice_response": f"{active_app or 'इसे'} बंद कर रहा हूँ, {config.USER_TITLE}।"
            }

        # 7. General Open Command
        open_match = re.search(r"^(?:open|launch|start|kholo)\s+(?:my\s+)?(.+)", cleaned)
        if open_match:
            target = open_match.group(1).strip()
            return {
                "thought": f"Sir requested to open '{target}'",
                "system_action": "open_any",
                "action_param": target,
                "terminal_command": None,
                "voice_response": f"{target} खोल रहा हूँ, {config.USER_TITLE}।"
            }

        # 8. Fast System Controls
        if "battery" in cleaned:
            return {
                "thought": "Battery status",
                "system_action": "get_battery",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"बैटरी की स्थिति देख रहा हूँ, {config.USER_TITLE}।"
            }

        if any(w in cleaned for w in ["screenshot", "screen shot", "स्क्रीनशॉट"]):
            return {
                "thought": "Screenshot",
                "system_action": "screenshot",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"स्क्रीनशॉट ले लिया गया है और डेस्कटॉप पर सहेज दिया गया है, {config.USER_TITLE}।"
            }

        if any(w in cleaned for w in ["scroll down", "niche scroll"]):
            return {
                "thought": "Scroll down",
                "system_action": "in_app_scroll",
                "action_param": "down",
                "terminal_command": None,
                "voice_response": f"नीचे स्क्रॉल कर रहा हूँ, {config.USER_TITLE}।"
            }

        if any(w in cleaned for w in ["scroll up", "upar scroll"]):
            return {
                "thought": "Scroll up",
                "system_action": "in_app_scroll",
                "action_param": "up",
                "terminal_command": None,
                "voice_response": f"ऊपर स्क्रॉल कर रहा हूँ, {config.USER_TITLE}।"
            }

        # 8. Focus / Switch Application
        focus_match = re.search(r"^(?:switch to|focus|go to|bring up|activate|par jao)\s+(?:app\s+|application\s+)?(.+)", cleaned)
        if focus_match:
            target_app = focus_match.group(1).strip()
            return {
                "thought": f"Sir requested to switch to '{target_app}'",
                "system_action": "focus_app",
                "action_param": target_app,
                "terminal_command": None,
                "voice_response": f"{target_app.title()} पर स्विच कर दिया है, {config.USER_TITLE}।"
            }

        # 9. In-App Editing & Clipboard Controls
        if cleaned in ["undo", "undo that", "undo this", "revert", "undo karo"]:
            return {
                "thought": "Undo last action",
                "system_action": "in_app_undo",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"पूर्ववत कर दिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["redo", "redo that", "redo karo"]:
            return {
                "thought": "Redo action",
                "system_action": "in_app_redo",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"फिर से लागू कर दिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["select all", "select all text", "select everything", "sab select karo"]:
            return {
                "thought": "Select all text",
                "system_action": "in_app_select_all",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"सारा टेक्स्ट चुन लिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["copy that", "copy this", "copy text", "copy", "copy karo"]:
            return {
                "thought": "Copy to clipboard",
                "system_action": "in_app_copy",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"क्लिपबोर्ड पर कॉपी कर लिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["paste that", "paste this", "paste text", "paste here", "paste", "paste karo"]:
            return {
                "thought": "Paste from clipboard",
                "system_action": "in_app_paste",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"पेस्ट कर दिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["cut that", "cut this", "cut text", "cut", "cut karo"]:
            return {
                "thought": "Cut to clipboard",
                "system_action": "in_app_cut",
                "action_param": None,
                "terminal_command": None,
                "voice_response": f"कट कर लिया गया है, {config.USER_TITLE}।"
            }

        # 10. Window Navigation & Tab Controls
        if cleaned in ["maximize", "maximize window", "maximise", "maximise window", "bada karo"]:
            return {
                "thought": "Maximize window",
                "system_action": "in_app_window_control",
                "action_param": "maximize",
                "terminal_command": None,
                "voice_response": f"विंडो को मैक्सिमाइज कर दिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["minimize window", "minimise window", "minimize active window", "chhota karo"]:
            return {
                "thought": "Minimize window",
                "system_action": "in_app_window_control",
                "action_param": "minimize",
                "terminal_command": None,
                "voice_response": f"विंडो को मिनीमाइज कर दिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["close tab", "close this tab", "tab band karo"]:
            return {
                "thought": "Close tab",
                "system_action": "in_app_window_control",
                "action_param": "close_tab",
                "terminal_command": None,
                "voice_response": f"टैब बंद कर दिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["new tab", "open new tab", "open a new tab", "naya tab"]:
            return {
                "thought": "New tab",
                "system_action": "in_app_window_control",
                "action_param": "new_tab",
                "terminal_command": None,
                "voice_response": f"नया टैब खोल दिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["refresh", "reload page", "reload", "refresh karo"]:
            return {
                "thought": "Refresh page",
                "system_action": "in_app_window_control",
                "action_param": "refresh",
                "terminal_command": None,
                "voice_response": f"पेज रीफ्रेश कर दिया गया है, {config.USER_TITLE}।"
            }
        if cleaned in ["press escape", "press esc", "cancel action", "cancel", "radd karo"]:
            return {
                "thought": "Press Escape",
                "system_action": "in_app_window_control",
                "action_param": "escape",
                "terminal_command": None,
                "voice_response": f"रद्द कर दिया गया है, {config.USER_TITLE}।"
            }

        if any(w in cleaned for w in ["press enter", "enter dabao"]):
            return {
                "thought": "Press enter",
                "system_action": "in_app_key",
                "action_param": "enter",
                "terminal_command": None,
                "voice_response": f"एंटर दबा दिया गया है, {config.USER_TITLE}।"
            }

        return None

    def _build_system_prompt(self) -> str:
        ctx = automator.get_context()
        active_app = ctx.get("app") or "None"
        active_file = ctx.get("file") or "None"
        fg_title = automator.get_active_window_title() or "None"

        return f"""You are {config.ASSISTANT_NAME}, a real-time male AI desktop assistant for Windows.
The user is your boss; address him respectfully as '{config.USER_TITLE}' or 'सर' (Sir).
CURRENT ACTIVE WINDOW CONTEXT: ForegroundWindow='{fg_title}', App='{active_app}', File='{active_file}'.

MANDATORY LANGUAGE RULE (HINDI ONLY):
- You MUST talk in HINDI ONLY and respond in HINDI ONLY (केवल हिंदी भाषा में ही बात करें और हिंदी में ही उत्तर दें).
- All 'voice_response' strings MUST strictly be in natural, polite Hindi (in Devanagari script हिंदी / देवनागरी) under 2 sentences.
- NEVER respond in English. Even if the user speaks in English or Hinglish, your response MUST be in Hindi.
- Address the user respectfully as '{config.USER_TITLE}' or 'सर' (e.g. 'जी सर', 'खोल रहा हूँ', 'कर दिया है').

Determine intent and return JSON:
{{
  "thought": "Brief reason in Hindi or English",
  "system_action": "One of: ['autonomous_goal', 'whatsapp_call', 'send_file_whatsapp', 'clear_search_box', 'clear_message_box', 'focus_app', 'in_app_undo', 'in_app_redo', 'in_app_select_all', 'in_app_copy', 'in_app_paste', 'in_app_cut', 'in_app_window_control', 'open_explorer', 'open_folder', 'create_folder', 'rename_folder', 'delete_folder', 'open_file', 'create_file', 'rename_file', 'delete_file', 'share_item', 'open_any', 'context_task', 'send_whatsapp_message', 'open_social', 'type_in_app', 'in_app_key', 'in_app_scroll', 'set_volume', 'mute', 'get_battery', 'get_system_stats', 'google_search', 'youtube_play', 'minimize_windows', 'screenshot', 'sleep_laptop', 'shutdown_laptop', 'sleep_assistant', 'conversational']",
  "action_param": "Param or dict (e.g. {{'contact': 'Mummy', 'type': 'voice'}}, {{'file': 'report', 'contact': 'Mummy'}}, 'invitation letter', app name, folder name, file name, or user goal string)",
  "terminal_command": "Optional PowerShell command",
  "voice_response": "हिंदी में विनम्र, संक्षिप्त उत्तर (2 वाक्यों के भीतर, केवल हिंदी में)"
}}

CRITICAL RULES:
1. When the user gives a multi-step task, compound command (with 'and', 'aur', 'phir', 'then'), website workflow, form filling, or cross-channel goal, use 'autonomous_goal' with the user request as action_param.
2. When the user asks to call someone or 'call them' on WhatsApp or phone, use 'whatsapp_call' with contact and call type (voice/video).
3. When the user asks to send or upload a file from File Explorer to someone (e.g. 'send file to mummy', 'mummy ko file bhejo'), use 'send_file_whatsapp' with file name and contact.
4. When the user asks to delete, clear, or erase a message, invitation letter, draft, or message box, ALWAYS use 'clear_message_box'. NEVER use 'delete_file' unless the user explicitly specifies a file on disk.
5. When the user asks to switch to, focus, or bring up an app or application (e.g. 'switch to whatsapp', 'go to chrome', 'focus notepad'), use 'focus_app'.
6. When the user says 'clear search' or 'clear the search box', use 'clear_search_box'.
7. The user's name is Rituraj. Address him respectfully as Sir Rituraj or Sir (सर).
8. REMEMBER: 'voice_response' MUST ALWAYS BE IN HINDI ONLY!
"""

    def _call_gemini(self) -> Dict[str, Any]:
        payload = {
            "systemInstruction": {"parts": [{"text": self._build_system_prompt()}]},
            "contents": self.history,
            "generationConfig": {"responseMimeType": "application/json", "temperature": 0.3}
        }
        res = requests.post(self.endpoint, json=payload, timeout=2.5)
        if res.status_code == 200:
            raw_text = res.json()['candidates'][0]['content']['parts'][0]['text']
            parsed = json.loads(raw_text)
            self.history.append({"role": "model", "parts": [{"text": raw_text}]})
            return parsed
        raise Exception(f"Gemini error {res.status_code}")

    def _call_groq_fallback(self, user_text: str) -> Dict[str, Any]:
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {"Authorization": f"Bearer {self.groq_key}", "Content-Type": "application/json"}
        model = getattr(config, "GROQ_CHAT_MODEL", "qwen/qwen3.8-27b")
        messages = [
            {"role": "system", "content": self._build_system_prompt() + "\nRespond in valid JSON object only. The voice_response MUST be in Hindi only."},
            {"role": "user", "content": user_text}
        ]
        res = requests.post(url, headers=headers, json={"model": model, "messages": messages, "response_format": {"type": "json_object"}}, timeout=4)
        if res.status_code == 200:
            parsed = json.loads(res.json()["choices"][0]["message"]["content"])
            self.history.append({"role": "model", "parts": [{"text": json.dumps(parsed)}]})
            return parsed
        raise Exception(f"Groq error {res.status_code}")

    def process_command(self, user_text: str) -> Dict[str, Any]:
        # 1. Instant local heuristics (<1ms)
        quick = self._quick_heuristic_match(user_text)
        if quick:
            return quick

        # 2. Add to context history
        self.history.append({"role": "user", "parts": [{"text": user_text}]})
        if len(self.history) > 6:
            self.history = self.history[-6:]

        # 3. Try Gemini Flash-Lite
        try:
            return self._call_gemini()
        except Exception:
            # 4. Fallback to Groq (<300ms ultra-fast cloud model)
            try:
                return self._call_groq_fallback(user_text)
            except Exception:
                return {
                    "thought": "Fallback",
                    "system_action": "conversational",
                    "action_param": None,
                    "terminal_command": None,
                    "voice_response": f"जी {config.USER_TITLE}, आपके निर्देश का पालन कर रहा हूँ।"
                }


# Global instance
brain = MJBrain()
