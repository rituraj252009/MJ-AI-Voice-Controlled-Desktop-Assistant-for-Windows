import os
import sys
import time
import subprocess
import webbrowser
import urllib.parse
import difflib
import ctypes
import pyautogui
import pyperclip

from backend.context_engine import context_engine
from backend.local_policy import local_policy
from backend.adapters.whatsapp_adapter import whatsapp_adapter
from backend.adapters.browser_adapter import browser_adapter
from backend.adapters.explorer_adapter import explorer_adapter
from backend.adapters.notepad_adapter import notepad_adapter
from backend.adapters.generic_adapter import generic_adapter

# Configure PyAutoGUI safety
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.2

class AppAutomator:
    """
    Step-by-Step Verified Application Launcher, In-App Task Controller,
    and Social Messaging Engine for Windows.
    Ensures every app command actually opens the target, with automatic
    web fallback when desktop apps are not installed.
    """
    def __init__(self):
        self.active_context = {
            "app": None,
            "file": None,
            "type": None,
            "opened_at": None
        }
        self.known_apps = [
            "spotify", "whatsapp", "second_whatsapp", "youtube", "chrome",
            "calculator", "notepad", "paint", "instagram", "telegram",
            "facebook", "discord", "vscode", "taskmgr", "settings"
        ]

        self.user32 = ctypes.windll.user32

    def get_active_window_title(self) -> str:
        """Retrieves currently focused foreground window title and syncs with context engine."""
        try:
            ctx = context_engine.refresh_active_window()
            title = ctx.get("active_window_title", "")
            app = ctx.get("active_application")
            if app:
                self.active_context["app"] = app
            return title
        except Exception:
            return ""

    def set_context(self, app_name: str, file_name: str = None, app_type: str = "general"):
        self.active_context = {
            "app": app_name.lower().strip() if app_name else None,
            "file": file_name,
            "type": app_type,
            "opened_at": time.time()
        }

    def get_context(self) -> dict:
        return self.active_context

    def _fuzzy_match_app(self, raw_name: str) -> str:
        """Cleans speech transcription typos and matches against known apps."""
        clean = raw_name.lower().strip()
        for p in ["open ", "launch ", "start ", "search ", "my ", "the ", "app "]:
            if clean.startswith(p):
                clean = clean[len(p):].strip()
        clean = clean.replace(",", "").replace(".", "").replace(";", "").strip()

        # Direct special checks
        if "second" in clean and "whatsapp" in clean:
            return "second_whatsapp"
        if "beta" in clean and "whatsapp" in clean:
            return "whatsapp_beta"
        if "whatsapp" in clean or "watsap" in clean or "watshap" in clean:
            return "whatsapp"
        if "spotify" in clean or "sotify" in clean or "spotfy" in clean or "spoti" in clean:
            return "spotify"
        if "youtube" in clean or "yt" in clean or "you tube" in clean:
            return "youtube"
        if "calc" in clean or "calculator" in clean or "calculater" in clean:
            return "calculator"
        if "notpad" in clean or "notepad" in clean or "notes" in clean:
            return "notepad"
        if "chrome" in clean or "chrom" in clean or "browser" in clean:
            return "chrome"
        if "insta" in clean or "instagram" in clean:
            return "instagram"
        if "tele" in clean or "telegram" in clean:
            return "telegram"
        if "face" in clean or "messenger" in clean:
            return "facebook"
        if clean in ["file", "files", "my files", "explorer", "file explorer", "file explore"]:
            return "explorer"

        # Fuzzy match
        matches = difflib.get_close_matches(clean, self.known_apps, n=1, cutoff=0.55)
        if matches:
            return matches[0]
        return clean

    # ==================== System Directory & Path Helpers ====================
    def _get_common_dirs(self) -> list:
        user_home = os.path.expanduser("~")
        return [
            os.path.join(user_home, "Desktop"),
            os.path.join(user_home, "Documents"),
            os.path.join(user_home, "Downloads"),
            os.path.join(user_home, "Pictures"),
            os.path.join(user_home, "Videos"),
            os.path.join(user_home, "Music"),
            user_home
        ]

    def _find_folder(self, folder_name: str) -> str | None:
        clean_name = folder_name.lower().strip()
        common_dirs = self._get_common_dirs()
        # 1. Exact match
        for d in common_dirs:
            p = os.path.join(d, clean_name)
            if os.path.isdir(p):
                return p
        # 2. Case-insensitive substring match
        for d in common_dirs:
            if not os.path.exists(d):
                continue
            try:
                for entry in os.scandir(d):
                    if entry.is_dir() and clean_name in entry.name.lower():
                        return entry.path
            except Exception:
                pass
        return None

    def _find_file(self, file_name: str) -> str | None:
        clean_name = file_name.lower().strip()
        common_dirs = self._get_common_dirs()
        # 1. Exact match
        for d in common_dirs:
            p = os.path.join(d, clean_name)
            if os.path.isfile(p):
                return p
        # 2. Case-insensitive substring match
        for d in common_dirs:
            if not os.path.exists(d):
                continue
            try:
                for entry in os.scandir(d):
                    if entry.is_file() and clean_name in entry.name.lower():
                        return entry.path
            except Exception:
                pass
        return None

    # ==================== Dedicated Folder & File Management ====================
    def open_explorer(self, target_path: str = None) -> str:
        """Opens File Explorer at a specific directory or default Quick Access."""
        self.set_context("explorer", app_type="tool")
        if target_path and os.path.exists(target_path):
            subprocess.run(["powershell", "-NoProfile", "-Command", f'Start-Process explorer.exe -ArgumentList "{target_path}"'])
            return f"Opened {os.path.basename(target_path)} in File Explorer for you, Sir."
        else:
            subprocess.run(["powershell", "-NoProfile", "-Command", "Start-Process explorer.exe"])
            return "Opened File Explorer for you, Sir."

    def open_folder(self, folder_name: str) -> str:
        """Finds and opens a specific folder in File Explorer."""
        clean = folder_name.lower().strip()
        for p in ["folder ", "the folder ", "folder named ", "folder called ", "my "]:
            if clean.startswith(p):
                clean = clean[len(p):].strip()

        user_home = os.path.expanduser("~")
        named_map = {
            "desktop": os.path.join(user_home, "Desktop"),
            "documents": os.path.join(user_home, "Documents"),
            "downloads": os.path.join(user_home, "Downloads"),
            "pictures": os.path.join(user_home, "Pictures"),
            "videos": os.path.join(user_home, "Videos"),
            "music": os.path.join(user_home, "Music"),
        }
        if clean in named_map:
            return self.open_explorer(named_map[clean])

        found = self._find_folder(clean)
        if found:
            return self.open_explorer(found)
        else:
            # Create on Desktop and open if not found
            new_dir = os.path.join(user_home, "Desktop", clean.title())
            os.makedirs(new_dir, exist_ok=True)
            return self.open_explorer(new_dir)

    def create_folder(self, folder_name: str) -> str:
        """Creates a folder on the desktop and opens it immediately in File Explorer."""
        clean = folder_name.strip()
        for p in ["folder ", "a folder ", "a new folder ", "new folder ", "called ", "named "]:
            if clean.lower().startswith(p):
                clean = clean[len(p):].strip()
        if not clean:
            clean = "New Folder"
        user_home = os.path.expanduser("~")
        new_dir = os.path.join(user_home, "Desktop", clean)
        os.makedirs(new_dir, exist_ok=True)
        self.open_explorer(new_dir)
        return f"Created folder '{clean}' on your desktop and opened it, Sir."

    def delete_folder(self, folder_name: str) -> str:
        """Finds and permanently deletes a folder."""
        clean = folder_name.strip()
        for p in ["folder ", "the folder ", "called ", "named "]:
            if clean.lower().startswith(p):
                clean = clean[len(p):].strip()
        found = self._find_folder(clean)
        if found:
            try:
                import shutil
                shutil.rmtree(found)
                return f"Deleted folder '{os.path.basename(found)}', Sir."
            except Exception:
                subprocess.run(["powershell", "-NoProfile", "-Command", f'Remove-Item -Path "{found}" -Recurse -Force'])
                return f"Deleted folder '{clean}', Sir."
        return f"Could not find folder '{clean}' to delete, Sir."

    def rename_folder(self, old_name: str, new_name: str) -> str:
        """Renames a folder."""
        clean_old = old_name.strip()
        clean_new = new_name.strip()
        found = self._find_folder(clean_old)
        if found:
            parent = os.path.dirname(found)
            target = os.path.join(parent, clean_new)
            try:
                os.rename(found, target)
                return f"Renamed folder '{os.path.basename(found)}' to '{clean_new}', Sir."
            except Exception:
                subprocess.run(["powershell", "-NoProfile", "-Command", f'Rename-Item -Path "{found}" -NewName "{clean_new}" -Force'])
                return f"Renamed folder '{clean_old}' to '{clean_new}', Sir."
        return f"Could not find folder '{clean_old}' to rename, Sir."

    def create_file(self, file_name: str) -> str:
        """Creates a new file on the desktop and opens it in Notepad."""
        clean = file_name.strip()
        for p in ["file ", "a file ", "a new file ", "new file ", "called ", "named "]:
            if clean.lower().startswith(p):
                clean = clean[len(p):].strip()
        if not clean:
            clean = "New Document.txt"
        elif "." not in clean:
            clean += ".txt"
        user_home = os.path.expanduser("~")
        new_file = os.path.join(user_home, "Desktop", clean)
        if not os.path.exists(new_file):
            with open(new_file, "w", encoding="utf-8") as f:
                f.write("")
        self.set_context("notepad", file_name=clean, app_type="editor")
        subprocess.run(["powershell", "-NoProfile", "-Command", f'Start-Process notepad.exe -ArgumentList "{new_file}"'])
        return f"Created file '{clean}' on your desktop and opened it in Notepad, Sir."

    def open_file(self, file_name: str) -> str:
        """Opens a file with its default program or opens File Explorer."""
        clean = file_name.strip()
        for p in ["file ", "the file ", "called ", "named ", "my "]:
            if clean.lower().startswith(p):
                clean = clean[len(p):].strip()
        found = self._find_file(clean)
        if found:
            self.set_context(os.path.splitext(found)[1].replace(".", "") or "file", file_name=os.path.basename(found), app_type="file")
            subprocess.run(["powershell", "-NoProfile", "-Command", f'Invoke-Item "{found}"'])
            return f"Opened file '{os.path.basename(found)}' for you, Sir."
        # If specific file not found, open File Explorer rather than web search!
        return self.open_explorer()

    def delete_file(self, file_name: str) -> str:
        """Finds and deletes a file."""
        clean = file_name.strip()
        for p in ["file ", "the file ", "called ", "named "]:
            if clean.lower().startswith(p):
                clean = clean[len(p):].strip()
        found = self._find_file(clean)
        if found:
            try:
                os.remove(found)
                return f"Deleted file '{os.path.basename(found)}', Sir."
            except Exception:
                subprocess.run(["powershell", "-NoProfile", "-Command", f'Remove-Item -Path "{found}" -Force'])
                return f"Deleted file '{clean}', Sir."
        return f"Could not find file '{clean}' to delete, Sir."

    def rename_file(self, old_name: str, new_name: str) -> str:
        """Renames a file."""
        clean_old = old_name.strip()
        clean_new = new_name.strip()
        found = self._find_file(clean_old)
        if found:
            parent = os.path.dirname(found)
            if "." not in clean_new and "." in found:
                clean_new += os.path.splitext(found)[1]
            target = os.path.join(parent, clean_new)
            try:
                os.rename(found, target)
                return f"Renamed file '{os.path.basename(found)}' to '{clean_new}', Sir."
            except Exception:
                subprocess.run(["powershell", "-NoProfile", "-Command", f'Rename-Item -Path "{found}" -NewName "{clean_new}" -Force'])
                return f"Renamed file '{clean_old}' to '{clean_new}', Sir."
        return f"Could not find file '{clean_old}' to rename, Sir."

    def share_item(self, item_name: str) -> str:
        """Selects and reveals a file or folder in File Explorer for sharing."""
        clean = item_name.strip()
        for p in ["folder ", "file ", "the folder ", "the file ", "item "]:
            if clean.lower().startswith(p):
                clean = clean[len(p):].strip()
        found = self._find_folder(clean) or self._find_file(clean)
        if found:
            subprocess.run(["powershell", "-NoProfile", "-Command", f'explorer.exe /select,"{found}"'])
            return f"Selected '{os.path.basename(found)}' in File Explorer ready to share, Sir."
        return self.open_explorer()

    # ==================== Step-by-Step Verified App & File Launcher ====================
    def open_any(self, target_name: str) -> str:
        """
        Step-by-step verified execution:
        1. Fuzzy-matches typo in name (e.g. 'sotify' -> 'spotify').
        2. Attempts native Windows launch / URI.
        3. Verifies if app is installed; if not, opens web version automatically.
        4. Saves active context.
        """
        target = self._fuzzy_match_app(target_name)

        # ----------------- File / Files / Explorer -----------------
        if target in ["file", "files", "explorer", "file explorer"]:
            return self.open_explorer()

        # ----------------- Step 1: WhatsApp (Stable Desktop Priority) -----------------
        elif target == "whatsapp":
            self.set_context("whatsapp", app_type="chat")
            res = whatsapp_adapter.activate(prefer_beta=False)
            return "Opening WhatsApp Desktop for you, Sir." if res else "Could not open WhatsApp Desktop, Sir."

        elif target == "whatsapp_beta":
            self.set_context("whatsapp", app_type="chat")
            res = whatsapp_adapter.activate(prefer_beta=True)
            return "Opening WhatsApp Beta for you, Sir." if res else "Could not open WhatsApp Beta, Sir."

        elif target == "second_whatsapp":
            self.set_context("whatsapp", app_type="chat")
            webbrowser.open("https://web.whatsapp.com")
            return "Opening your second WhatsApp on the web, Sir."

        # ----------------- Step 2: YouTube (Tab Reuse Priority) -----------------
        elif target == "youtube":
            self.set_context("youtube", app_type="browser")
            res = browser_adapter.open_youtube()
            return res.get("result", "Opened YouTube for you, Sir.")

        # ----------------- Step 3: Notepad -----------------
        elif target in ["notepad", "notpad", "notes"]:
            self.set_context("notepad", app_type="editor")
            res = notepad_adapter.activate()
            return "Opened Notepad for you, Sir." if res else "Could not open Notepad, Sir."

        # ----------------- Step 4: Spotify -----------------
        elif target == "spotify":
            self.set_context("spotify", app_type="media")
            res = generic_adapter.open_app("spotify")
            if res.get("success"):
                return "Opened Spotify for you, Sir."
            return "Could not find Spotify locally, Sir."

        # ----------------- Step 5: Social Platforms -----------------
        elif target == "instagram":
            self.set_context("instagram", app_type="chat")
            webbrowser.open("https://www.instagram.com/direct/inbox/")
            return "Opened Instagram Direct Messages for you, Sir."

        elif target == "telegram":
            self.set_context("telegram", app_type="chat")
            res = generic_adapter.open_app("telegram")
            if res.get("success"):
                return "Opened Telegram for you, Sir."
            webbrowser.open("https://web.telegram.org")
            return "Opening Telegram Web for you, Sir."

        elif target == "facebook":
            self.set_context("facebook", app_type="chat")
            webbrowser.open("https://www.messenger.com/")
            return "Opening Facebook Messenger for you, Sir."

        # ----------------- Step 6: Built-in & Local Applications -----------------
        gen_res = generic_adapter.open_app(target)
        if gen_res.get("success"):
            self.set_context(target, app_type="app")
            return gen_res.get("result", f"Opened {target.title()} for you, Sir.")

        # ----------------- Step 7: Search Local User Files / Folders -----------------
        fol_res = explorer_adapter.open_folder(target)
        if fol_res.get("success"):
            return fol_res.get("result", f"Opened folder '{target}' for you, Sir.")

        fl_res = explorer_adapter.open_file(target)
        if fl_res.get("success"):
            return fl_res.get("result", f"Opened file '{target}' for you, Sir.")

        # ----------------- Step 8: Strict Local-First Policy (NO GOOGLE SEARCH FALLBACK!) -----------------
        missing_res = local_policy.handle_missing_local_target(target, target_type="application")
        return missing_res.get("voice_response", f"I could not find '{target}' locally on your laptop, Sir.")

    # ==================== Contextual Task Execution ====================
    def execute_context_task(self, task_action: str, payload: str = "") -> str:
        """
        Performs a requested task inside the currently active application or tab.
        Routes to application-specific adapters (WhatsApp, YouTube/Browser, Notepad, Generic).
        """
        ctx = context_engine.get_active_context()
        app = ctx.get("active_application") or self.active_context.get("app") or ""
        app_type = ctx.get("type") or "general"

        # 1. WhatsApp in-app operations
        if "whatsapp" in app.lower():
            if task_action in ["search_inside", "search_contact", "browser_search"]:
                res = whatsapp_adapter.search_contact(payload)
                return res.get("result", f"Searched for '{payload}' in WhatsApp, Sir.")
            elif task_action in ["write_text", "type_text", "insert_content"]:
                res = whatsapp_adapter.type_message(payload, send_now=False)
                return res.get("result", "Typed into WhatsApp chat, Sir.")
            elif task_action in ["send_it", "send"]:
                res = whatsapp_adapter.send_current_message()
                return res.get("result", "Message sent on WhatsApp, Sir.")

        # 2. YouTube / Browser in-page operations
        elif "youtube" in app.lower():
            if task_action in ["search_inside", "browser_search"]:
                res = browser_adapter.search_youtube(payload)
                return res.get("result", f"Searching YouTube for '{payload}', Sir.")
            elif task_action in ["play", "pause", "play_pause"]:
                res = browser_adapter.play_pause()
                return res.get("result", "Toggled video playback, Sir.")
            elif task_action in ["open_first", "first_result"]:
                res = browser_adapter.open_first_video()
                return res.get("result", "Opened the first video, Sir.")

        # 3. Notepad in-app operations
        elif "notepad" in app.lower():
            if task_action in ["write_text", "type_text", "insert_content"]:
                res = notepad_adapter.write_text(payload)
                return res.get("result", "Written into Notepad document, Sir.")
            elif task_action in ["save_file", "save_document"]:
                res = notepad_adapter.save_file(payload if payload else None)
                return res.get("result", "Saved document, Sir.")

        # 4. Generic in-app operations
        if task_action in ["write_text", "type_text", "insert_content"]:
            res = generic_adapter.execute_in_active_window("write_text", payload)
            return res.get("result", f"Written into {app or 'active window'}, Sir.")

        elif task_action in ["search_inside", "browser_search"]:
            res = generic_adapter.execute_in_active_window("search_inside", payload)
            return res.get("result", f"Searching for '{payload}' in {app or 'window'}, Sir.")

        elif task_action in ["clear_search", "clear_search_box"]:
            return self.clear_search_box()

        elif task_action in ["save_file", "save_document"]:
            res = generic_adapter.execute_in_active_window("save", payload)
            return res.get("result", "Saved active document, Sir.")

        elif task_action in ["close_context", "close_tab"]:
            if app_type == "browser" or "chrome" in app.lower() or "edge" in app.lower():
                browser_adapter.execute_action("close_tab")
                return "Closed active tab, Sir."
            else:
                generic_adapter.execute_in_active_window("close")
                self.active_context = {"app": None, "file": None, "type": None, "opened_at": None}
                return f"Closed {app or 'application'}, Sir."

        elif task_action in ["clear_content", "select_all"]:
            pyautogui.hotkey('ctrl', 'a')
            if task_action == "clear_content":
                pyautogui.press('backspace')
                return "Cleared content, Sir."
            return "Selected all, Sir."

        return self.type_in_active_window(payload, press_enter=True)

    # ==================== Social Media & Messaging ====================
    def open_social(self, platform: str) -> str:
        return self.open_any(platform)

    def focus_app(self, app_name: str) -> str:
        """Brings target application to the foreground using Windows Shell."""
        clean = self._fuzzy_match_app(app_name)
        self.set_context(clean)
        ps_cmd = f"""
        $ws = New-Object -ComObject WScript.Shell
        $activated = $ws.AppActivate('{clean}')
        if (-not $activated) {{
            $activated = $ws.AppActivate('{app_name}')
        }}
        if ($activated) {{ 'OK' }} else {{ 'FAIL' }}
        """
        res = subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], capture_output=True, text=True)
        if "OK" in res.stdout:
            return f"Switched to {clean.title()} for you, Sir."
        # If not currently running/active, launch it
        return self.open_any(clean)

    def clear_message_box(self, item_name: str = "") -> str:
        """
        Instantly clears any message, invitation letter, or draft in the active message input box.
        Executes Ctrl+A + Backspace in the active window.
        """
        time.sleep(0.1)
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.08)
        pyautogui.press('backspace')
        time.sleep(0.05)

        clean_item = item_name.lower().strip() if item_name else ""
        if "invitation" in clean_item or "letter" in clean_item:
            return "Deleted the invitation letter from the message box for you, Sir."
        elif "message" in clean_item or "chat" in clean_item:
            return "Cleared the message from the message box, Sir."
        elif clean_item:
            return f"Cleared {clean_item} from the message box, Sir."
        return "Cleared the message box for you, Sir."

    def clear_search_box(self) -> str:
        """
        Clears any previous search text in the active application's search bar.
        """
        time.sleep(0.1)
        pyautogui.hotkey('ctrl', 'f')
        time.sleep(0.15)
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.05)
        pyautogui.press('backspace')
        time.sleep(0.1)
        pyautogui.press('esc')
        return "Cleared the search box for you, Sir."

    def delete_message(self, target: str = "") -> str:
        """Handles deleting message / invitation letter from chat or message box."""
        return self.clear_message_box(item_name=target)

    def whatsapp_call(self, contact: str = "", call_type: str = "voice", platform: str = "whatsapp") -> str:
        """Initiates a voice or video call on WhatsApp Desktop via WhatsAppAdapter."""
        if platform.lower() == "instagram":
            self.open_any("instagram")
            return "Opened Instagram for you to call, Sir."

        res = whatsapp_adapter.start_call(contact_name=contact if contact else None, call_type=call_type)
        return res.get("result", f"Calling {contact or 'them'} on WhatsApp for you, Sir.")

    def send_file_whatsapp(self, contact_name: str, file_query: str) -> str:
        """Finds a file on the computer and sends it to a contact in WhatsApp."""
        res = whatsapp_adapter.send_file(contact_name, file_query)
        return res.get("result", f"Sent file to {contact_name or 'them'} on WhatsApp.")

    def in_app_undo(self) -> str:
        pyautogui.hotkey('ctrl', 'z')
        return "Undone, Sir."

    def in_app_redo(self) -> str:
        pyautogui.hotkey('ctrl', 'y')
        return "Redone, Sir."

    def in_app_select_all(self) -> str:
        pyautogui.hotkey('ctrl', 'a')
        return "Selected all text, Sir."

    def in_app_copy(self) -> str:
        pyautogui.hotkey('ctrl', 'c')
        return "Copied to clipboard, Sir."

    def in_app_paste(self) -> str:
        pyautogui.hotkey('ctrl', 'v')
        return "Pasted, Sir."

    def in_app_cut(self) -> str:
        pyautogui.hotkey('ctrl', 'x')
        return "Cut to clipboard, Sir."

    def in_app_window_control(self, action: str) -> str:
        act = action.lower().strip()
        if act == "maximize":
            pyautogui.hotkey('win', 'up')
            return "Maximized window, Sir."
        elif act in ["minimize", "minimise"]:
            pyautogui.hotkey('win', 'down')
            return "Minimized window, Sir."
        elif act in ["close_tab", "close tab"]:
            pyautogui.hotkey('ctrl', 'w')
            return "Closed tab, Sir."
        elif act in ["new_tab", "new tab"]:
            pyautogui.hotkey('ctrl', 't')
            return "Opened new tab, Sir."
        elif act in ["switch_tab", "next tab"]:
            pyautogui.hotkey('ctrl', 'tab')
            return "Switched tab, Sir."
        elif act in ["refresh", "reload"]:
            pyautogui.press('f5')
            return "Refreshed, Sir."
        elif act in ["fullscreen", "full screen"]:
            pyautogui.press('f11')
            return "Toggled fullscreen, Sir."
        elif act in ["escape", "cancel"]:
            pyautogui.press('esc')
            return "Cancelled, Sir."
        elif act in ["enter", "submit", "send"]:
            pyautogui.press('enter')
            return "Sent, Sir."
        return f"Executed {action}, Sir."

    def send_whatsapp_message(self, contact_name: str, message: str) -> str:
        """Automates WhatsApp messaging via WhatsAppAdapter with instant responsiveness."""
        res = whatsapp_adapter.execute_action("send", {"contact": contact_name, "message": message})
        return res.get("result", f"Message sent to {contact_name} on WhatsApp, Sir.")

    def type_in_active_window(self, text: str, press_enter: bool = True) -> str:
        pyperclip.copy(text)
        time.sleep(0.15)
        pyautogui.hotkey('ctrl', 'v')
        if press_enter:
            time.sleep(0.2)
            pyautogui.press('enter')
        return "Message typed and sent, Sir."

    def press_key(self, key_name: str) -> str:
        pyautogui.press(key_name.lower().strip())
        return f"Pressed {key_name}, Sir."

    def execute_hotkey(self, keys_str: str) -> str:
        keys = [k.strip().lower() for k in keys_str.split("+")]
        pyautogui.hotkey(*keys)
        return f"Executed shortcut {keys_str}, Sir."

    def scroll(self, direction: str = "down", amount: int = 500) -> str:
        scroll_val = -abs(amount) if direction.lower() == "down" else abs(amount)
        pyautogui.scroll(scroll_val)
        return f"Scrolled {direction}, Sir."


# Global instance
automator = AppAutomator()
