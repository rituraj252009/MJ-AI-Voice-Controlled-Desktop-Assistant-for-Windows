import os
import sys
import time
import asyncio
import tempfile
import ctypes
import threading
import edge_tts
import config

class SpeechEngine:
    """
    High-fidelity Neural Text-to-Speech engine for MJ with instant barge-in
    cancellation and watchdog anti-hang protections.
    """
    def __init__(self, voice: str = config.TTS_VOICE):
        self.voice = voice
        self.mci = ctypes.windll.winmm.mciSendStringW
        self._lock = threading.Lock()
        self._is_speaking = False
        self._stop_requested = False
        self._current_alias = None

    def stop(self):
        """
        Immediately stops any ongoing audio playback in 0ms.
        Used for voice barge-in when the user interrupts MJ.
        """
        self._stop_requested = True
        self._is_speaking = False
        try:
            if self._current_alias:
                self.mci(f"stop {self._current_alias}", None, 0, None)
                self.mci(f"close {self._current_alias}", None, 0, None)
            self.mci("stop all", None, 0, None)
            self.mci("close all", None, 0, None)
        except Exception:
            pass

    def _play_audio_file(self, file_path: str):
        """
        Plays audio file via Windows MCI in a poll loop with an anti-hang watchdog timer.
        """
        alias = f"mj_voice_{int(time.time() * 1000)}"
        self._current_alias = alias
        safe_path = os.path.abspath(file_path).replace("\\", "/")

        # Estimate max playtime to prevent indefinite polling
        try:
            file_bytes = os.path.getsize(file_path)
            max_play_time = max(2.0, (file_bytes / 12000.0) + 1.5)
        except Exception:
            max_play_time = 10.0

        start_time = time.time()
        try:
            self.mci("close all", None, 0, None)
            open_cmd = f'open "{safe_path}" type mpegvideo alias {alias}'
            res = self.mci(open_cmd, None, 0, None)
            if res != 0:
                self.mci(f'open "{safe_path}" alias {alias}', None, 0, None)

            if self._stop_requested:
                return

            self.mci(f"play {alias}", None, 0, None)

            # Poll status in 35ms intervals with strict watchdog limit
            status_buf = ctypes.create_unicode_buffer(128)
            while not self._stop_requested:
                # Watchdog timeout check
                if (time.time() - start_time) > max_play_time:
                    break

                self.mci(f"status {alias} mode", status_buf, 128, None)
                mode = status_buf.value.strip()
                if mode in ["stopped", ""]:
                    break
                time.sleep(0.035)

        finally:
            try:
                self.mci(f"stop {alias}", None, 0, None)
                self.mci(f"close {alias}", None, 0, None)
            except Exception:
                pass
            if self._current_alias == alias:
                self._current_alias = None

    async def _async_generate_edge_tts(self, text: str, output_path: str):
        communicate = edge_tts.Communicate(text, self.voice)
        await asyncio.wait_for(communicate.save(output_path), timeout=4.5)

    def _speak_pyttsx3_fallback(self, text: str):
        """Fallback local TTS engine if network is unavailable."""
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty("rate", 185)
            voices = engine.getProperty("voices")
            for v in voices:
                if any(name in v.name.lower() for name in ["david", "male", "mark", "george", "ravi"]):
                    engine.setProperty("voice", v.id)
                    break
            engine.say(text)
            engine.runAndWait()
        except Exception:
            pass

    def speak(self, text: str, blocking: bool = True):
        """
        Speak text with neural audio. Stops immediately if stop() is called.
        """
        if not text or not text.strip():
            return

        def _run():
            # Try to acquire lock with 1.0s timeout to prevent thread pile-up
            acquired = self._lock.acquire(timeout=1.0)
            if not acquired:
                return

            self._stop_requested = False
            self._is_speaking = True
            temp_file = None
            try:
                fd, temp_file = tempfile.mkstemp(suffix=".mp3")
                os.close(fd)
                try:
                    asyncio.run(self._async_generate_edge_tts(text, temp_file))
                except Exception:
                    # If Edge-TTS times out or fails, use local pyttsx3 immediately
                    if not self._stop_requested:
                        self._speak_pyttsx3_fallback(text)
                    return

                if not self._stop_requested:
                    self._play_audio_file(temp_file)
            finally:
                if temp_file and os.path.exists(temp_file):
                    try:
                        os.remove(temp_file)
                    except Exception:
                        pass
                self._is_speaking = False
                self._lock.release()

        if blocking:
            _run()
        else:
            t = threading.Thread(target=_run, daemon=True)
            t.start()

    @property
    def is_speaking(self) -> bool:
        return self._is_speaking

    def get_status(self) -> dict:
        return {
            "voice": self.voice,
            "is_speaking": self._is_speaking,
            "engine": "edge-tts (Neural)"
        }


# Global singleton instance
engine = SpeechEngine()

def speak(text: str, blocking: bool = True):
    engine.speak(text, blocking=blocking)

def stop_speaking():
    engine.stop()

