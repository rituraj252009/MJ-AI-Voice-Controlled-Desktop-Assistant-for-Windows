import io
import time
import base64
import requests
from requests.adapters import HTTPAdapter
from typing import Optional

import config
from voice.audio import AudioProcessor


class SpeechToTextService:
    """
    Sub-300ms Streaming Speech-to-Text using Groq Whisper Large V3 Turbo
    with Gemini Audio fallback.
    """
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or config.GROQ_API_KEY
        self.groq_url = "https://api.groq.com/openai/v1/audio/transcriptions"
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=5, pool_maxsize=10, max_retries=1)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

    def transcribe_pcm(self, pcm_bytes: bytes, sample_rate: int = 16000) -> str:
        """Converts raw linear PCM bytes to transcribed text."""
        if not pcm_bytes or len(pcm_bytes) < 3200:  # Ignore under 0.1s audio
            return ""

        wav_bytes = AudioProcessor.create_wav_header(pcm_bytes, sample_rate=sample_rate)
        return self.transcribe_wav(wav_bytes)

    def transcribe_wav(self, wav_bytes: bytes) -> str:
        if not wav_bytes:
            return ""

        headers = {"Authorization": f"Bearer {self.api_key}"}
        files = {"file": ("audio.wav", io.BytesIO(wav_bytes), "audio/wav")}
        data = {
            "model": getattr(config, "GROQ_WHISPER_MODEL", "whisper-large-v3-turbo"),
            "response_format": "json",
            "temperature": 0.0,
            "prompt": "MJ, Sir, Rituraj, meeting, WhatsApp, Chrome, call, Rahul"
        }

        try:
            res = self.session.post(self.groq_url, headers=headers, files=files, data=data, timeout=3.5)
            if res.status_code == 200:
                text = res.json().get("text", "").strip()
                if text:
                    return text
        except Exception:
            pass

        # Fallback to Gemini
        return self._gemini_fallback(wav_bytes)

    def _gemini_fallback(self, wav_bytes: bytes) -> str:
        try:
            b64 = base64.b64encode(wav_bytes).decode('utf-8')
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{config.FAST_GEMINI_MODEL}:generateContent?key={config.GEMINI_API_KEY}"
            payload = {
                "contents": [{
                    "parts": [
                        {"inlineData": {"mimeType": "audio/wav", "data": b64}},
                        {"text": "Transcribe the spoken audio verbatim. Output only the words spoken. If noise or silence, return empty."}
                    ]
                }]
            }
            res = self.session.post(url, json=payload, timeout=4.0)
            if res.status_code == 200:
                return res.json()['candidates'][0]['content']['parts'][0]['text'].strip()
        except Exception:
            pass
        return ""


# Global singleton instance
stt_service = SpeechToTextService()
