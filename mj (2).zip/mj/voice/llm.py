import json
import logging
import requests
from typing import Dict, Any, List, Optional

import config
from backend.memory.conversations import conversation_manager

logger = logging.getLogger("MJ_VoiceLLM")


class RealtimeVoiceLLM:
    """
    Sub-400ms conversational LLM engine for live phone and voice sessions.
    Maintains conversational state and triggers tools only when external data is needed.
    """
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or config.GEMINI_API_KEY
        self.fast_model = getattr(config, "FAST_GEMINI_MODEL", "gemini-3.5-flash-lite")
        self.groq_key = config.GROQ_API_KEY

    def _build_system_prompt(self, caller_name: str, caller_phone: str, context_notes: str) -> str:
        return f"""You are {config.ASSISTANT_NAME}, an autonomous AI representative speaking on a live phone call on behalf of {config.USER_TITLE}.
CALLER: {caller_name} ({caller_phone})
KNOWN CONTEXT: {context_notes}

CONVERSATIONAL RULES:
1. Speak naturally, concisely, and warmly. Keep responses under 2 sentences unless explaining something complex.
2. Always speak and respond strictly in fluent, polite Hindi (केवल हिंदी भाषा में ही बात करें और उत्तर दें).
3. If the caller asks for Sir Rituraj, politely inform them that Sir is currently occupied, take down their message or confirm their meeting time.
4. If the caller asks for information you have in context (e.g. meeting times), answer directly.
5. NEVER mention internal technical terms like "n8n", "JSON", "FastAPI", "Prompt". Speak as a real professional human assistant.
6. When the call is concluding, say goodbye politely and add '[CALL_END]' at the very end of your response.
"""

    def generate_reply(
        self,
        caller_name: str,
        caller_phone: str,
        dialogue_history: List[Dict[str, str]],
        latest_user_text: str
    ) -> Dict[str, Any]:
        """Generates conversational response for live telephony session."""
        ctx = conversation_manager.get_cross_channel_context(caller_name)
        notes = f"Relationship/Notes: {ctx.get('contact', {}).get('notes', '')}\nLast Call: {ctx.get('latest_call_summary', {}).get('summary', 'None')}"

        sys_prompt = self._build_system_prompt(caller_name, caller_phone, notes)

        # 1. Try Gemini Flash-Lite
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.fast_model}:generateContent?key={self.api_key}"
            contents = []
            for d in dialogue_history[-6:]:
                role = "user" if d["role"] == "caller" else "model"
                contents.append({"role": role, "parts": [{"text": d["text"]}]})
            contents.append({"role": "user", "parts": [{"text": latest_user_text}]})

            payload = {
                "systemInstruction": {"parts": [{"text": sys_prompt}]},
                "contents": contents,
                "generationConfig": {"temperature": 0.4, "maxOutputTokens": 150}
            }
            res = requests.post(url, json=payload, timeout=3.0)
            if res.status_code == 200:
                raw_text = res.json()['candidates'][0]['content']['parts'][0]['text'].strip()
                should_end = "[CALL_END]" in raw_text
                clean_text = raw_text.replace("[CALL_END]", "").strip()
                return {"text": clean_text, "end_call": should_end}
        except Exception as e:
            logger.warning(f"Gemini voice call failed ({e}), falling back to Groq")

        # 2. Fallback to Groq
        try:
            url = "https://api.groq.com/openai/v1/chat/completions"
            headers = {"Authorization": f"Bearer {self.groq_key}", "Content-Type": "application/json"}
            messages = [{"role": "system", "content": sys_prompt}]
            for d in dialogue_history[-4:]:
                r = "user" if d["role"] == "caller" else "assistant"
                messages.append({"role": r, "content": d["text"]})
            messages.append({"role": "user", "content": latest_user_text})

            res = requests.post(url, headers=headers, json={"model": "groq/compound-mini", "messages": messages, "max_tokens": 120}, timeout=3.0)
            if res.status_code == 200:
                reply = res.json()["choices"][0]["message"]["content"].strip()
                should_end = "[CALL_END]" in reply
                clean = reply.replace("[CALL_END]", "").strip()
                return {"text": clean, "end_call": should_end}
        except Exception as e:
            logger.error(f"Groq voice fallback failed: {e}")

        return {
            "text": "जी बिल्कुल, मैंने नोट कर लिया है। मैं सर को सूचित कर दूँगा।",
            "end_call": False
        }


# Global singleton instance
voice_llm = RealtimeVoiceLLM()
