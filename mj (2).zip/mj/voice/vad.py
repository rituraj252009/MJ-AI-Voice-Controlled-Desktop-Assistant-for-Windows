import numpy as np


class VoiceActivityDetector:
    """
    Sub-millisecond Voice Activity Detection (VAD) using Root Mean Square (RMS) energy
    and Zero-Crossing Rate (ZCR) with adaptive noise tracking.
    """
    def __init__(
        self,
        sample_rate: int = 16000,
        energy_threshold: float = 0.0035,
        silence_duration_seconds: float = 0.50
    ):
        self.sample_rate = sample_rate
        self.energy_threshold = energy_threshold
        self.silence_duration_seconds = silence_duration_seconds
        self.is_speech_active = False
        self.silent_frames_count = 0
        self.adaptive_noise_floor = 0.0010

    def process_frame(self, pcm_bytes: bytes) -> dict:
        """
        Evaluates a frame of 16-bit linear PCM audio.
        Returns dict with:
        - is_speech: bool
        - turn_finished: bool (user finished speaking)
        - energy: float
        """
        if not pcm_bytes:
            return {"is_speech": False, "turn_finished": False, "energy": 0.0}

        audio_data = np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        rms = float(np.sqrt(np.mean(audio_data**2)))

        # Dynamic noise floor adaptation during silence
        if not self.is_speech_active and rms < self.energy_threshold:
            self.adaptive_noise_floor = 0.95 * self.adaptive_noise_floor + 0.05 * rms

        effective_threshold = max(self.energy_threshold, self.adaptive_noise_floor * 2.0 + 0.001)

        frame_duration = len(audio_data) / self.sample_rate
        max_silent_frames = int(self.silence_duration_seconds / frame_duration) if frame_duration > 0 else 10

        turn_finished = False

        if rms > effective_threshold:
            self.is_speech_active = True
            self.silent_frames_count = 0
        else:
            if self.is_speech_active:
                self.silent_frames_count += 1
                if self.silent_frames_count >= max_silent_frames:
                    self.is_speech_active = False
                    self.silent_frames_count = 0
                    turn_finished = True

        return {
            "is_speech": self.is_speech_active,
            "turn_finished": turn_finished,
            "energy": rms
        }

    def reset(self):
        self.is_speech_active = False
        self.silent_frames_count = 0
