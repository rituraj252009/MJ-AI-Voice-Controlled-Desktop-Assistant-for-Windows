import time
import numpy as np
from typing import Callable, Optional


class BargeInDetector:
    """
    Sub-10ms Acoustic Interruption (Barge-In) Monitor.
    Detects when user begins speaking while MJ is delivering TTS audio,
    immediately cutting off output playback.
    """
    def __init__(self, energy_threshold: float = 0.035, consecutive_spikes_required: int = 2):
        self.energy_threshold = energy_threshold
        self.consecutive_spikes_required = consecutive_spikes_required
        self.spike_count = 0

    def check_for_interruption(self, pcm_bytes: bytes, on_interrupt_callback: Optional[Callable[[], None]] = None) -> bool:
        """
        Analyzes incoming audio chunk while assistant is speaking.
        Returns True if barge-in detected.
        """
        if not pcm_bytes:
            return False

        audio_data = np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32) / 32768.0
        rms = float(np.sqrt(np.mean(audio_data**2)))

        if rms > self.energy_threshold:
            self.spike_count += 1
            if self.spike_count >= self.consecutive_spikes_required:
                self.spike_count = 0
                if on_interrupt_callback:
                    try:
                        on_interrupt_callback()
                    except Exception:
                        pass
                return True
        else:
            self.spike_count = 0

        return False

    def reset(self):
        self.spike_count = 0
