import os
import sys
import json
import asyncio
import logging
from aiohttp import web

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from voice.audio import AudioProcessor
from voice.vad import VoiceActivityDetector
from voice.interruption import BargeInDetector
from voice.stt import stt_service
from voice.llm import voice_llm
from voice.tts import tts_service
from voice.session_manager import session_manager

logger = logging.getLogger("MJ_VoiceServer")
logging.basicConfig(level=logging.INFO, format="[%(asctime)s] [%(levelname)s] %(message)s")


async def handle_voice_websocket(request):
    """
    High-Performance Realtime Bidirectional Voice WebSocket.
    Processes telephony/browser audio frames with VAD, barge-in,
    streaming STT, LLM reasoning, and low-latency audio response.
    """
    ws = web.WebSocketResponse()
    await ws.prepare(request)

    session_id = f"call_{int(asyncio.get_event_loop().time() * 1000)}"
    vad = VoiceActivityDetector(sample_rate=16000)
    barge_in = BargeInDetector()
    session = None
    accumulated_pcm = bytearray()

    logger.info(f"New Realtime Voice Connection opened: {session_id}")

    try:
        async for msg in ws:
            if msg.type == web.WSMsgType.TEXT:
                # Handle control events (e.g. Twilio/Exotel start/media/stop)
                try:
                    payload = json.loads(msg.data)
                    event_type = payload.get("event") or payload.get("action")

                    if event_type == "start":
                        phone = payload.get("from") or payload.get("caller") or "+919999999999"
                        session = session_manager.create_session(session_id, phone=phone)
                        logger.info(f"Session started for {session.caller_name} ({phone})")
                        # Greet caller
                        greeting = f"Namaste, I am MJ, AI assistant to Sir Rituraj. How may I help you today?"
                        await ws.send_str(json.dumps({"event": "text", "text": greeting}))

                    elif event_type == "media":
                        # Telephony media packet (base64 encoded audio)
                        media_b64 = payload.get("media", {}).get("payload", "")
                        if media_b64:
                            import base64
                            raw_bytes = base64.b64decode(media_b64)
                            pcm_16k = AudioProcessor.mulaw_to_pcm16(raw_bytes)

                            # 1. Check Barge-In if assistant is currently speaking
                            if session and session.is_speaking:
                                if barge_in.check_for_interruption(pcm_16k):
                                    logger.info("Barge-in detected! Halting assistant audio.")
                                    tts_service.stop()
                                    session.is_speaking = False
                                    await ws.send_str(json.dumps({"event": "clear_audio"}))

                            # 2. VAD turn detection
                            vad_res = vad.process_frame(pcm_16k)
                            if vad_res["is_speech"]:
                                accumulated_pcm.extend(pcm_16k)

                            if vad_res["turn_finished"] and len(accumulated_pcm) > 0:
                                # User finished speaking
                                user_audio = bytes(accumulated_pcm)
                                accumulated_pcm.clear()

                                transcribed_text = stt_service.transcribe_pcm(user_audio)
                                if transcribed_text:
                                    logger.info(f"Caller [{session.caller_name if session else 'User'}]: '{transcribed_text}'")
                                    if session:
                                        session.add_turn("caller", transcribed_text)

                                    # Generate LLM reply
                                    reply_obj = voice_llm.generate_reply(
                                        caller_name=session.caller_name if session else "Caller",
                                        caller_phone=session.caller_phone if session else "",
                                        dialogue_history=session.dialogue_history if session else [],
                                        latest_user_text=transcribed_text
                                    )

                                    reply_text = reply_obj["text"]
                                    logger.info(f"MJ Reply: '{reply_text}'")
                                    if session:
                                        session.add_turn("assistant", reply_text)
                                        session.is_speaking = True

                                    await ws.send_str(json.dumps({
                                        "event": "reply",
                                        "text": reply_text,
                                        "end_call": reply_obj.get("end_call", False)
                                    }))

                                    if reply_obj.get("end_call"):
                                        await asyncio.sleep(2.0)
                                        break

                    elif event_type == "stop":
                        break

                except Exception as e:
                    logger.error(f"Error processing WS text message: {e}")

            elif msg.type == web.WSMsgType.BINARY:
                # Direct binary PCM stream (from desktop mic or low-latency telephony)
                pcm_data = msg.data
                vad_res = vad.process_frame(pcm_data)
                if vad_res["is_speech"]:
                    accumulated_pcm.extend(pcm_data)

                if vad_res["turn_finished"] and len(accumulated_pcm) > 0:
                    user_audio = bytes(accumulated_pcm)
                    accumulated_pcm.clear()
                    transcribed_text = stt_service.transcribe_pcm(user_audio)
                    if transcribed_text:
                        await ws.send_str(json.dumps({"event": "transcript", "text": transcribed_text}))

            elif msg.type == web.WSMsgType.ERROR:
                logger.error(f"WS error: {ws.exception()}")

    finally:
        summary_info = session_manager.close_session(session_id)
        if summary_info:
            logger.info(f"Session {session_id} closed. Summary: {summary_info['summary']}")
        logger.info(f"Realtime Voice Connection closed: {session_id}")

    return ws


def create_voice_server():
    app = web.Application()
    app.router.add_get("/voice/stream", handle_voice_websocket)
    app.router.add_get("/voice/health", lambda req: web.json_response({"status": "online", "service": "MJ Realtime Voice Server"}))
    return app


if __name__ == "__main__":
    port = int(os.getenv("VOICE_SERVER_PORT", 8765))
    host = os.getenv("VOICE_SERVER_HOST", "127.0.0.1")
    logger.info(f"Starting MJ Realtime Voice Server on ws://{host}:{port}/voice/stream")
    app = create_voice_server()
    web.run_app(app, host=host, port=port)
