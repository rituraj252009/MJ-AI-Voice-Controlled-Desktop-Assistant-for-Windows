import os
import sys
import time
import asyncio
import tempfile
import logging
from typing import AsyncGenerator, Optional
import edge_tts

import config
from voice.audio import AudioProcessor

logger = logging.getLogger("MJ_VoiceTTS")


class RealtimeTTS:
    """
    Streaming Neural TTS Engine for Realtime WebSockets & Telephony.
    Synthesizes speech using Edge-TTS with sub-500ms initial chunk delivery
    and instant interruption cancellation.
    """
    def __init__(self, voice: str = config.TTS_VOICE):
        self.voice = voice
        self.is_stopped = False

    def stop(self):
        """Immediately sets cancellation flag to stop audio delivery."""
        self.is_stopped = True

    async def generate_telephony_mulaw_stream(self, text: str) -> AsyncGenerator[bytes, None]:
        """
        Generates 8kHz G.711u mulaw audio frames directly for telephony WebSocket.
        Checks self.is_stopped before yielding each frame for 0ms barge-in.
        """
        self.is_stopped = False
        if not text or not text.strip():
            return

        communicate = edge_tts.Communicate(text, self.voice)
        fd, temp_mp3 = tempfile.mkstemp(suffix=".mp3")
        os.close(fd)

        try:
            await communicate.save(temp_mp3)
            if self.is_stopped:
                return

            # Read MP3 or convert to PCM
            # Use wavio/wave/soundfile or basic audioop
            # In Windows, we can use edge_tts raw stream or ffmpeg if available
            async for chunk in communicate.stream():
                if self.is_stopped:
                    break
                if chunk["type"] == "audio":
                    yield chunk["data"]

        except Exception as e:
            logger.error(f"TTS generation error: {e}")
        finally:
            if os.path.exists(temp_mp3):
                try:
                    os.remove(temp_mp3)
                except Exception:
                    pass


# Global singleton instance
tts_service = RealtimeTTS()
