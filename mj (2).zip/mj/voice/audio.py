import io
import wave
import numpy as np
from typing import Tuple

try:
    import audioop
except ImportError:
    try:
        import audioop_lts as audioop
    except ImportError:
        audioop = None


class AudioProcessor:
    """
    High-speed audio encoding, decoding, and resampling for telephony WebSockets.
    Converts 8kHz μ-law (G.711u) <-> 16kHz linear PCM for Groq Whisper Turbo and Edge-TTS.
    """
    @staticmethod
    def mulaw_to_pcm16(mulaw_bytes: bytes, target_rate: int = 16000, source_rate: int = 8000) -> bytes:
        """Converts G.711u telephony bytes to 16kHz 16-bit linear PCM."""
        if not mulaw_bytes:
            return b""

        if audioop:
            pcm_8k = audioop.ulaw2lin(mulaw_bytes, 2)
            if target_rate != source_rate:
                pcm_16k, _ = audioop.ratecv(pcm_8k, 2, 1, source_rate, target_rate, None)
                return pcm_16k
            return pcm_8k
        else:
            # Fallback numpy-based mulaw decoding
            mulaw = np.frombuffer(mulaw_bytes, dtype=np.uint8)
            # Standard G.711 conversion table / equation
            sign = (mulaw & 0x80) >> 7
            exponent = (mulaw & 0x70) >> 4
            mantissa = mulaw & 0x0F
            pcm = ((mantissa << 3) + 0x84) << exponent
            pcm = pcm - 0x84
            pcm = np.where(sign == 0, -pcm, pcm).astype(np.int16)
            
            # Simple 2x linear interpolation if 8k -> 16k
            if target_rate == 16000 and source_rate == 8000:
                pcm = np.repeat(pcm, 2)
            return pcm.tobytes()

    @staticmethod
    def pcm16_to_mulaw(pcm_bytes: bytes, source_rate: int = 16000, target_rate: int = 8000) -> bytes:
        """Converts linear PCM audio back to 8kHz G.711u for telephony streaming."""
        if not pcm_bytes:
            return b""

        if audioop:
            if source_rate != target_rate:
                pcm_8k, _ = audioop.ratecv(pcm_bytes, 2, 1, source_rate, target_rate, None)
            else:
                pcm_8k = pcm_bytes
            return audioop.lin2ulaw(pcm_8k, 2)
        else:
            pcm = np.frombuffer(pcm_bytes, dtype=np.int16)
            if source_rate == 16000 and target_rate == 8000:
                pcm = pcm[::2]
            # Fast clip
            pcm = np.clip(pcm, -32768, 32767)
            # Mulaw compression
            sign = np.where(pcm < 0, 0, 0x80)
            pcm_abs = np.abs(pcm) + 0x84
            pcm_abs = np.clip(pcm_abs, 0, 32767)
            exponent = np.clip((np.log2(pcm_abs) - 7).astype(np.int8), 0, 7)
            mantissa = ((pcm_abs >> (exponent + 3)) & 0x0F)
            mulaw = ~(sign | (exponent << 4) | mantissa) & 0xFF
            return mulaw.astype(np.uint8).tobytes()

    @staticmethod
    def create_wav_header(pcm_bytes: bytes, sample_rate: int = 16000, channels: int = 1) -> bytes:
        """Wraps raw PCM in a valid WAV header for STT APIs."""
        wav_buf = io.BytesIO()
        with wave.open(wav_buf, 'wb') as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm_bytes)
        wav_buf.seek(0)
        return wav_buf.read()
