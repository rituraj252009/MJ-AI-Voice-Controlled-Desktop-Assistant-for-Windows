import time
import logging
from typing import Dict, Any, Optional, List

from backend.memory.conversations import conversation_manager
from backend.memory.contacts import contacts_manager

logger = logging.getLogger("MJ_SessionManager")


class CallSession:
    def __init__(self, session_id: str, caller_name: str, caller_phone: str, direction: str = "inbound"):
        self.session_id = session_id
        self.caller_name = caller_name
        self.caller_phone = caller_phone
        self.direction = direction
        self.started_at = time.time()
        self.ended_at = None
        self.status = "active"
        self.dialogue_history: List[Dict[str, str]] = []
        self.is_speaking = False

    def add_turn(self, role: str, text: str):
        self.dialogue_history.append({
            "role": role,
            "text": text,
            "timestamp": time.strftime("%H:%M:%S")
        })

    def end(self) -> Dict[str, Any]:
        self.ended_at = time.time()
        self.status = "completed"
        duration = int(self.ended_at - self.started_at)

        # Generate summary
        transcript_text = "\n".join([f"{t['role'].title()}: {t['text']}" for t in self.dialogue_history])
        summary_text = f"Call with {self.caller_name} ({duration}s):\n{transcript_text}" if transcript_text else "Call completed without dialogue."

        # Save to database
        conversation_manager.record_call(
            call_id=self.session_id,
            contact_name=self.caller_name,
            phone=self.caller_phone,
            direction=self.direction,
            status="completed",
            duration_seconds=duration,
            transcript=transcript_text
        )

        conversation_manager.record_call_summary(
            call_id=self.session_id,
            contact_name=self.caller_name,
            summary=summary_text,
            action_items=""
        )

        return {
            "session_id": self.session_id,
            "caller": self.caller_name,
            "duration": duration,
            "summary": summary_text
        }


class SessionManager:
    """Manages concurrent active call sessions."""
    def __init__(self):
        self._sessions: Dict[str, CallSession] = {}

    def create_session(self, session_id: str, phone: str, name: Optional[str] = None, direction: str = "inbound") -> CallSession:
        if not name:
            contact = contacts_manager.find_contact(phone)
            name = contact["name"] if contact else phone

        session = CallSession(session_id, name, phone, direction=direction)
        self._sessions[session_id] = session
        return session

    def get_session(self, session_id: str) -> Optional[CallSession]:
        return self._sessions.get(session_id)

    def close_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        session = self._sessions.pop(session_id, None)
        if session:
            return session.end()
        return None


# Global singleton instance
session_manager = SessionManager()
