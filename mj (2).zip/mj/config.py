import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Identity & Personalization
ASSISTANT_NAME = "MJ"
USER_NAME = "Rituraj"
USER_TITLE = "Sir Rituraj"

# API Keys (Loaded strictly from .env)
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

# AI Models
GEMINI_MODEL = "gemini-3.7-flash"
FAST_GEMINI_MODEL = "gemini-3.5-flash-lite"
GROQ_WHISPER_MODEL = "whisper-large-v3-turbo"
GROQ_CHAT_MODEL = "qwen/qwen3.8-27b"

# Language & Personality Settings
ASSISTANT_LANGUAGE = "hi"

# Voice & Speech Engine Settings
# High-fidelity Indian Hindi male neural voice for pure Hindi speech
TTS_VOICE = "hi-IN-MadhurNeural"
TTS_FALLBACK_ENGINE = "pyttsx3"

# Audio Recording Settings (Continuous & Responsive Tuning)
SAMPLE_RATE = 16000        # Standard for Whisper Turbo
CHANNELS = 1               # Mono
SILENCE_THRESHOLD = 0.0035 # Base threshold (dynamically calibrated with ambient floor)
SILENCE_DURATION = 0.70    # 0.70s natural pause cutoff for crisp, responsive recognition
MAX_RECORDING_SECONDS = 15 # Max recording window
PRE_SPEECH_BLOCKS = 8      # Rolling pre-buffer to preserve start of first words
BARGE_IN_THRESHOLD = 0.035 # Energy to interrupt MJ while speaking
MIN_SPEECH_PEAK = 0.012    # Minimum peak amplitude to prevent sending ambient silence to Whisper
WHISPER_TIMEOUT = 3.5      # Max seconds for Groq Whisper transcription
WHISPER_TEMPERATURE = 0.0  # Zero hallucination, deterministic output

# Clap Detector Settings
CLAP_THRESHOLD = 0.40    # Amplitude threshold for sudden clap impulse (0.0 to 1.0)
CLAP_MIN_INTERVAL = 0.15 # Min seconds between two claps (rejects echoes / continuous noise)
CLAP_MAX_INTERVAL = 0.85 # Max seconds between two claps for a double clap
CLAP_BLOCK_SIZE = 1024   # Audio frame block size for stream

# Web Dashboard HUD
DASHBOARD_HOST = "127.0.0.1"
DASHBOARD_PORT = 5000
